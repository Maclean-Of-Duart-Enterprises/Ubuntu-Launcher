# Ubuntu Launcher 1.0.3.001 build verification

Verified on 2026-10-08 with JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile/target SDK 35, and Android build tools 35.0.0.

## Completed checks

- `compileReleaseKotlin`: passed
- `lintRelease`: passed with no errors
- `assembleRelease`: passed
- R8 code optimization: passed
- Resource shrinking and optimization: passed
- APK zip alignment: passed
- APK Signature Schemes v2 and v3: passed
- Package: `com.macleanofduartenterprises.ubuntulauncher`
- Version: `1.0.3.001` (`versionCode 5`)
- Minimum/target SDK: 26 / 35
- Native ABIs: ARM64, ARMv7, x86, x86_64
- Release certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`

The package name and signing certificate match the supplied 1.0.1 signed release, and versionCode 5 is higher than versionCode 2, so Android can treat this APK as its signed upgrade.

## Repairs and improvements

- Repaired the Kotlin/Compose syntax defects that prevented the supplied source from compiling.
- Replaced stale hard-coded About information with BuildConfig release identity.
- Moved installed-app enumeration and image decoding off the main thread.
- Added sampled wallpaper/file previews and cached application icon bitmaps.
- Disabled JavaScript in background favicon WebViews.
- Added adaptive and monochrome icons.
- Enabled release code shrinking, resource shrinking, and optimization.
- Corrected and hardened the signed GitHub Actions build workflow.

The release keystore and credentials are never included in this source archive.
