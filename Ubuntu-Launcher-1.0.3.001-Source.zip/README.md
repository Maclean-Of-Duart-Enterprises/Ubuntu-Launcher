# Ubuntu Launcher for Android

Ubuntu Launcher is a standalone Android HOME launcher with an Ubuntu-inspired aubergine and orange interface. It supports portrait and landscape layouts, a searchable application drawer, configurable taskbar, desktop shortcuts, Dumb Phone Mode, per-orientation appearance controls, launcher backup/restore, and an optional launcher-level lock.

## Release identity

- App name: **Ubuntu Launcher**
- Application ID: `com.macleanofduartenterprises.ubuntulauncher`
- Version: **1.0.3.001** (`versionCode 5`)
- Developer: **Maclean Of Duart Enterprises Corp**
- Android support: API 26+; compile/target SDK 35
- APK format: universal ARM64, ARMv7, x86, and x86_64

## Features

- Android HOME/default-launcher role request
- Portrait and landscape-specific wallpapers, scaling, clock, typography, desktop columns, custom text, and border style
- Fast asynchronous installed-app discovery and cached app icons
- Searchable application drawer with grid and list modes
- Unlimited scrollable taskbar pins with configurable position, size, visibility, and auto-hide delay
- Main and optional secondary desktop pages for files and website shortcuts
- File image previews and website favicon tiles
- Long-press shortcut rename and removal
- Configurable weather-app shortcut and launcher swipe actions
- Dumb Phone Mode with app allowlist and optional notification filtering
- Launcher-level hidden-app list
- Optional launcher lock with hashed PIN/password
- JSON settings backup and restore
- Adaptive and monochrome launcher icons

## Build

Use Android Studio with JDK 17, or run:

```bash
./gradlew --no-daemon assembleDebug
./gradlew --no-daemon lintRelease assembleRelease
```

The Gradle wrapper uses Gradle 8.9. Release builds use R8 code optimization and resource shrinking.

### Signed release

Private signing material is intentionally excluded. Supply it through environment variables:

```bash
export ANDROID_KEYSTORE_PATH=/absolute/path/to/release.keystore
export ANDROID_KEYSTORE_PASSWORD='...'
export ANDROID_KEY_ALIAS='...'
export ANDROID_KEY_PASSWORD='...'
./gradlew --no-daemon clean lintRelease assembleRelease
```

The signed APK is written to `app/build/outputs/apk/release/app-release.apk`. The GitHub Actions workflow accepts the equivalent encrypted repository secrets and verifies the resulting APK signature.

## Android limitations

Hidden Apps removes selected apps from this launcher's Home, drawer, search, and Dumb Phone Mode. It does not uninstall, disable, or system-lock other apps. The optional launcher lock protects this launcher UI but does not replace Android's secure system keyguard. Weather is an app shortcut rather than a live third-party widget; full widgets require AppWidgetHost integration.

## License and trademarks

Ubuntu Launcher is distributed under the GNU Affero General Public License version 3. The complete license is included as `LICENSE`, bundled in the app, and viewable under **Ubuntu Launcher Settings → Licenses**.

Ubuntu and the Ubuntu logo are registered trademarks of Canonical Ltd. This independent project is not endorsed by or affiliated with Canonical.
