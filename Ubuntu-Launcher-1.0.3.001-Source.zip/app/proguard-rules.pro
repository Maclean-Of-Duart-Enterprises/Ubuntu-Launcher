# Android Gradle Plugin and the bundled AndroidX consumer rules retain all
# manifest components and Compose metadata required by this application.
