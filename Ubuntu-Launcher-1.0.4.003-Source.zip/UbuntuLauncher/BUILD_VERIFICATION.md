# Ubuntu Launcher 1.0.4.003 build verification

Verified on 2026-10-12 with JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile/target SDK 35, and Android build tools 35.0.0.

## Completed checks

- `testDebugUnitTest`: passed (13 tests across 4 suites)
- `compileReleaseKotlin`: passed
- `lintRelease`: passed (0 errors; 0 warnings)
- `assembleRelease`: passed
- R8 code optimization: passed
- Resource shrinking and optimization: passed
- APK zip alignment: passed
- APK Signature Schemes v2 and v3: passed
- Package: `com.macleanofduartenterprises.ubuntulauncher`
- Version: `1.0.4.003` (`versionCode 10`)
- Minimum/target SDK: 26 / 35
- Native ABIs: ARM64, ARMv7, x86, and x86_64
- Release certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- APK SHA-256: `749d5bb53dcc60ba9882b5fa340dab25a9506f9ab6341b74c0d8da33667b04dd`
- APK size: 1,467,821 bytes

The package name and release certificate exactly match the supplied releases. Version code 10 is higher than version 1.0.4.002's version code 9, allowing Android to install 1.0.4.003 as a signed upgrade.

## Repairs and improvements

- Repaired the Kotlin/Compose syntax defects that prevented the supplied source from compiling.
- Replaced stale hard-coded About information with BuildConfig release identity.
- Moved installed-app enumeration and image decoding off the main thread.
- Added sampled wallpaper/file previews and cached application icon bitmaps.
- Replaced fragile hidden WebView favicon extraction with direct favicon discovery, redirect handling, memory caching, and persistent disk caching.
- Added adaptive and monochrome icons.
- Updated adaptive and legacy icons from the supplied Ubuntu Launcher artwork and centered the complete design inside Android's safe mask area.
- Repaired Home-gesture re-entry with a dedicated single launcher task, state restoration, and a non-black window fallback.
- Added system All Apps intent routing and isolated third-party app/icon failures from the Home surface.
- Repaired Dumb Phone filtering for new and already-active notifications outside the app allowlist.
- Added live notification-access status, an app-specific Android permission route, all-type listener delivery metadata, settings-change reconciliation, and listener rebind recovery.
- Added four notification-filter policy tests covering disabled states, allowed apps, launcher self-notifications, and blocked apps.
- Added independent vertical and horizontal clock placement for portrait and landscape.
- Reserved a full desktop grid row for the clock, preventing overlap with files and links at every placement.
- Added persistent three-second hold-and-drag/tap shortcut placement with occupied-slot swapping.
- Raised the landscape desktop limit to 14 columns and added unlimited vertically scrollable shortcut rows in both orientations.
- Added live preference observation so newly shared files and links appear without restarting the launcher.
- Propagated preference revisions through the home, clock, taskbar, wallpaper, desktop, and app-drawer surfaces so saved settings render immediately without restarting the phone.
- Repaired lock activation, foreground lifecycle re-locking, manual Lock now, PIN validation, and incorrect-entry feedback.
- Enabled release code shrinking, resource shrinking, and optimization.
- Corrected and hardened the signed GitHub Actions build workflow.

The release keystore and credentials are never included in this source archive.
