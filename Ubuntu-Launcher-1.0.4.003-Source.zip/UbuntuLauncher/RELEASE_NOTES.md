# Ubuntu Launcher 1.0.4.003

## Live settings refresh hotfix (`versionCode 10`)

- Fixed launcher settings that were saved but did not appear until the phone restarted.
- Clock placement, clock text, typography, color, and visibility now update on the launcher immediately.
- Taskbar pinned apps, taskbar position, size, visibility, and auto-hide settings now refresh immediately.
- Wallpaper, desktop layout, shared shortcuts, weather, swipe actions, and app-drawer presentation now observe the same live preference revision.
- Retains the Dumb Phone notification-filter, Home-gesture, favicon, icon, lock-screen, and desktop-layout fixes from prior 1.0.4 builds.

## Dumb Phone notification-filter hotfix (`versionCode 9`, version 1.0.4.002)

- Repaired Dumb Phone notification filtering for apps outside the selected allowlist.
- The listener now filters newly posted notifications and immediately reconciles already-active notifications when it connects or when Dumb Phone settings change.
- Added automatic listener rebind recovery and explicit support for conversation, alerting, silent, and ongoing notification types.
- Enabling the filter without Android notification access now opens Ubuntu Launcher's app-specific permission screen.
- Dumb Phone Settings now shows whether notification access is granted and clearly warns when the filter cannot run.
- Android still controls protected system and non-dismissible foreground-service notifications; those cannot always be removed by a third-party listener.

## Swipe/Home hotfix (`versionCode 8`)

- Repaired the black screen that could appear when Android returned to the launcher with an upward Home gesture.
- Aligned the HOME activity task and restoration behavior with Android Launcher3: single launcher task, cleared stale task state, state-not-needed recovery, and empty task affinity.
- System **All Apps** intents now open the application drawer; ordinary Home, icon-launch, and Share intents restore the desktop.
- Isolated installed-app and third-party icon failures so one invalid app entry cannot take down the Home surface.
- Added an aubergine window fallback while Compose restores, avoiding a black launch window.
- Reframed the supplied icon inside Android's adaptive safe area so the complete centered artwork remains visible under device-specific masks.

## Desktop layout

- The clock and custom text now occupy a reserved grid row and cannot overlap shared files or website links.
- Hold a file or website shortcut for three seconds to enter move mode. Drag it to a visible slot, or release, scroll, and tap any destination. Moving onto an occupied slot swaps the two shortcuts.
- Shortcut positions are saved independently for the main and secondary pages in portrait and landscape.
- Landscape supports 2–14 columns; portrait supports 2–8 columns.
- File and link rows expand as needed and scroll vertically in both orientations.

## Website icons

- Restored favicon loading without a background WebView.
- Discovers page icon links, Apple touch icons, web-manifest icons, and conventional favicon locations.
- Follows redirects and caches successful icons in memory and on disk for faster subsequent launches.

## Existing 1.0.3.002 improvements retained

- Updated Ubuntu Launcher app icon.
- Separate portrait and landscape display settings, including top/center/bottom and left/center/right clock placement.
- Launcher PIN/password activation, immediate **Lock now**, incorrect-entry feedback, and automatic re-lock after the launcher leaves the foreground.

The launcher lock protects the Ubuntu Launcher interface; Android's secure system keyguard remains the device-level lock.
