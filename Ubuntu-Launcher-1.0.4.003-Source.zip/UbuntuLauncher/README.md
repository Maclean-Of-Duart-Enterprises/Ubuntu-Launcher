# Ubuntu Launcher for Android

Ubuntu Launcher is a standalone Android HOME launcher with an Ubuntu-inspired aubergine and orange interface. It supports portrait and landscape layouts, a searchable application drawer, configurable taskbar, desktop shortcuts, Dumb Phone Mode, per-orientation appearance controls, launcher backup/restore, and an optional launcher-level lock.

## Release identity

- App name: **Ubuntu Launcher**
- Application ID: `com.macleanofduartenterprises.ubuntulauncher`
- Version: **1.0.4.003** (`versionCode 10`, live launcher-settings refresh hotfix)
- Developer: **Maclean Of Duart Enterprises Corp**
- Android support: API 26+; compile/target SDK 35
- APK format: universal ARM64, ARMv7, x86, and x86_64

## Features

- Android HOME/default-launcher role request with a dedicated single launcher task and reliable gesture-Home restoration
- Portrait and landscape-specific wallpapers, scaling, clock typography, independent 3×3 clock placement, desktop columns, custom text, and border style
- Fast, failure-isolated asynchronous installed-app discovery and cached app icons
- Searchable application drawer with grid and list modes
- Unlimited scrollable taskbar pins with configurable position, size, visibility, and auto-hide delay
- Main and optional secondary desktop pages with unlimited vertically scrollable rows for files and website shortcuts
- Up to 14 desktop columns in landscape and up to 8 in portrait
- Clock/date content occupies its own grid row, so it never paints over shortcuts
- Three-second hold-to-move shortcut placement with drag, tap-to-place, occupied-slot swapping, and persistent per-page/per-orientation positions
- File image previews and directly downloaded, memory/disk-cached website favicons with HTML, web-manifest, and conventional favicon discovery
- Shortcut rename and removal from move mode
- Configurable weather-app shortcut and launcher swipe actions
- Dumb Phone Mode with an app allowlist and notification filtering that reconciles both new and already-active notifications
- App-specific Android notification-access guidance with live granted/not-granted status
- Launcher-level hidden-app list
- Optional launcher lock with hashed PIN/password, immediate activation, Lock now, incorrect-entry feedback, and automatic re-lock after leaving the launcher
- JSON settings backup and restore
- Safely centered adaptive and legacy launcher icons generated from the supplied Ubuntu Launcher artwork
- Live preference observation for clock placement and text, taskbar pins and layout, wallpapers, desktop shortcuts, and app-drawer presentation—no phone restart required

## Build

Use Android Studio with JDK 17, or run:

```bash
./gradlew --no-daemon assembleDebug
./gradlew --no-daemon testDebugUnitTest lintRelease assembleRelease
```

The Gradle wrapper uses Gradle 8.9. Release builds use R8 code optimization and resource shrinking.

### Signed release

Private signing material is intentionally excluded. Supply it through environment variables:

```bash
export ANDROID_KEYSTORE_PATH=/absolute/path/to/release.keystore
export ANDROID_KEYSTORE_PASSWORD='...'
export ANDROID_KEY_ALIAS='...'
export ANDROID_KEY_PASSWORD='...'
./gradlew --no-daemon clean lintRelease assembleRelease
```

The signed APK is written to `app/build/outputs/apk/release/app-release.apk`. The GitHub Actions workflow accepts the equivalent encrypted repository secrets and verifies the resulting APK signature.

## Enable Dumb Phone notification filtering

1. Open **Ubuntu Launcher Settings → Dumb Phone Settings**.
2. Choose the applications permitted in Dumb Phone Mode.
3. Turn on **Notification filter**. If access is missing, the launcher opens Android's app-specific notification-access page.
4. Enable **Ubuntu Launcher** and allow every notification type, then return to the launcher.
5. Turn on **Dumb Phone Mode**.

The settings page reports whether Android notification access is granted. When active, the service dismisses new and already-visible notifications from packages outside the Dumb Phone allowlist.

## Android limitations

Hidden Apps removes selected apps from this launcher's Home, drawer, search, and Dumb Phone Mode. It does not uninstall, disable, or system-lock other apps. The optional launcher lock protects this launcher UI but does not replace Android's secure system keyguard. Weather is an app shortcut rather than a live third-party widget; full widgets require AppWidgetHost integration.

## License and trademarks

Ubuntu Launcher is distributed under the GNU Affero General Public License version 3. The complete license is included as `LICENSE`, bundled in the app, and viewable under **Ubuntu Launcher Settings → Licenses**.

Ubuntu and the Ubuntu logo are registered trademarks of Canonical Ltd. This independent project is not endorsed by or affiliated with Canonical.
