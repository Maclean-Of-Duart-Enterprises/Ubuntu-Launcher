package com.macleanofduartenterprises.ubuntulauncher

import android.content.ComponentName
import android.content.SharedPreferences
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

internal const val LAUNCHER_PREFERENCES = "launcher"
internal const val DUMB_MODE_PREFERENCE = "dumb_mode"
internal const val DUMB_NOTIFICATION_FILTER_PREFERENCE = "dumb_notification_filter"
internal const val DUMB_ALLOWLIST_PREFERENCE = "dumb"

internal fun shouldCancelDumbPhoneNotification(
    notificationPackage: String,
    launcherPackage: String,
    dumbModeEnabled: Boolean,
    notificationFilterEnabled: Boolean,
    allowedPackages: Set<String>
): Boolean =
    dumbModeEnabled &&
        notificationFilterEnabled &&
        notificationPackage != launcherPackage &&
        notificationPackage !in allowedPackages

class NotificationFilterService : NotificationListenerService() {
    private val preferences by lazy {
        getSharedPreferences(LAUNCHER_PREFERENCES, MODE_PRIVATE)
    }
    private var listenerConnected = false

    private val preferenceListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (
                key == DUMB_MODE_PREFERENCE ||
                key == DUMB_NOTIFICATION_FILTER_PREFERENCE ||
                key == DUMB_ALLOWLIST_PREFERENCE
            ) {
                reconcileActiveNotifications()
            }
        }

    override fun onCreate() {
        super.onCreate()
        preferences.registerOnSharedPreferenceChangeListener(preferenceListener)
    }

    override fun onDestroy() {
        preferences.unregisterOnSharedPreferenceChangeListener(preferenceListener)
        super.onDestroy()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        listenerConnected = true
        reconcileActiveNotifications()
    }

    override fun onListenerDisconnected() {
        listenerConnected = false
        super.onListenerDisconnected()
        runCatching {
            requestRebind(ComponentName(this, NotificationFilterService::class.java))
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (shouldCancel(sbn.packageName)) {
            runCatching { cancelNotification(sbn.key) }
        }
    }

    private fun shouldCancel(notificationPackage: String): Boolean =
        shouldCancelDumbPhoneNotification(
            notificationPackage = notificationPackage,
            launcherPackage = packageName,
            dumbModeEnabled = preferences.getBoolean(DUMB_MODE_PREFERENCE, false),
            notificationFilterEnabled = preferences.getBoolean(
                DUMB_NOTIFICATION_FILTER_PREFERENCE,
                false
            ),
            allowedPackages = preferences.getStringSet(
                DUMB_ALLOWLIST_PREFERENCE,
                emptySet()
            ).orEmpty().toSet()
        )

    private fun reconcileActiveNotifications() {
        if (!listenerConnected) return
        runCatching {
            val keys = activeNotifications
                .orEmpty()
                .filter { shouldCancel(it.packageName) }
                .map { it.key }
                .toTypedArray()
            if (keys.isNotEmpty()) cancelNotifications(keys)
        }
    }
}
