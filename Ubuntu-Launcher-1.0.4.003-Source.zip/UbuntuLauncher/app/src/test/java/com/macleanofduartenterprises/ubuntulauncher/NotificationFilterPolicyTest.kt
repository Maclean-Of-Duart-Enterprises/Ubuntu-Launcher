package com.macleanofduartenterprises.ubuntulauncher

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NotificationFilterPolicyTest {
    private val launcherPackage = "com.macleanofduartenterprises.ubuntulauncher"
    private val allowedPackages = setOf("org.example.allowed")

    @Test
    fun filterRequiresBothDumbModeAndNotificationFiltering() {
        assertFalse(
            shouldCancelDumbPhoneNotification(
                "org.example.blocked",
                launcherPackage,
                dumbModeEnabled = false,
                notificationFilterEnabled = true,
                allowedPackages
            )
        )
        assertFalse(
            shouldCancelDumbPhoneNotification(
                "org.example.blocked",
                launcherPackage,
                dumbModeEnabled = true,
                notificationFilterEnabled = false,
                allowedPackages
            )
        )
    }

    @Test
    fun allowsPackagesOnTheDumbPhoneList() {
        assertFalse(
            shouldCancelDumbPhoneNotification(
                "org.example.allowed",
                launcherPackage,
                dumbModeEnabled = true,
                notificationFilterEnabled = true,
                allowedPackages
            )
        )
    }

    @Test
    fun alwaysAllowsUbuntuLauncherNotifications() {
        assertFalse(
            shouldCancelDumbPhoneNotification(
                launcherPackage,
                launcherPackage,
                dumbModeEnabled = true,
                notificationFilterEnabled = true,
                allowedPackages
            )
        )
    }

    @Test
    fun cancelsPackagesOutsideTheDumbPhoneList() {
        assertTrue(
            shouldCancelDumbPhoneNotification(
                "org.example.blocked",
                launcherPackage,
                dumbModeEnabled = true,
                notificationFilterEnabled = true,
                allowedPackages
            )
        )
    }
}
