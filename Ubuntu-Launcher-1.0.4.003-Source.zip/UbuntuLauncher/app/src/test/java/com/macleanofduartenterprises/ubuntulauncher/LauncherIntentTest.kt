package com.macleanofduartenterprises.ubuntulauncher

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LauncherIntentTest {
    @Test
    fun allAppsActionsOpenTheDrawer() {
        assertTrue(opensAppDrawerForLauncherAction("android.intent.action.ALL_APPS"))
        assertTrue(opensAppDrawerForLauncherAction("android.intent.action.SHOW_WORK_APPS"))
    }

    @Test
    fun homeAndShareActionsRestoreTheDesktop() {
        assertFalse(opensAppDrawerForLauncherAction("android.intent.action.MAIN"))
        assertFalse(opensAppDrawerForLauncherAction("android.intent.action.SEND"))
        assertFalse(opensAppDrawerForLauncherAction(null))
    }
}
