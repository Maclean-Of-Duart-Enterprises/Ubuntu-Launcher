# Ubuntu Launcher for Android

A standalone Android HOME launcher with an Ubuntu-inspired visual shell. Portrait uses a phone-first Ubuntu-style home; landscape automatically becomes a desktop-style shell with a left dock, Activities/app search and desktop grid.

- App name: **Ubuntu Launcher**
- Application ID: `com.macleanofduartenterprises.ubuntulauncher`
- Version: **1.0.3 debug** (`versionCode 4`)
- Developer: **Maclean Of Duart Enterprises Corp**

## Included
- Android HOME/default-launcher role request
- Automatic portrait/landscape layouts
- Ubuntu-inspired aubergine/orange UI
- Installed-app discovery and launch
- App + Android settings search
- Pinnable dock (long-press an app)
- Dumb Phone Mode with selectable allowed apps
- Launcher-level hidden-app vault, available only inside Launcher Settings
- Wi-Fi/Bluetooth/Display/Sound/Storage/Security/Accessibility shortcuts
- Package-change refresh when apps are installed, removed, or updated

## Build
Open in Android Studio (JDK 17), allow Gradle sync, then Build > Build APK(s), or run:

```bash
./gradlew assembleDebug
./gradlew assembleRelease
```

The included Gradle wrapper uses Gradle 8.9. The project uses compileSdk/targetSdk 35 and minSdk 26. The release build is a universal APK; the bundled AndroidX native helper includes ARM64, ARMv7, x86, and x86_64 ABIs.

The source project intentionally excludes private signing keys and passwords. Keep release credentials outside version control, then align and sign the release APK with Android SDK `zipalign` and `apksigner`.

## Important Android limitations
The Hidden Apps feature removes selected apps from this launcher's Home, drawer, search and Dumb Phone mode. It does not uninstall, disable, or system-lock them. Strong system-wide blocking requires device-owner/enterprise privileges or OS support. Android 15+ Private Space is a separate platform feature and requires additional launcher integration if you want to expose Private Space apps.

## Suggested next modules
Widgets/AppWidgetHost, folders, desktop drag-and-drop, notification badges (with notification-listener permission), icon packs, wallpaper picker, gestures, backup/export, work/private-profile support, keyboard shortcuts, mouse context menus, and per-orientation layouts.

## License

Ubuntu Launcher is distributed under the GNU Affero General Public License, version 3 (AGPLv3). The complete license text is included in the repository as `LICENSE`, bundled in the Android application as `res/raw/agpl_3_0.txt`, and can be viewed in the launcher under **Ubuntu Launcher Settings → Licenses**.

Ubuntu and the Ubuntu logo are registered trademarks of Canonical Ltd. This independent project is not endorsed by or affiliated with Canonical.

## 1.0.2beta
Development update adds separate regular/Dumb Phone photo backgrounds and slideshow selection, desktop-style pinned apps/files/web links, 2–8 desktop columns, configurable taskbar position/size/hide/auto-hide, app drawer grid/list modes, Dumb Phone notification filtering through Android Notification Access, selectable weather app shortcut, Ubuntu-style launcher lock layer with hashed PIN/password, and the supplied Ubuntu Launcher artwork as the launcher icon. Android's secure system keyguard is intentionally not replaced.


## Second draft corrections
- Application pinning is taskbar-only; applications are not pinned to desktop pages.
- Main desktop page is reserved for file shortcuts, website shortcuts, desktop information/widgets and controls.
- Optional secondary desktop page can be enabled in Settings for file and website shortcuts.
- Settings selects the default destination for newly shared files and website links.
- Ubuntu-style launcher lock layer remains independently switchable on/off in Settings.

## Third-draft UI refinements
- Desktop and Dumb Phone home pages no longer show an "Ubuntu Desktop"/"Dumb Phone" title or settings gear.
- Taskbar pins are unlimited and scrollable.
- Desktop settings group taskbar, taskbar pins, secondary page, shared shortcut destination, and weather app.
- Dumb Phone Settings groups all four Dumb Phone controls.
- Wallpaper can be removed to restore the default launcher display.
- Clock/date size, color, and font are configurable.
- Launcher settings can be exported to and restored from a JSON backup file.

### Fourth-draft desktop interaction additions
- Desktop file and website shortcuts can be long-pressed to rename or remove them.
- Image files use their image content as the shortcut background preview when readable; other files retain a file icon.
- Website shortcuts render a live, non-interactive WebView preview as their tile background; tapping the tile opens the website normally.
- Taskbar auto-hide duration is configurable as a custom number of seconds.
- A small orange reveal dot remains on the appropriate taskbar edge whenever auto-hide has hidden the taskbar.
- Optional launcher swipe actions can be enabled under Desktop settings: swipe right opens Applications and swipe left opens Launcher Settings.

## GitHub signed release build
The repository includes `.github/workflows/build-signed-release.yml`. Configure these encrypted GitHub Actions repository secrets before running it:

- `ANDROID_KEYSTORE_BASE64` — Base64 of the release keystore
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

The private keystore and credentials are intentionally not committed to source control. The workflow reconstructs the keystore only inside the ephemeral GitHub runner and builds `assembleRelease` with Java 17.

## 1.0.2beta fourth-draft hardening
Website shortcut tiles no longer embed live WebViews on the launcher desktop. This removes the WebView cross-thread/ViewDebug failure observed in the Android bug report. Website tiles now asynchronously load the site’s own `/favicon.ico` on an IO dispatcher and fall back to a local web icon when unavailable. The desktop therefore contains no persistent WebView instances.

### WebView / AndroidView restoration
Website desktop shortcuts use a live Android `WebView` hosted by Jetpack Compose `AndroidView`. Creation, URL loading, updates, and destruction are constrained to Android's main looper. Shortcut tap/long-press handling remains owned by the launcher overlay, so the WebView is used as the live preview surface without taking over launcher navigation.

### Clock + website shortcut correction
- Desktop and launcher-lock clocks now maintain live Compose time state and refresh every second rather than freezing at composition time.
- Website shortcuts display the site's favicon instead of a miniature page preview.
- WebView and Compose AndroidView remain present and functional for page loading/favicon discovery; WebView lifecycle operations remain on the main looper.


## 1.0.3 debug
- Adds Desktop Settings → Weather → Show weather emblem.
- The weather app selection is preserved when the emblem is hidden.
- Hiding the emblem only affects the main desktop weather shortcut; no other launcher behavior is changed.
- Based on the device-tested 1.0.2beta debug source.

### Desktop Settings update (2026-10-07)
- Removed the Applications / Pin file / Add website button row from desktop pages. The taskbar app drawer button remains.
- Added Pin file and Add website to Desktop Settings. The shared shortcut destination controls the page used for these actions.
- Weather remains an app-launch shortcut, not a true live widget. A third-party weather app's live conditions and icon cannot be inferred reliably from its package; an Android AppWidgetHost widget picker/binding UI is required for full weather-widget functionality.
- Source-only patch; no Android compilation was performed in this environment.

## 1.0.3.001 orientation-specific display settings

Settings → Display settings → Portrait orientation / Landscape orientation.
Each orientation independently configures regular and Dumb Phone wallpapers, Crop / Fill / Fit / Zoom scaling, clock visibility, size, color and font, desktop columns, custom text and border style. Existing legacy values are used as defaults for backward compatibility. New photo selection is saved to the selected orientation.

This source archive is not an APK and has not been verified by a Gradle compile in this environment. Run the GitHub debug build and test both rotations before installing a release build.
