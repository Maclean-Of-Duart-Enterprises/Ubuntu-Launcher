# Ubuntu Launcher 1.0.3-debug build verification

The attached debug APK is a compiled reference artifact, not editable Kotlin source. The provided ZIP is the authoritative source tree.

## Repairs
- Replaced the dense, single-line `AppDrawer` composable with balanced, readable Kotlin/Compose declarations.
- Explicitly named Material3 `ListItem` slots to reduce overload/argument-order errors.
- CI compiles `assembleDebug` before attempting signed release packaging.
- Corrected GitHub Actions artifact version labels to 1.0.3-debug.
- Preserved package name, versionCode 4, versionName 1.0.3-debug, AGPLv3, and other source functions.

## Local verification status
- Source ZIP validated as an archive.
- Kotlin/Android Gradle compilation was **not executed successfully in this environment**; GitHub Actions is required for authoritative compiler verification.
- A debug APK can prove that *some* source version compiled, but cannot establish that this exact updated source compiles.

## Build
`./gradlew --no-daemon --stacktrace assembleDebug`

The signed-release workflow also requires repository Actions secrets. Never commit signing keys or passwords.
