# Ubuntu Launcher for Android

A standalone Android HOME launcher with an Ubuntu-inspired visual shell. Portrait uses a phone-first Ubuntu-style home; landscape automatically becomes a desktop-style shell with a left dock, Activities/app search and desktop grid.

- App name: **Ubuntu Launcher**
- Application ID: `com.macleanofduartenterprises.ubuntulauncher`
- Version: **1.0.1** (`versionCode 2`)
- Developer: **Maclean Of Duart Enterprises Corp**

## Included
- Android HOME/default-launcher role request
- Automatic portrait/landscape layouts
- Ubuntu-inspired aubergine/orange UI
- Installed-app discovery and launch
- App + Android settings search
- Pinnable dock (long-press an app)
- Dumb Phone Mode with selectable allowed apps
- Launcher-level hidden-app vault, available only inside Launcher Settings
- Wi-Fi/Bluetooth/Display/Sound/Storage/Security/Accessibility shortcuts
- Package-change refresh when apps are installed, removed, or updated

## Build
Open in Android Studio (JDK 17), allow Gradle sync, then Build > Build APK(s), or run:

```bash
./gradlew assembleDebug
./gradlew assembleRelease
```

The included Gradle wrapper uses Gradle 8.9. The project uses compileSdk/targetSdk 35 and minSdk 26. The release build is a universal APK; the bundled AndroidX native helper includes ARM64, ARMv7, x86, and x86_64 ABIs.

The source project intentionally excludes private signing keys and passwords. Keep release credentials outside version control, then align and sign the release APK with Android SDK `zipalign` and `apksigner`.

## Important Android limitations
The Hidden Apps feature removes selected apps from this launcher's Home, drawer, search and Dumb Phone mode. It does not uninstall, disable, or system-lock them. Strong system-wide blocking requires device-owner/enterprise privileges or OS support. Android 15+ Private Space is a separate platform feature and requires additional launcher integration if you want to expose Private Space apps.

## Suggested next modules
Widgets/AppWidgetHost, folders, desktop drag-and-drop, notification badges (with notification-listener permission), icon packs, wallpaper picker, gestures, backup/export, work/private-profile support, keyboard shortcuts, mouse context menus, and per-orientation layouts.

## License

Ubuntu Launcher is distributed under the GNU Affero General Public License, version 3 (AGPLv3). The complete license text is included in the repository as `LICENSE`, bundled in the Android application as `res/raw/agpl_3_0.txt`, and can be viewed in the launcher under **Ubuntu Launcher Settings → Licenses**.

Ubuntu and the Ubuntu logo are registered trademarks of Canonical Ltd. This independent project is not endorsed by or affiliated with Canonical.

## 1.0.2beta
Development update adds separate regular/Dumb Phone photo backgrounds and slideshow selection, desktop-style pinned apps/files/web links, 2–8 desktop columns, configurable taskbar position/size/hide/auto-hide, app drawer grid/list modes, Dumb Phone notification filtering through Android Notification Access, selectable weather app shortcut, Ubuntu-style launcher lock layer with hashed PIN/password, and the supplied Ubuntu Launcher artwork as the launcher icon. Android's secure system keyguard is intentionally not replaced.


## Second draft corrections
- Application pinning is taskbar-only; applications are not pinned to desktop pages.
- Main desktop page is reserved for file shortcuts, website shortcuts, desktop information/widgets and controls.
- Optional secondary desktop page can be enabled in Settings for file and website shortcuts.
- Settings selects the default destination for newly shared files and website links.
- Ubuntu-style launcher lock layer remains independently switchable on/off in Settings.

## Third-draft UI refinements
- Desktop and Dumb Phone home pages no longer show an "Ubuntu Desktop"/"Dumb Phone" title or settings gear.
- Taskbar pins are unlimited and scrollable.
- Desktop settings group taskbar, taskbar pins, secondary page, shared shortcut destination, and weather app.
- Dumb Phone Settings groups all four Dumb Phone controls.
- Wallpaper can be removed to restore the default launcher display.
- Clock/date size, color, and font are configurable.
- Launcher settings can be exported to and restored from a JSON backup file.

### Fourth-draft desktop interaction additions
- Desktop file and website shortcuts can be long-pressed to rename or remove them.
- Image files use their image content as the shortcut background preview when readable; other files retain a file icon.
- Website shortcuts render a live, non-interactive WebView preview as their tile background; tapping the tile opens the website normally.
- Taskbar auto-hide duration is configurable as a custom number of seconds.
- A small orange reveal dot remains on the appropriate taskbar edge whenever auto-hide has hidden the taskbar.
- Optional launcher swipe actions can be enabled under Desktop settings: swipe right opens Applications and swipe left opens Launcher Settings.
