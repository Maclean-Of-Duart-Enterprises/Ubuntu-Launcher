package com.macleanofduartenterprises.ubuntulauncher

import android.app.role.RoleManager
import android.content.*
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.security.MessageDigest
import java.text.*
import java.util.*
import org.json.JSONObject
import org.json.JSONArray

private val Aubergine=Color(0xFF2C001E); private val Aubergine2=Color(0xFF3D1230); private val Orange=Color(0xFFE95420); private val Warm=Color(0xFFF7F3F0)
data class AppItem(val label:String,val packageName:String,val activityName:String,val icon:Drawable)
data class SettingItem(val label:String,val subtitle:String,val action:String)

class MainActivity:ComponentActivity(){
    private val prefs by lazy{getSharedPreferences("launcher",MODE_PRIVATE)}
    private val roleRequest=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){}
    private val photos=registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->
        if(uris.isNotEmpty()){uris.forEach{runCatching{contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}};prefs.edit().putStringSet(if(prefs.getBoolean("picking_dumb",false))"wall_dumb" else "wall_regular",uris.map{it.toString()}.toSet()).apply()}
    }
    private val file=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri-> uri?.let{
        runCatching{contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
        val page=prefs.getString("shortcut_target_page","main")?:"main"; val key=if(page=="secondary")"desktop_files_secondary" else "desktop_files_main"; val set=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.add("${it}|Pinned file");prefs.edit().putStringSet(key,set).apply()
    }}
    val backupOut=registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->uri?.let{exportBackup(it)}}
    val backupIn=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->uri?.let{importBackup(it);recreate()}}
    private fun exportBackup(uri:Uri){val root=JSONObject();prefs.all.forEach{(k,v)->when(v){is String->root.put(k,v);is Boolean->root.put(k,v);is Int->root.put(k,v);is Long->root.put(k,v);is Float->root.put(k,v);is Set<*>->root.put(k,JSONArray(v.filterIsInstance<String>()))}};contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(root.toString(2))}}
    private fun importBackup(uri:Uri){val text=contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:return;val root=JSONObject(text);val e=prefs.edit().clear();root.keys().forEach{k->when(val v=root.get(k)){is Boolean->e.putBoolean(k,v);is Int->e.putInt(k,v);is Long->e.putLong(k,v);is Double->e.putFloat(k,v.toFloat());is JSONArray->{val set=mutableSetOf<String>();for(i in 0 until v.length())set.add(v.getString(i));e.putStringSet(k,set)}else->e.putString(k,v.toString())}};e.apply()}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);acceptShare(intent);setContent{LauncherApp(prefs,{d->prefs.edit().putBoolean("picking_dumb",d).apply();photos.launch(arrayOf("image/*"))},{file.launch(arrayOf("*/*"))})}}
    override fun onNewIntent(intent:Intent){super.onNewIntent(intent);acceptShare(intent)}
    private fun acceptShare(i:Intent){if(i.action!=Intent.ACTION_SEND)return; val e=prefs.edit(); val uri=if(Build.VERSION.SDK_INT>=33)i.getParcelableExtra(Intent.EXTRA_STREAM,Uri::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM); val page=prefs.getString("shortcut_target_page","main")?:"main"; val suffix=if(page=="secondary")"secondary" else "main"; if(uri!=null){val key="desktop_files_$suffix";val s=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();s.add("$uri|Shared file");e.putStringSet(key,s)}; i.getStringExtra(Intent.EXTRA_TEXT)?.let{t->if(t.startsWith("http")){val key="desktop_links_$suffix";val s=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();s.add("$t|Shared link");e.putStringSet(key,s)}};e.apply()}
    fun requestHome(){if(Build.VERSION.SDK_INT>=29){val r=getSystemService(RoleManager::class.java);if(r.isRoleAvailable(RoleManager.ROLE_HOME)&&!r.isRoleHeld(RoleManager.ROLE_HOME))roleRequest.launch(r.createRequestRoleIntent(RoleManager.ROLE_HOME))}else startActivity(Intent(Settings.ACTION_HOME_SETTINGS))}
}
fun loadApps(c:Context):List<AppItem>{val q=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);return c.packageManager.queryIntentActivities(q,0).filter{it.activityInfo.packageName!=c.packageName}.map{AppItem(it.loadLabel(c.packageManager).toString(),it.activityInfo.packageName,it.activityInfo.name,it.loadIcon(c.packageManager))}.distinctBy{it.packageName+it.activityName}.sortedBy{it.label.lowercase()}}
fun launch(c:Context,a:AppItem)=runCatching{c.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(ComponentName(a.packageName,a.activityName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}.let{}
fun openSetting(c:Context,a:String)=runCatching{c.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}.let{}
fun hash(v:String)=MessageDigest.getInstance("SHA-256").digest(v.toByteArray()).joinToString(""){"%02x".format(it)}

@Composable fun LauncherApp(p:android.content.SharedPreferences,pickPhotos:(Boolean)->Unit,pickFile:()->Unit){
 val c=LocalContext.current;var apps by remember{mutableStateOf(loadApps(c))};var settings by remember{mutableStateOf(false)};var drawer by remember{mutableStateOf(false)};var q by remember{mutableStateOf("")};var tick by remember{mutableIntStateOf(0)};var unlocked by remember{mutableStateOf(!p.getBoolean("lock_enabled",false))}
 DisposableEffect(c){val r=object:BroadcastReceiver(){override fun onReceive(x:Context?,i:Intent?){apps=loadApps(c)}};val f=IntentFilter().apply{addAction(Intent.ACTION_PACKAGE_ADDED);addAction(Intent.ACTION_PACKAGE_REMOVED);addAction(Intent.ACTION_PACKAGE_CHANGED);addDataScheme("package")};ContextCompat.registerReceiver(c,r,f,ContextCompat.RECEIVER_EXPORTED);onDispose{runCatching{c.unregisterReceiver(r)}}}
 val hidden=remember(tick){p.getStringSet("hidden",emptySet()).orEmpty()};val dumb=remember(tick){p.getBoolean("dumb_mode",false)};val allow=remember(tick){p.getStringSet("dumb",emptySet()).orEmpty()};val visible=apps.filter{it.packageName !in hidden&&(!dumb||it.packageName in allow)}
 UbuntuTheme{Box(Modifier.fillMaxSize()){Wallpaper(p,dumb);HomeShell(visible,apps,p,dumb,{drawer=true},{settings=true},pickFile){tick++};if(drawer)AppDrawer(visible,q,{q=it},{drawer=false},{settings=true},p){tick++};if(settings)LauncherSettings(apps,p,{settings=false},{tick++},pickPhotos,pickFile,{(c as? MainActivity)?.backupOut?.launch("ubuntu-launcher-backup.json")},{(c as? MainActivity)?.backupIn?.launch(arrayOf("application/json","text/plain"))});if(!unlocked&&p.getBoolean("lock_enabled",false))LockOverlay(p){unlocked=true}}}
}

@Composable fun Wallpaper(p:android.content.SharedPreferences,dumb:Boolean){val key=if(dumb)"wall_dumb" else "wall_regular";val uris=p.getStringSet(key,emptySet()).orEmpty().toList();var idx by remember(uris){mutableIntStateOf(0)};val interval=p.getInt(if(dumb)"slide_dumb" else "slide_regular",15).coerceAtLeast(3);if(uris.size>1)LaunchedEffect(uris,interval){while(true){delay(interval*1000L);idx=(idx+1)%uris.size}};val c=LocalContext.current;val bm=remember(uris,idx){uris.getOrNull(idx)?.let{u->runCatching{c.contentResolver.openInputStream(Uri.parse(u))?.use{BitmapFactory.decodeStream(it)}?.asImageBitmap()}.getOrNull()}};if(bm!=null)Image(bm,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)else Box(Modifier.fillMaxSize().background(Aubergine2));Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=.18f)))}

@Composable fun HomeShell(visible:List<AppItem>,all:List<AppItem>,p:android.content.SharedPreferences,dumb:Boolean,drawer:()->Unit,settings:()->Unit,pickFile:()->Unit,changed:()->Unit){
 val landscape=LocalConfiguration.current.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE
 val pos=p.getString("taskbar_pos",if(landscape)"left" else "bottom")?:"bottom"
 val hide=p.getBoolean("taskbar_hide",false);var autoShown by remember{mutableStateOf(true)};val auto=p.getBoolean("taskbar_auto",false)
 val autoSeconds=p.getInt("taskbar_auto_seconds",3).coerceAtLeast(1)
 val gestures=p.getBoolean("swipe_actions",false)
 val content:@Composable()->Unit={DesktopContent(visible,all,p,dumb,drawer,settings,pickFile,changed)}
 if(auto) LaunchedEffect(pos,autoShown,autoSeconds){if(autoShown){delay(autoSeconds*1000L);autoShown=false}}
 var drag by remember{mutableFloatStateOf(0f)}
 val swipeModifier=if(gestures) Modifier.pointerInput(Unit){detectHorizontalDragGestures(onDragStart={drag=0f},onHorizontalDrag={_,amount->drag+=amount},onDragEnd={if(drag>120f)drawer() else if(drag< -120f)settings();drag=0f})} else Modifier
 Column(Modifier.fillMaxSize().then(swipeModifier).statusBarsPadding().navigationBarsPadding()){
  if(!hide&&(!auto||autoShown)&&pos=="top")Taskbar(all,p,drawer,changed,false,auto){autoShown=!autoShown}
  Row(Modifier.weight(1f)){
   if(!hide&&(!auto||autoShown)&&pos=="left")Taskbar(all,p,drawer,changed,true,auto){autoShown=!autoShown}
   Box(Modifier.weight(1f)){content();if(auto&&!autoShown)TaskbarRevealDot(pos){autoShown=true}}
   if(!hide&&(!auto||autoShown)&&pos=="right")Taskbar(all,p,drawer,changed,true,auto){autoShown=!autoShown}
  }
  if(!hide&&(!auto||autoShown)&&pos=="bottom")Taskbar(all,p,drawer,changed,false,auto){autoShown=!autoShown}
 }
}
@Composable fun BoxScope.TaskbarRevealDot(pos:String,show:()->Unit){val a=when(pos){"top"->Alignment.TopCenter;"left"->Alignment.CenterStart;"right"->Alignment.CenterEnd;else->Alignment.BottomCenter};Box(Modifier.align(a).padding(5.dp).size(14.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Orange).clickable{show()})}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun DesktopContent(visible:List<AppItem>,all:List<AppItem>,p:android.content.SharedPreferences,dumb:Boolean,drawer:()->Unit,settings:()->Unit,pickFile:()->Unit,changed:()->Unit){
 val c=LocalContext.current;val cols=p.getInt("desktop_cols",4).coerceIn(2,8);val secondaryEnabled=p.getBoolean("secondary_page_enabled",false);var page by remember{mutableStateOf("main")};if(!secondaryEnabled)page="main";val suffix=if(page=="secondary")"secondary" else "main";val files=p.getStringSet("desktop_files_$suffix",emptySet()).orEmpty();val links=p.getStringSet("desktop_links_$suffix",emptySet()).orEmpty();val weather=p.getStringSet("weather_app",emptySet()).orEmpty().firstOrNull();val showWeather=p.getBoolean("show_weather",true);var addLink by remember{mutableStateOf(false)};var url by remember{mutableStateOf("")};var label by remember{mutableStateOf("")};var manage by remember{mutableStateOf<Pair<String,String>?>(null)}
 var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
 LaunchedEffect(Unit){
  while(true){
   now=System.currentTimeMillis()
   delay(1000L-(now%1000L))
  }
 }
 Column(Modifier.fillMaxSize().padding(16.dp)){Column{if(p.getBoolean("show_clock",true)){val cs=p.getInt("clock_size",22).sp;val cc=runCatching{Color(android.graphics.Color.parseColor(p.getString("clock_color","#FFFFFF")))}.getOrDefault(Color.White);val ff=when(p.getString("clock_font","sans")){"serif"->FontFamily.Serif;"mono"->FontFamily.Monospace;"cursive"->FontFamily.Cursive;else->FontFamily.SansSerif};Text(SimpleDateFormat("EEE, MMM d   HH:mm",Locale.getDefault()).format(Date(now)),color=cc,fontSize=cs,fontFamily=ff)};p.getString("custom_text","")?.takeIf{it.isNotBlank()}?.let{Text(it,color=Color.White.copy(alpha=.85f))}}
 Spacer(Modifier.height(12.dp));LazyVerticalGrid(GridCells.Fixed(cols),Modifier.weight(1f)){
  items(files.toList(),key={it}){entry->val z=entry.split("|",limit=2);FileShortcutTile(Uri.parse(z[0]),z.getOrElse(1){"File"},{runCatching{c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(z[0])).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))}},{manage="desktop_files_$suffix" to entry})}
  items(links.toList(),key={it}){entry->val z=entry.split("|",limit=2);WebsiteShortcutTile(z[0],z.getOrElse(1){"Website"},{runCatching{c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(z[0])))}},{manage="desktop_links_$suffix" to entry})}
  if(page=="main"&&showWeather)weather?.let{pkg->all.firstOrNull{it.packageName==pkg}?.let{a->item{ShortcutTile(Icons.Default.Cloud,"Weather"){launch(c,a)}}}}
 }
 if(secondaryEnabled)Row{TextButton({page=if(page=="main")"secondary" else "main"}){Text(if(page=="main")"Page 2" else "Main page")}}
 if(addLink)AlertDialog(onDismissRequest={addLink=false},title={Text("Pin website to ${if(page=="secondary")"Page 2" else "Main page"}")},text={Column{OutlinedTextField(label,{label=it},label={Text("Name")});OutlinedTextField(url,{url=it},label={Text("https://...")})}},confirmButton={TextButton({if(url.startsWith("http")){val key="desktop_links_$suffix";val set=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.add("$url|${label.ifBlank{"Website"}}");p.edit().putStringSet(key,set).apply();changed()};addLink=false}){Text("Pin")}},dismissButton={TextButton({addLink=false}){Text("Cancel")}})
 manage?.let{(key,entry)->ShortcutManageDialog(p,key,entry,{manage=null;changed()},{manage=null})}
 }}
@Composable fun ShortcutManageDialog(p:android.content.SharedPreferences,key:String,entry:String,done:()->Unit,cancel:()->Unit){val parts=entry.split("|",limit=2);var name by remember(entry){mutableStateOf(parts.getOrElse(1){"Shortcut"})};AlertDialog(onDismissRequest=cancel,title={Text("Manage shortcut")},text={OutlinedTextField(name,{name=it},label={Text("Name")})},confirmButton={Row{TextButton({val set=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.remove(entry);set.add("${parts[0]}|${name.ifBlank{"Shortcut"}}");p.edit().putStringSet(key,set).apply();done()}){Text("Rename")};TextButton({val set=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.remove(entry);p.edit().putStringSet(key,set).apply();done()}){Text("Remove",color=MaterialTheme.colorScheme.error)}}},dismissButton={TextButton(cancel){Text("Cancel")}})}
@OptIn(ExperimentalFoundationApi::class) @Composable fun FileShortcutTile(uri:Uri,label:String,click:()->Unit,manage:()->Unit){val c=LocalContext.current;val bm=remember(uri){runCatching{c.contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it)}?.asImageBitmap()}.getOrNull()};Box(Modifier.padding(8.dp).aspectRatio(1f).clip(RoundedCornerShape(14.dp)).combinedClickable(onClick=click,onLongClick=manage)){if(bm!=null)Image(bm,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)else Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=.38f))){Icon(Icons.Default.Description,null,tint=Color.White,modifier=Modifier.align(Alignment.Center).size(44.dp))};Box(Modifier.fillMaxWidth().align(Alignment.BottomCenter).background(Color.Black.copy(alpha=.58f)).padding(5.dp)){Text(label,color=Color.White,maxLines=2)}}}
@OptIn(ExperimentalFoundationApi::class)
@Composable fun WebsiteShortcutTile(url:String,label:String,click:()->Unit,manage:()->Unit){
 // Keep a real Android WebView/AndroidView for standards-compliant page loading and
 // favicon discovery, but present the site's favicon rather than a miniature webpage.
 var webView by remember(url){mutableStateOf<WebView?>(null)}
 var favicon by remember(url){mutableStateOf<ImageBitmap?>(null)}
 DisposableEffect(url){
  onDispose{
   val w=webView; webView=null
   if(w!=null){
    val dispose={runCatching{w.stopLoading();w.loadUrl("about:blank");w.clearHistory();w.removeAllViews();w.destroy()}}
    if(Looper.myLooper()==Looper.getMainLooper())dispose() else Handler(Looper.getMainLooper()).post{dispose()}
   }
  }
 }
 Box(Modifier.padding(8.dp).aspectRatio(1f).clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(alpha=.30f))){
  AndroidView(
   modifier=Modifier.size(1.dp).align(Alignment.TopStart),
   factory={ctx->
    check(Looper.myLooper()==Looper.getMainLooper()){"WebView must be created on the main thread"}
    WebView(ctx).apply{
     webView=this
     webViewClient=WebViewClient()
     webChromeClient=object:WebChromeClient(){override fun onReceivedIcon(view:WebView?,icon:Bitmap?){if(icon!=null)favicon=icon.asImageBitmap()}}
     settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.cacheMode=WebSettings.LOAD_DEFAULT;settings.loadsImagesAutomatically=true
     isVerticalScrollBarEnabled=false;isHorizontalScrollBarEnabled=false
     loadUrl(url)
    }
   },
   update={w->
    check(Looper.myLooper()==Looper.getMainLooper()){"WebView update must run on the main thread"}
    webView=w;if(w.url!=url)w.loadUrl(url)
   }
  )
  if(favicon!=null) Image(favicon!!,label,Modifier.align(Alignment.Center).fillMaxSize(.62f),contentScale=ContentScale.Fit)
  else Icon(Icons.Default.Language,"Website",tint=Color.White,modifier=Modifier.align(Alignment.Center).fillMaxSize(.48f))
  Box(Modifier.fillMaxSize().combinedClickable(onClick=click,onLongClick=manage))
  Box(Modifier.fillMaxWidth().align(Alignment.BottomCenter).background(Color.Black.copy(alpha=.62f)).padding(5.dp)){Text(label,color=Color.White,maxLines=2)}
 }
}
@Composable fun ShortcutTile(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,click:()->Unit){Column(Modifier.padding(8.dp).clickable(onClick=click),horizontalAlignment=Alignment.CenterHorizontally){Icon(icon,null,tint=Color.White,modifier=Modifier.size(44.dp));Text(label,color=Color.White,maxLines=2)}}
@OptIn(ExperimentalFoundationApi::class) @Composable fun AppTile(a:AppItem,onClick:()->Unit,onLong:(()->Unit)?=null){Column(Modifier.padding(7.dp).clip(RoundedCornerShape(12.dp)).combinedClickable(onClick=onClick,onLongClick=onLong).padding(7.dp),horizontalAlignment=Alignment.CenterHorizontally){Image(a.icon.toBitmap(96,96).asImageBitmap(),a.label,Modifier.size(48.dp));Text(a.label,color=Color.White,maxLines=1,style=MaterialTheme.typography.labelMedium)}}
fun toggleSet(p:android.content.SharedPreferences,key:String,value:String){val s=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();if(!s.add(value))s.remove(value);p.edit().putStringSet(key,s).apply()}

@Composable fun Taskbar(all:List<AppItem>,p:android.content.SharedPreferences,drawer:()->Unit,changed:()->Unit,vertical:Boolean,auto:Boolean,toggle:()->Unit){
 val c=LocalContext.current;val size=p.getInt("taskbar_size",64).coerceIn(44,110).dp;val pins=p.getStringSet("pins",emptySet()).orEmpty().mapNotNull{x->all.firstOrNull{a->a.packageName==x}};val mod=if(vertical)Modifier.width(size).fillMaxHeight() else Modifier.height(size).fillMaxWidth();Surface(mod,color=Color.Black.copy(alpha=.48f)){if(vertical)LazyColumn(horizontalAlignment=Alignment.CenterHorizontally){item{IconButton(drawer){Icon(Icons.Default.Apps,"Apps",tint=Color.White)}};items(pins,key={it.packageName}){a->Image(a.icon.toBitmap(72,72).asImageBitmap(),a.label,Modifier.padding(5.dp).size(36.dp).clickable{launch(c,a)})};if(auto)item{IconButton(toggle){Icon(Icons.Default.UnfoldLess,"Auto hide",tint=Color.White)}}}else LazyRow(verticalAlignment=Alignment.CenterVertically){item{IconButton(drawer){Icon(Icons.Default.Apps,"Apps",tint=Color.White)}};items(pins,key={it.packageName}){a->Image(a.icon.toBitmap(72,72).asImageBitmap(),a.label,Modifier.padding(horizontal=7.dp).size(36.dp).clickable{launch(c,a)})};if(auto)item{IconButton(toggle){Icon(Icons.Default.UnfoldLess,"Auto hide",tint=Color.White)}}}}}

val settingItems=listOf(SettingItem("Wi-Fi","Networks and Internet",Settings.ACTION_WIFI_SETTINGS),SettingItem("Bluetooth","Connected devices",Settings.ACTION_BLUETOOTH_SETTINGS),SettingItem("Display","Brightness and display",Settings.ACTION_DISPLAY_SETTINGS),SettingItem("Sound","Volume and sound",Settings.ACTION_SOUND_SETTINGS),SettingItem("Storage","Device storage",Settings.ACTION_INTERNAL_STORAGE_SETTINGS),SettingItem("Accessibility","Accessibility",Settings.ACTION_ACCESSIBILITY_SETTINGS),SettingItem("System settings","All Android settings",Settings.ACTION_SETTINGS))
@Composable
fun AppDrawer(
    apps: List<AppItem>,
    q: String,
    setQ: (String) -> Unit,
    close: () -> Unit,
    settings: () -> Unit,
    p: android.content.SharedPreferences,
    changed: () -> Unit
) {
    val context = LocalContext.current
    val grid = p.getBoolean("app_grid", true)
    val results = apps.filter {
        it.label.contains(q, ignoreCase = true) ||
            it.packageName.contains(q, ignoreCase = true)
    }
    Surface(modifier = Modifier.fillMaxSize(), color = Aubergine.copy(alpha = .98f)) {
        Column(
            modifier = Modifier.statusBarsPadding().navigationBarsPadding().padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = settings) {
                    Icon(Icons.Default.Settings, contentDescription = "Launcher settings", tint = Color.White)
                }
                OutlinedTextField(
                    value = q,
                    onValueChange = setQ,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("Search apps and settings") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
                )
                IconButton(onClick = close) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }
            if (q.isNotBlank()) {
                settingItems.filter {
                    it.label.contains(q, ignoreCase = true) ||
                        it.subtitle.contains(q, ignoreCase = true)
                }.forEach { setting ->
                    ListItem(
                        headlineContent = { Text(setting.label) },
                        supportingContent = { Text(setting.subtitle) },
                        modifier = Modifier.clickable { openSetting(context, setting.action) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            if (grid) {
                LazyVerticalGrid(columns = GridCells.Adaptive(90.dp)) {
                    items(results, key = { it.packageName + it.activityName }) { app ->
                        AppTile(
                            app,
                            onClick = { launch(context, app) },
                            onLong = { toggleSet(p, "pins", app.packageName); changed() }
                        )
                    }
                }
            } else {
                LazyColumn {
                    items(results, key = { it.packageName + it.activityName }) { app ->
                        ListItem(
                            headlineContent = { Text(app.label) },
                            supportingContent = { Text(app.packageName) },
                            leadingContent = {
                                Image(
                                    app.icon.toBitmap(64, 64).asImageBitmap(),
                                    contentDescription = null,
                                    modifier = Modifier.size(38.dp)
                                )
                            },
                            modifier = Modifier.clickable { launch(context, app) }
                        )
                    }
                }
            }
        }
    }
}

@Composable fun LauncherSettings(apps:List<AppItem>,p:android.content.SharedPreferences,close:()->Unit,changed:()->Unit,pickPhotos:(Boolean)->Unit,pickFile:()->Unit,exportBackup:()->Unit,importBackup:()->Unit){val c=LocalContext.current;var page by remember{mutableStateOf("main")};var tick by remember{mutableIntStateOf(0)};var addWebsite by remember{mutableStateOf(false)};var websiteUrl by remember{mutableStateOf("")};var websiteLabel by remember{mutableStateOf("")};fun ch(){tick++;changed()};Surface(Modifier.fillMaxSize(),color=Warm){Column(Modifier.statusBarsPadding().navigationBarsPadding()){Row(Modifier.fillMaxWidth().background(Aubergine).padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton({if(page=="main")close()else page="main"}){Icon(Icons.AutoMirrored.Filled.ArrowBack,"Back",tint=Color.White)};Text(pageTitle(page),color=Color.White,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)};when(page){
"hidden"->AppSelector(apps,p,"hidden",true){ch()};"dumbapps"->AppSelector(apps,p,"dumb",false){ch()};"taskbarapps"->AppSelector(apps,p,"pins",false){ch()};"weather"->WeatherSettings(apps,p){ch()};"appearance"->AppearanceSettings(p,pickPhotos){ch()};"taskbar"->TaskbarSettings(p){ch()};"apps"->AppsSettings(p){ch()};"lock"->LockSettings(p){ch()};"licenses"->LicenseScreen();"about"->AboutScreen();
"desktop"->LazyColumn{item{SettingRow(Icons.Default.Description,"Pin file","Choose a file for the selected shortcut destination"){pickFile()}};item{SettingRow(Icons.Default.AddLink,"Add website","Create a website shortcut on the selected desktop page"){addWebsite=true}};item{SettingRow(Icons.Default.ViewSidebar,"Taskbar","Position, size, hide, auto-hide and delay"){page="taskbar"}};item{SettingRow(Icons.Default.PushPin,"Taskbar pinned apps","Choose any number of apps for the scrollable taskbar"){page="taskbarapps"}};item{val second=p.getBoolean("secondary_page_enabled",false);SettingRow(Icons.Default.Layers,"Secondary desktop page","Optional second page for file and website shortcuts",second){p.edit().putBoolean("secondary_page_enabled",!second).apply();ch()}};item{val target=p.getString("shortcut_target_page","main")?:"main";SettingRow(Icons.Default.AddLink,"Shared shortcut destination","New shared files/links go to ${if(target=="secondary")"Page 2" else "Main page"}"){p.edit().putString("shortcut_target_page",if(target=="main")"secondary" else "main").apply();ch()}};item{SettingRow(Icons.Default.Cloud,"Weather app","Choose the app opened by the weather shortcut"){page="weather"}};item{val sw=p.getBoolean("swipe_actions",false);SettingRow(Icons.Default.Swipe,"Swipe actions","Swipe right for Applications; swipe left for Settings",sw){p.edit().putBoolean("swipe_actions",!sw).apply();ch()}}};
"dumbsettings"->LazyColumn{item{val d=p.getBoolean("dumb_mode",false);SettingRow(Icons.Default.PhoneAndroid,"Dumb Phone Mode",if(d)"Enabled" else "Disabled",d){p.edit().putBoolean("dumb_mode",!d).apply();ch()}};item{SettingRow(Icons.Default.Checklist,"Choose Dumb Phone apps","Manage accessible apps"){page="dumbapps"}};item{val f=p.getBoolean("dumb_notification_filter",false);SettingRow(Icons.Default.NotificationsOff,"Notification filter","Block notifications from apps outside the Dumb Phone allowlist",f){p.edit().putBoolean("dumb_notification_filter",!f).apply();ch()}};item{SettingRow(Icons.Default.Notifications,"Notification access","Required for Dumb Phone notification filtering"){openSetting(c,Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)}}};
else->LazyColumn{item{SettingRow(Icons.Default.Home,"Make default Home","Set Ubuntu Launcher as Android Home"){(c as? MainActivity)?.requestHome()}};item{SettingRow(Icons.Default.Wallpaper,"Display settings","Wallpaper, clock/date, colors, fonts and desktop appearance"){page="appearance"}};item{SettingRow(Icons.Default.DesktopWindows,"Desktop settings","Taskbar, pinned apps, secondary page, shared shortcuts and weather"){page="desktop"}};item{SettingRow(Icons.Default.PhoneAndroid,"Dumb Phone Settings","Mode, app allowlist and notification management"){page="dumbsettings"}};item{SettingRow(Icons.Default.Apps,"Applications list","Grid/list presentation"){page="apps"}};item{SettingRow(Icons.Default.Lock,"Ubuntu-style lock layer","PIN/password and lock-screen appearance"){page="lock"}};item{SettingRow(Icons.Default.VisibilityOff,"Hidden apps","Only accessible through launcher settings"){page="hidden"}};item{SettingRow(Icons.Default.Save,"Launcher backup","Download a complete launcher settings backup"){exportBackup()}};item{SettingRow(Icons.Default.Restore,"Restore launcher backup","Upload a launcher backup and restore settings"){importBackup()}};item{SettingRow(Icons.Default.Settings,"Android Settings","Open system settings"){openSetting(c,Settings.ACTION_SETTINGS)}};item{SettingRow(Icons.Default.Description,"Licenses","GNU AGPLv3"){page="licenses"}};item{SettingRow(Icons.Default.Info,"About","Version and developer information"){page="about"}}}}}
 if(addWebsite)AlertDialog(onDismissRequest={addWebsite=false},title={Text("Add website")},text={Column{OutlinedTextField(websiteLabel,{websiteLabel=it},label={Text("Name")});OutlinedTextField(websiteUrl,{websiteUrl=it},label={Text("Website URL")})}},confirmButton={TextButton({val normalized=if(websiteUrl.startsWith("https://")||websiteUrl.startsWith("http://"))websiteUrl else "https://$websiteUrl";val uri=runCatching{Uri.parse(normalized)}.getOrNull();if(uri?.host!=null){val target=if(p.getString("shortcut_target_page","main")=="secondary" && p.getBoolean("secondary_page_enabled",false))"secondary" else "main";val key="desktop_links_$target";val links=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();links.add("$normalized|${websiteLabel.ifBlank{uri.host?:"Website"}}");p.edit().putStringSet(key,links).apply();ch()};addWebsite=false;websiteUrl="";websiteLabel=""}){Text("Add")}},dismissButton={TextButton({addWebsite=false}){Text("Cancel")}})
 }}

fun pageTitle(p:String)=when(p){"hidden"->"Hidden applications";"dumbapps"->"Dumb Phone applications";"taskbarapps"->"Taskbar pinned applications";"weather"->"Weather";"appearance"->"Display settings";"desktop"->"Desktop settings";"dumbsettings"->"Dumb Phone Settings";"taskbar"->"Taskbar";"apps"->"Applications list";"lock"->"Lock screen";"licenses"->"Licenses";"about"->"About";else->"Ubuntu Launcher Settings"}

@Composable fun SettingRow(icon:androidx.compose.ui.graphics.vector.ImageVector,title:String,sub:String,switch:Boolean?=null,click:()->Unit){Row(Modifier.fillMaxWidth().clickable(onClick=click).padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Orange);Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.SemiBold);Text(sub,color=Color.Gray,style=MaterialTheme.typography.bodySmall)};if(switch!=null)Switch(switch,{click()})}}

@Composable fun AppearanceSettings(p:android.content.SharedPreferences,pick:(Boolean)->Unit,changed:()->Unit){var cols by remember{mutableIntStateOf(p.getInt("desktop_cols",4))};var clock by remember{mutableStateOf(p.getBoolean("show_clock",true))};var clockSize by remember{mutableIntStateOf(p.getInt("clock_size",22))};var clockColor by remember{mutableStateOf(p.getString("clock_color","#FFFFFF")?:"#FFFFFF")};var clockFont by remember{mutableStateOf(p.getString("clock_font","sans")?:"sans")};LazyColumn{item{Text("Regular launcher wallpaper",Modifier.padding(16.dp),fontWeight=FontWeight.Bold);Row(Modifier.padding(horizontal=16.dp)){Button({pick(false)}){Text("Choose photos")};Spacer(Modifier.width(8.dp));OutlinedButton({p.edit().remove("wall_regular").apply();changed()}){Text("Remove wallpaper")}};Text("Removing the wallpaper restores the default Ubuntu display.",Modifier.padding(16.dp),color=Color.Gray)};item{Text("Dumb Phone wallpaper",Modifier.padding(16.dp),fontWeight=FontWeight.Bold);Row(Modifier.padding(horizontal=16.dp)){Button({pick(true)}){Text("Choose photos")};Spacer(Modifier.width(8.dp));OutlinedButton({p.edit().remove("wall_dumb").apply();changed()}){Text("Remove wallpaper")}}};item{Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("Show clock and date",Modifier.weight(1f));Switch(clock,{clock=it;p.edit().putBoolean("show_clock",it).apply();changed()})}};item{Text("Clock/date size: $clockSize sp",Modifier.padding(16.dp));Slider(clockSize.toFloat(),{clockSize=it.toInt();p.edit().putInt("clock_size",clockSize).apply();changed()},valueRange=12f..64f,modifier=Modifier.padding(horizontal=16.dp))};item{OutlinedTextField(clockColor,{clockColor=it;p.edit().putString("clock_color",it).apply();changed()},label={Text("Clock/date color (#RRGGBB)")},modifier=Modifier.fillMaxWidth().padding(16.dp))};item{Text("Clock/date font",Modifier.padding(horizontal=16.dp),fontWeight=FontWeight.Bold);Row(Modifier.padding(12.dp)){listOf("sans","serif","mono","cursive").forEach{x->FilterChip(clockFont==x,{clockFont=x;p.edit().putString("clock_font",x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(3.dp))}}};item{Text("Desktop columns: $cols",Modifier.padding(16.dp));Slider(cols.toFloat(),{cols=it.toInt().coerceIn(2,8);p.edit().putInt("desktop_cols",cols).apply();changed()},valueRange=2f..8f,steps=5,modifier=Modifier.padding(horizontal=16.dp))};item{var custom by remember{mutableStateOf(p.getString("custom_text","")?:"")};OutlinedTextField(custom,{custom=it;p.edit().putString("custom_text",it).apply();changed()},label={Text("Desktop custom text")},modifier=Modifier.fillMaxWidth().padding(16.dp))};item{Text("Border design",Modifier.padding(16.dp),fontWeight=FontWeight.Bold);Row(Modifier.padding(horizontal=12.dp)){listOf("none","rounded","ubuntu").forEach{x->FilterChip(p.getString("border_style","rounded")==x,{p.edit().putString("border_style",x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(3.dp))}}}}}

@Composable fun TaskbarSettings(p:android.content.SharedPreferences,changed:()->Unit){var pos by remember{mutableStateOf(p.getString("taskbar_pos","bottom")?:"bottom")};var size by remember{mutableIntStateOf(p.getInt("taskbar_size",64))};var hide by remember{mutableStateOf(p.getBoolean("taskbar_hide",false))};var auto by remember{mutableStateOf(p.getBoolean("taskbar_auto",false))};var seconds by remember{mutableStateOf(p.getInt("taskbar_auto_seconds",3).toString())};LazyColumn{item{Text("Position",Modifier.padding(16.dp),fontWeight=FontWeight.Bold);Row(Modifier.padding(horizontal=12.dp)){listOf("left","right","top","bottom").forEach{x->FilterChip(pos==x,{pos=x;p.edit().putString("taskbar_pos",x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(3.dp))}}};item{Text("Size: $size dp",Modifier.padding(16.dp));Slider(size.toFloat(),{size=it.toInt();p.edit().putInt("taskbar_size",size).apply();changed()},valueRange=44f..110f,modifier=Modifier.padding(horizontal=16.dp))};item{SettingRow(Icons.Default.VisibilityOff,"Hide taskbar","Never show the taskbar",hide){hide=!hide;p.edit().putBoolean("taskbar_hide",hide).apply();changed()}};item{SettingRow(Icons.Default.UnfoldLess,"Auto hide","Hide the taskbar after the configured delay",auto){auto=!auto;p.edit().putBoolean("taskbar_auto",auto).apply();changed()}};if(auto)item{OutlinedTextField(seconds,{v->if(v.all{it.isDigit()}&&v.length<=5){seconds=v;v.toIntOrNull()?.coerceAtLeast(1)?.let{p.edit().putInt("taskbar_auto_seconds",it).apply();changed()}}},label={Text("Auto-hide duration (seconds)")},singleLine=true,modifier=Modifier.fillMaxWidth().padding(16.dp));Text("A small orange dot remains at the taskbar edge. Tap it to reveal the hidden taskbar.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray)}}}}
@Composable fun AppsSettings(p:android.content.SharedPreferences,changed:()->Unit){val grid=p.getBoolean("app_grid",true);Column{SettingRow(Icons.Default.GridView,"Grid view","Show apps as icons in a grid",grid){p.edit().putBoolean("app_grid",true).apply();changed()};SettingRow(Icons.Default.ViewList,"List view","Show apps in a detailed list",!grid){p.edit().putBoolean("app_grid",false).apply();changed()}}}
@Composable fun LockSettings(p:android.content.SharedPreferences,changed:()->Unit){var enabled by remember{mutableStateOf(p.getBoolean("lock_enabled",false))};var pass by remember{mutableStateOf("")};Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("Enable launcher lock layer",Modifier.weight(1f));Switch(enabled,{enabled=it;p.edit().putBoolean("lock_enabled",it).apply();changed()})};OutlinedTextField(pass,{pass=it},label={Text("New PIN or password")},modifier=Modifier.fillMaxWidth());Button({if(pass.isNotBlank()){p.edit().putString("lock_hash",hash(pass)).apply();pass="";changed()}},Modifier.padding(top=10.dp)){Text("Save PIN/password")};Text("Android's system keyguard remains the authoritative device lock. This launcher lock protects the launcher UI but does not replace Android secure lock-screen enforcement.",Modifier.padding(top=18.dp),color=Color.Gray)}}
@Composable fun LockOverlay(p:android.content.SharedPreferences,unlock:()->Unit){var v by remember{mutableStateOf("")};var now by remember{mutableLongStateOf(System.currentTimeMillis())};LaunchedEffect(Unit){while(true){now=System.currentTimeMillis();delay(1000L-(now%1000L))}};Surface(Modifier.fillMaxSize(),color=Aubergine){Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(Icons.Default.Lock,null,tint=Orange,modifier=Modifier.size(72.dp));Text(SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date(now)),color=Color.White,style=MaterialTheme.typography.displayMedium);Text(DateFormat.getDateInstance().format(Date(now)),color=Color.White);OutlinedTextField(v,{v=it},label={Text("PIN or password")},modifier=Modifier.padding(top=24.dp));Button({if(hash(v)==p.getString("lock_hash",""))unlock()},Modifier.padding(top=12.dp)){Text("Unlock")}}}}

@Composable fun WeatherSettings(apps:List<AppItem>,p:android.content.SharedPreferences,changed:()->Unit){
 var show by remember{mutableStateOf(p.getBoolean("show_weather",true))}
 Column{
  SettingRow(Icons.Default.Cloud,"Show weather emblem","Show or hide the selected weather app emblem on the main desktop",show){show=!show;p.edit().putBoolean("show_weather",show).apply();changed()}
  Text("Weather application",Modifier.padding(start=16.dp,top=14.dp,bottom=6.dp),fontWeight=FontWeight.Bold)
  Box(Modifier.weight(1f)){AppSelector(apps,p,"weather_app",false,single=true,changed=changed)}
 }
}
@Composable fun AppSelector(apps:List<AppItem>,p:android.content.SharedPreferences,key:String,launchable:Boolean,single:Boolean=false,changed:()->Unit){val c=LocalContext.current;var selected by remember{mutableStateOf(p.getStringSet(key,emptySet()).orEmpty())};LazyColumn{items(apps,key={it.packageName+it.activityName}){a->Row(Modifier.fillMaxWidth().clickable{val s=if(single)mutableSetOf<String>() else selected.toMutableSet();if(single)s.add(a.packageName) else if(!s.add(a.packageName))s.remove(a.packageName);selected=s;p.edit().putStringSet(key,s).apply();changed()}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Image(a.icon.toBitmap(64,64).asImageBitmap(),a.label,Modifier.size(38.dp));Spacer(Modifier.width(12.dp));Text(a.label,Modifier.weight(1f));if(launchable)IconButton({launch(c,a)}){Icon(Icons.Default.OpenInNew,"Open")};Checkbox(a.packageName in selected,null)}}}}
@Composable fun LicenseScreen(){val c=LocalContext.current;val t=remember{runCatching{c.resources.openRawResource(R.raw.agpl_3_0).bufferedReader().use{it.readText()}}.getOrElse{"Unable to load license."}};LazyColumn(Modifier.padding(18.dp)){item{Text("GNU Affero General Public License",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge,color=Aubergine);Text("Version 3, 19 November 2007",color=Color.Gray);Spacer(Modifier.height(16.dp));Text(t,style=MaterialTheme.typography.bodySmall)}}}
@Composable fun AboutScreen(){Column(Modifier.padding(18.dp)){Text("Ubuntu Launcher",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.headlineSmall,color=Aubergine);Text("Version 1.0.3 debug");Spacer(Modifier.height(16.dp));Text("Developer",fontWeight=FontWeight.Bold);Text("Maclean Of Duart Enterprises Corp");Text("com.macleanofduartenterprises.ubuntulauncher");Spacer(Modifier.height(16.dp));Text("Licensed under GNU AGPLv3. Ubuntu is a registered trademark of Canonical Ltd. This independent launcher is not endorsed by or affiliated with Canonical.",color=Color.DarkGray)}}
@Composable fun UbuntuTheme(content:@Composable()->Unit){MaterialTheme(colorScheme=lightColorScheme(primary=Orange,secondary=Aubergine,surface=Warm),content=content)}
