package com.macleanofduartenterprises.ubuntulauncher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationFilterService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        if (!prefs.getBoolean("dumb_mode", false) || !prefs.getBoolean("dumb_notification_filter", false)) return
        val allowed = prefs.getStringSet("dumb", emptySet()).orEmpty()
        if (sbn.packageName !in allowed && sbn.packageName != packageName) cancelNotification(sbn.key)
    }
}
