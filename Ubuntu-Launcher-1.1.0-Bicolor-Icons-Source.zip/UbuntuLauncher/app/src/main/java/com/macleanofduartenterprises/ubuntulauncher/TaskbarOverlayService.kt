package com.macleanofduartenterprises.ubuntulauncher

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import kotlin.math.roundToInt

internal const val TASKBAR_OVERLAY_ENABLED = "taskbar_overlay_enabled"
internal const val TASKBAR_OVERLAY_KEYBOARD_PRIORITY = "taskbar_overlay_keyboard_priority"
internal const val DEFAULT_TASKBAR_OPACITY_PERCENT = 48

internal fun shouldDisplayTaskbarOverlay(
    enabled: Boolean,
    permissionGranted: Boolean,
    launcherVisible: Boolean,
    hiddenForOrientation: Boolean
): Boolean = enabled && permissionGranted && !launcherVisible && !hiddenForOrientation

internal fun shouldScheduleTaskbarOverlayAutoHide(
    autoHide: Boolean,
    launcherVisible: Boolean,
    destroyed: Boolean
): Boolean = autoHide && !launcherVisible && !destroyed

internal fun taskbarAutoHideDelayMillis(seconds: Int): Long =
    seconds.coerceAtLeast(1).toLong() * 1000L

internal object TaskbarOverlayController {
    fun hasPermission(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun openPermissionSettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
        if (context !is android.app.Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun sync(
        context: Context,
        preferences: SharedPreferences,
        launcherVisible: Boolean
    ) {
        if (!preferences.getBoolean(TASKBAR_OVERLAY_ENABLED, false) || !hasPermission(context)) {
            context.stopService(Intent(context, TaskbarOverlayService::class.java))
            return
        }
        val intent = Intent(context, TaskbarOverlayService::class.java)
            .setAction(TaskbarOverlayService.ACTION_SYNC)
            .putExtra(TaskbarOverlayService.EXTRA_LAUNCHER_VISIBLE, launcherVisible)
        runCatching { ContextCompat.startForegroundService(context, intent) }
    }

    fun setLauncherVisible(
        context: Context,
        preferences: SharedPreferences,
        visible: Boolean
    ) {
        if (!preferences.getBoolean(TASKBAR_OVERLAY_ENABLED, false) || !hasPermission(context)) return
        val intent = Intent(context, TaskbarOverlayService::class.java)
            .setAction(TaskbarOverlayService.ACTION_LAUNCHER_VISIBILITY)
            .putExtra(TaskbarOverlayService.EXTRA_LAUNCHER_VISIBLE, visible)
        runCatching { ContextCompat.startForegroundService(context, intent) }
    }
}

class TaskbarOverlayService : Service() {
    companion object {
        const val ACTION_SYNC = "com.macleanofduartenterprises.ubuntulauncher.action.SYNC_TASKBAR_OVERLAY"
        const val ACTION_LAUNCHER_VISIBILITY = "com.macleanofduartenterprises.ubuntulauncher.action.LAUNCHER_VISIBILITY"
        const val ACTION_STOP = "com.macleanofduartenterprises.ubuntulauncher.action.STOP_TASKBAR_OVERLAY"
        const val EXTRA_LAUNCHER_VISIBLE = "launcher_visible"
        private const val CHANNEL_ID = "taskbar_overlay"
        private const val NOTIFICATION_ID = 104007
    }

    private data class OverlayConfig(
        val position: String,
        val direction: String,
        val sizeDp: Int,
        val hidden: Boolean,
        val autoHide: Boolean,
        val autoHideSeconds: Int,
        val placeholderStyle: TaskbarPlaceholderStyle,
        val opacityPercent: Int,
        val keyboardPriority: Boolean
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val appLoader = Executors.newSingleThreadExecutor()
    private lateinit var preferences: SharedPreferences
    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var launcherVisible = false
    private var refreshGeneration = 0
    private var destroyed = false
    private var autoHideRunnable: Runnable? = null

    private val preferenceListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        mainHandler.post {
            if (!preferences.getBoolean(TASKBAR_OVERLAY_ENABLED, false)) stopOverlay()
            else scheduleRefresh()
        }
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            scheduleRefresh()
        }
    }

    override fun onCreate() {
        super.onCreate()
        preferences = getSharedPreferences("launcher", MODE_PRIVATE)
        windowManager = getSystemService(WindowManager::class.java)
        createNotificationChannel()
        preferences.registerOnSharedPreferenceChangeListener(preferenceListener)
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground()
        when (intent?.action) {
            ACTION_STOP -> {
                preferences.edit().putBoolean(TASKBAR_OVERLAY_ENABLED, false).apply()
                stopOverlay()
                return START_NOT_STICKY
            }
            ACTION_SYNC, ACTION_LAUNCHER_VISIBILITY -> {
                launcherVisible = intent.getBooleanExtra(EXTRA_LAUNCHER_VISIBLE, launcherVisible)
            }
        }
        if (!preferences.getBoolean(TASKBAR_OVERLAY_ENABLED, false) ||
            !TaskbarOverlayController.hasPermission(this)
        ) {
            stopOverlay()
            return START_NOT_STICKY
        }
        if (launcherVisible) removeOverlayView() else scheduleRefresh()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        scheduleRefresh()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        destroyed = true
        refreshGeneration++
        preferences.unregisterOnSharedPreferenceChangeListener(preferenceListener)
        runCatching { unregisterReceiver(packageReceiver) }
        removeOverlayView()
        appLoader.shutdownNow()
        super.onDestroy()
    }

    private fun startInForeground() {
        val openLauncher = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopOverlay = PendingIntent.getService(
            this,
            1,
            Intent(this, TaskbarOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_taskbar_notification)
            .setContentTitle("Ubuntu Launcher taskbar")
            .setContentText("Taskbar is available over other applications")
            .setContentIntent(openLauncher)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, "Turn off", stopOverlay)
            .build()
        val serviceType = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, serviceType)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Taskbar over other apps",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps the optional Ubuntu Launcher taskbar available over other apps"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun stopOverlay() {
        removeOverlayView()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun readOverlayConfig(): OverlayConfig {
        val orientation = orientationName(resources.configuration.orientation)
        val defaultPosition = if (orientation == "landscape") "left" else "bottom"
        val savedPosition = preferences.getString(
            settingKey("taskbar_pos", orientation),
            preferences.getString("taskbar_pos", defaultPosition)
        ) ?: defaultPosition
        val position = savedPosition.takeIf { it in setOf("left", "right", "top", "bottom") }
            ?: defaultPosition
        val direction = normalizeTaskbarDirection(
            position,
            preferences.getString(
                settingKey("taskbar_direction", orientation),
                preferences.getString("taskbar_direction", defaultTaskbarDirection(position))
            ) ?: defaultTaskbarDirection(position)
        )
        val size = preferences.getInt(
            settingKey("taskbar_size", orientation),
            preferences.getInt("taskbar_size", 64)
        ).coerceIn(44, 110)
        val hidden = preferences.getBoolean(
            settingKey("taskbar_hide", orientation),
            preferences.getBoolean("taskbar_hide", false)
        )
        val autoHide = preferences.getBoolean(
            settingKey("taskbar_auto", orientation),
            preferences.getBoolean("taskbar_auto", false)
        )
        val autoHideSeconds = preferences.getInt(
            settingKey("taskbar_auto_seconds", orientation),
            preferences.getInt("taskbar_auto_seconds", 3)
        ).coerceAtLeast(1)
        val placeholderStyle = readTaskbarPlaceholderStyle(preferences, orientation)
        val opacityPercent = normalizeTaskbarOpacity(
            preferences.getInt(
                settingKey("taskbar_opacity", orientation),
                preferences.getInt("taskbar_opacity", DEFAULT_TASKBAR_OPACITY_PERCENT)
            )
        )
        val keyboardPriority = preferences.getBoolean(
            TASKBAR_OVERLAY_KEYBOARD_PRIORITY,
            true
        )
        return OverlayConfig(
            position,
            direction,
            size,
            hidden,
            autoHide,
            autoHideSeconds,
            placeholderStyle,
            opacityPercent,
            keyboardPriority
        )
    }

    private fun scheduleRefresh() {
        if (destroyed || !shouldDisplayTaskbarOverlay(
                enabled = preferences.getBoolean(TASKBAR_OVERLAY_ENABLED, false),
                permissionGranted = TaskbarOverlayController.hasPermission(this),
                launcherVisible = launcherVisible,
                hiddenForOrientation = false
            )
        ) {
            removeOverlayView()
            return
        }
        val config = readOverlayConfig()
        if (!shouldDisplayTaskbarOverlay(
                enabled = true,
                permissionGranted = true,
                launcherVisible = launcherVisible,
                hiddenForOrientation = config.hidden
            )
        ) {
            removeOverlayView()
            return
        }
        val generation = ++refreshGeneration
        appLoader.execute {
            val allApps = runCatching { loadApps(applicationContext) }.getOrDefault(emptyList())
            val orderedPackages = orderedPinnedPackages(preferences, allApps)
            val pinnedApps = orderedPackages.mapNotNull { packageName ->
                allApps.firstOrNull { it.packageName == packageName }
            }
            mainHandler.post {
                if (!destroyed && generation == refreshGeneration && !launcherVisible) {
                    showOverlay(config, pinnedApps)
                }
            }
        }
    }

    private fun showOverlay(config: OverlayConfig, pinnedApps: List<AppItem>) {
        if (!shouldDisplayTaskbarOverlay(
                enabled = preferences.getBoolean(TASKBAR_OVERLAY_ENABLED, false),
                permissionGranted = TaskbarOverlayController.hasPermission(this),
                launcherVisible = launcherVisible,
                hiddenForOrientation = config.hidden
            )) {
            removeOverlayView()
            return
        }
        removeOverlayView()
        showExpandedOverlay(config, pinnedApps)
    }

    private fun showExpandedOverlay(config: OverlayConfig, pinnedApps: List<AppItem>) {
        val vertical = config.position == "left" || config.position == "right"
        val view = createTaskbarView(
            vertical,
            config.direction,
            config.sizeDp,
            pinnedApps,
            config.opacityPercent
        ) { scheduleOverlayAutoHide(config, pinnedApps) }
        replaceOverlayView(view, overlayLayoutParams(config, collapsed = false))
        scheduleOverlayAutoHide(config, pinnedApps)
    }

    private fun showCollapsedOverlay(config: OverlayConfig, pinnedApps: List<AppItem>) {
        val view = createRevealHandle(config.placeholderStyle) {
            showExpandedOverlay(config, pinnedApps)
        }
        replaceOverlayView(view, overlayLayoutParams(config, collapsed = true))
    }

    private fun overlayLayoutParams(
        config: OverlayConfig,
        collapsed: Boolean
    ): WindowManager.LayoutParams {
        val vertical = config.position == "left" || config.position == "right"
        val thicknessPx = dp(config.sizeDp)
        val slotPx = dp(48)
        val width = when {
            collapsed && vertical -> thicknessPx
            collapsed -> slotPx
            vertical -> thicknessPx
            else -> WindowManager.LayoutParams.MATCH_PARENT
        }
        val height = when {
            collapsed && vertical -> slotPx
            collapsed -> thicknessPx
            vertical -> WindowManager.LayoutParams.MATCH_PARENT
            else -> thicknessPx
        }
        val baseGravity = when (config.position) {
            "top" -> Gravity.TOP
            "left" -> Gravity.START
            "right" -> Gravity.END
            else -> Gravity.BOTTOM
        }
        val collapsedEdge = if (!collapsed) 0 else if (vertical) {
            if (taskbarDirectionIsReversed(config.direction)) Gravity.BOTTOM else Gravity.TOP
        } else {
            if (taskbarDirectionIsReversed(config.direction)) Gravity.END else Gravity.START
        }
        val keyboardFlag = if (config.keyboardPriority) {
            WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM
        } else {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        return WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or keyboardFlag,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = baseGravity or collapsedEdge
            title = "Ubuntu Launcher taskbar"
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createTaskbarView(
        vertical: Boolean,
        direction: String,
        sizeDp: Int,
        pinnedApps: List<AppItem>,
        opacityPercent: Int,
        onInteraction: () -> Unit
    ): View {
        val reversed = taskbarDirectionIsReversed(direction)
        val thicknessPx = dp(sizeDp)
        val slotPx = dp(minOf(48, sizeDp))
        val container = LinearLayout(this).apply {
            orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            gravity = if (vertical) {
                Gravity.CENTER_HORIZONTAL or if (reversed) Gravity.BOTTOM else Gravity.TOP
            } else {
                Gravity.CENTER_VERTICAL or if (reversed) Gravity.END else Gravity.START
            }
        }
        val items = mutableListOf<View>()
        items += createApplicationsButton(vertical, thicknessPx, slotPx, onInteraction)
        pinnedApps.forEach {
            items += createPinnedAppButton(it, vertical, thicknessPx, slotPx, onInteraction)
        }
        if (reversed) items.reverse()
        items.forEach { container.addView(it) }

        val backgroundColor = Color.argb(taskbarOpacityAlpha(opacityPercent), 0, 0, 0)
        val taskbar = if (vertical) {
            ScrollView(this).apply {
                isFillViewport = true
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                setBackgroundColor(backgroundColor)
                addView(
                    container,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
                if (reversed) post { fullScroll(View.FOCUS_DOWN) }
            }
        } else {
            HorizontalScrollView(this).apply {
                isFillViewport = true
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                setBackgroundColor(backgroundColor)
                addView(
                    container,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                if (reversed) post { fullScroll(View.FOCUS_RIGHT) }
            }
        }
        taskbar.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN ||
                event.actionMasked == MotionEvent.ACTION_MOVE ||
                event.actionMasked == MotionEvent.ACTION_UP
            ) onInteraction()
            false
        }
        return taskbar
    }

    private fun createApplicationsButton(
        vertical: Boolean,
        thicknessPx: Int,
        slotPx: Int,
        onInteraction: () -> Unit
    ): View =
        FrameLayout(this).apply {
            layoutParams = taskbarItemLayoutParams(vertical, thicknessPx, slotPx)
            contentDescription = "Applications"
            isClickable = true
            isFocusable = true
            addView(
                NineDotView(context),
                FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
            )
            setOnClickListener {
                onInteraction()
                val intent = Intent("android.intent.action.ALL_APPS")
                    .setClass(this@TaskbarOverlayService, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                runCatching { startActivity(intent) }
            }
        }

    private fun createPinnedAppButton(
        app: AppItem,
        vertical: Boolean,
        thicknessPx: Int,
        slotPx: Int,
        onInteraction: () -> Unit
    ): View = ImageButton(this).apply {
        layoutParams = taskbarItemLayoutParams(vertical, thicknessPx, slotPx)
        background = ColorDrawable(Color.TRANSPARENT)
        contentDescription = app.label
        scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        val padding = dp(6)
        setPadding(padding, padding, padding, padding)
        setImageDrawable(runCatching { app.icon.constantState?.newDrawable()?.mutate() ?: app.icon }.getOrDefault(app.icon))
        setOnClickListener {
            onInteraction()
            val launchIntent = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(app.packageName, app.activityName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { startActivity(launchIntent) }
        }
    }

    private fun taskbarItemLayoutParams(
        vertical: Boolean,
        thicknessPx: Int,
        slotPx: Int
    ): LinearLayout.LayoutParams = if (vertical) {
        LinearLayout.LayoutParams(thicknessPx, slotPx)
    } else {
        LinearLayout.LayoutParams(slotPx, thicknessPx)
    }

    private fun createRevealHandle(style: TaskbarPlaceholderStyle, onClick: () -> Unit): View =
        FrameLayout(this).apply {
            isClickable = true
            isFocusable = true
            contentDescription = "Show taskbar"
            addView(
                PlaceholderStyleView(context, style),
                FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
            )
            setOnClickListener { onClick() }
        }

    private fun scheduleOverlayAutoHide(config: OverlayConfig, pinnedApps: List<AppItem>) {
        autoHideRunnable?.let(mainHandler::removeCallbacks)
        autoHideRunnable = null
        if (!shouldScheduleTaskbarOverlayAutoHide(config.autoHide, launcherVisible, destroyed)) return
        val runnable = Runnable {
            autoHideRunnable = null
            if (!launcherVisible &&
                preferences.getBoolean(TASKBAR_OVERLAY_ENABLED, false) &&
                TaskbarOverlayController.hasPermission(this)
            ) showCollapsedOverlay(config, pinnedApps)
        }
        autoHideRunnable = runnable
        mainHandler.postDelayed(runnable, taskbarAutoHideDelayMillis(config.autoHideSeconds))
    }

    private fun replaceOverlayView(view: View, params: WindowManager.LayoutParams) {
        overlayView?.let { current -> runCatching { windowManager.removeViewImmediate(current) } }
        overlayView = null
        if (runCatching { windowManager.addView(view, params) }.isSuccess) overlayView = view
        else stopOverlay()
    }

    private fun removeOverlayView() {
        autoHideRunnable?.let(mainHandler::removeCallbacks)
        autoHideRunnable = null
        overlayView?.let { view -> runCatching { windowManager.removeViewImmediate(view) } }
        overlayView = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private class PlaceholderStyleView(
        context: Context,
        private val style: TaskbarPlaceholderStyle
    ) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val bounds = RectF()
        private val primary = colorWithOpacity(style.primaryArgb, style.opacityPercent)
        private val secondary = colorWithOpacity(style.secondaryArgb, style.opacityPercent)
        private var linearShader: Shader? = null
        private var radialShader: Shader? = null

        override fun onSizeChanged(width: Int, height: Int, oldWidth: Int, oldHeight: Int) {
            super.onSizeChanged(width, height, oldWidth, oldHeight)
            if (width <= 0 || height <= 0) return
            val radius = 4f * resources.displayMetrics.density
            bounds.set(0f, 0f, width.toFloat(), height.toFloat())
            path.reset()
            path.addRoundRect(bounds, radius, radius, Path.Direction.CW)
            linearShader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                primary, secondary, Shader.TileMode.CLAMP
            )
            radialShader = RadialGradient(
                width / 2f, height / 2f, maxOf(width, height) * .72f,
                primary, secondary, Shader.TileMode.CLAMP
            )
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (width <= 0 || height <= 0) return
            val checkpoint = canvas.save()
            canvas.clipPath(path)
            when (style.mode) {
                "linear" -> {
                    paint.shader = linearShader
                    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
                }
                "radial" -> {
                    paint.shader = radialShader
                    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
                }
                "stripes" -> {
                    fill(canvas, primary)
                    paint.shader = null
                    paint.color = secondary
                    paint.strokeWidth = (minOf(width, height) / 7f).coerceAtLeast(2f)
                    val gap = (minOf(width, height) / 3f).coerceAtLeast(3f)
                    var start = -height.toFloat()
                    while (start < width) {
                        canvas.drawLine(start, height.toFloat(), start + height, 0f, paint)
                        start += gap
                    }
                }
                "dots" -> {
                    fill(canvas, primary)
                    paint.shader = null
                    paint.color = secondary
                    val gap = (minOf(width, height) / 3f).coerceAtLeast(4f)
                    val dotRadius = (gap * .22f).coerceAtLeast(1f)
                    var y = gap / 2f
                    while (y < height) {
                        var x = gap / 2f
                        while (x < width) {
                            canvas.drawCircle(x, y, dotRadius, paint)
                            x += gap
                        }
                        y += gap
                    }
                }
                "checker" -> {
                    fill(canvas, primary)
                    paint.shader = null
                    paint.color = secondary
                    val square = (minOf(width, height) / 3f).coerceAtLeast(3f)
                    var row = 0
                    var y = 0f
                    while (y < height) {
                        var column = 0
                        var x = 0f
                        while (x < width) {
                            if ((row + column) % 2 == 0) {
                                canvas.drawRect(x, y, x + square, y + square, paint)
                            }
                            x += square
                            column++
                        }
                        y += square
                        row++
                    }
                }
                else -> fill(canvas, primary)
            }
            paint.shader = null
            canvas.restoreToCount(checkpoint)
        }

        private fun fill(canvas: Canvas, color: Int) {
            paint.shader = null
            paint.color = color
            paint.style = Paint.Style.FILL
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        }
    }

    private class NineDotView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val square = minOf(width, height) / 7f
            val gap = square * 0.75f
            val total = square * 3f + gap * 2f
            val startX = (width - total) / 2f
            val startY = (height - total) / 2f
            repeat(3) { row ->
                repeat(3) { column ->
                    val left = startX + column * (square + gap)
                    val top = startY + row * (square + gap)
                    canvas.drawRect(left, top, left + square, top + square, paint)
                }
            }
        }
    }
}
