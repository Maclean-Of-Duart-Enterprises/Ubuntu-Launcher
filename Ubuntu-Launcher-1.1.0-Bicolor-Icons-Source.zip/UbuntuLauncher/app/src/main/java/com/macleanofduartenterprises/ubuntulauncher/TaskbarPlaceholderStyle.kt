package com.macleanofduartenterprises.ubuntulauncher

import android.content.SharedPreferences
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

internal const val DEFAULT_TASKBAR_PLACEHOLDER_PRIMARY = "#E95420"
internal const val DEFAULT_TASKBAR_PLACEHOLDER_SECONDARY = "#77216F"
internal const val DEFAULT_TASKBAR_PLACEHOLDER_MODE = "solid"
internal const val DEFAULT_TASKBAR_PLACEHOLDER_OPACITY = 100

internal val TASKBAR_PLACEHOLDER_MODES =
    listOf("solid", "linear", "radial", "stripes", "dots", "checker")

internal data class TaskbarPlaceholderStyle(
    val primaryArgb: Int,
    val secondaryArgb: Int,
    val mode: String,
    val opacityPercent: Int
)

internal data class HsvColor(
    val hue: Float,
    val saturation: Float,
    val value: Float
)

internal fun normalizeHexColor(value: String): String? {
    val digits = value.trim().removePrefix("#")
    if (digits.length != 6 && digits.length != 8) return null
    if (!digits.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) return null
    return "#${digits.uppercase(Locale.ROOT)}"
}

internal fun parseArgbColor(value: String?, fallback: Int): Int {
    val normalized = normalizeHexColor(value.orEmpty()) ?: return fallback
    val digits = normalized.removePrefix("#")
    return runCatching {
        if (digits.length == 6) {
            (0xFF000000L or digits.toLong(16)).toInt()
        } else {
            digits.toLong(16).toInt()
        }
    }.getOrDefault(fallback)
}

internal fun argbToOpaqueHex(argb: Int): String =
    String.format(Locale.ROOT, "#%06X", argb and 0x00FFFFFF)

internal fun normalizeTaskbarPlaceholderMode(value: String?): String =
    value?.takeIf { it in TASKBAR_PLACEHOLDER_MODES } ?: DEFAULT_TASKBAR_PLACEHOLDER_MODE

internal fun normalizeTaskbarPlaceholderOpacity(value: Int): Int = value.coerceIn(0, 100)

internal fun colorWithOpacity(argb: Int, opacityPercent: Int): Int {
    val sourceAlpha = argb ushr 24 and 0xFF
    val outputAlpha = (sourceAlpha * normalizeTaskbarPlaceholderOpacity(opacityPercent) + 50) / 100
    return (argb and 0x00FFFFFF) or (outputAlpha shl 24)
}

internal fun readTaskbarPlaceholderStyle(
    preferences: SharedPreferences,
    orientation: String
): TaskbarPlaceholderStyle {
    val primaryText = preferences.getString(
        settingKey("taskbar_handle_color", orientation),
        preferences.getString("taskbar_handle_color", DEFAULT_TASKBAR_PLACEHOLDER_PRIMARY)
    ) ?: DEFAULT_TASKBAR_PLACEHOLDER_PRIMARY
    val secondaryText = preferences.getString(
        settingKey("taskbar_handle_secondary_color", orientation),
        preferences.getString("taskbar_handle_secondary_color", DEFAULT_TASKBAR_PLACEHOLDER_SECONDARY)
    ) ?: DEFAULT_TASKBAR_PLACEHOLDER_SECONDARY
    val mode = normalizeTaskbarPlaceholderMode(
        preferences.getString(
            settingKey("taskbar_handle_style", orientation),
            preferences.getString("taskbar_handle_style", DEFAULT_TASKBAR_PLACEHOLDER_MODE)
        )
    )
    val opacity = normalizeTaskbarPlaceholderOpacity(
        preferences.getInt(
            settingKey("taskbar_handle_opacity", orientation),
            preferences.getInt("taskbar_handle_opacity", DEFAULT_TASKBAR_PLACEHOLDER_OPACITY)
        )
    )
    return TaskbarPlaceholderStyle(
        primaryArgb = parseArgbColor(primaryText, 0xFFE95420.toInt()),
        secondaryArgb = parseArgbColor(secondaryText, 0xFF77216F.toInt()),
        mode = mode,
        opacityPercent = opacity
    )
}

internal fun argbToHsv(argb: Int): HsvColor {
    val red = ((argb ushr 16) and 0xFF) / 255f
    val green = ((argb ushr 8) and 0xFF) / 255f
    val blue = (argb and 0xFF) / 255f
    val maximum = max(red, max(green, blue))
    val minimum = min(red, min(green, blue))
    val delta = maximum - minimum
    val hue = when {
        delta == 0f -> 0f
        maximum == red -> 60f * (((green - blue) / delta) % 6f)
        maximum == green -> 60f * (((blue - red) / delta) + 2f)
        else -> 60f * (((red - green) / delta) + 4f)
    }.let { if (it < 0f) it + 360f else it }
    val saturation = if (maximum == 0f) 0f else delta / maximum
    return HsvColor(hue, saturation, maximum)
}

internal fun hsvToArgb(hue: Float, saturation: Float, value: Float): Int {
    val normalizedHue = ((hue % 360f) + 360f) % 360f
    val clampedSaturation = saturation.coerceIn(0f, 1f)
    val clampedValue = value.coerceIn(0f, 1f)
    val chroma = clampedValue * clampedSaturation
    val hueSection = normalizedHue / 60f
    val component = chroma * (1f - abs(hueSection % 2f - 1f))
    val (redPrime, greenPrime, bluePrime) = when (hueSection.toInt()) {
        0 -> Triple(chroma, component, 0f)
        1 -> Triple(component, chroma, 0f)
        2 -> Triple(0f, chroma, component)
        3 -> Triple(0f, component, chroma)
        4 -> Triple(component, 0f, chroma)
        else -> Triple(chroma, 0f, component)
    }
    val match = clampedValue - chroma
    val red = ((redPrime + match) * 255f + .5f).toInt().coerceIn(0, 255)
    val green = ((greenPrime + match) * 255f + .5f).toInt().coerceIn(0, 255)
    val blue = ((bluePrime + match) * 255f + .5f).toInt().coerceIn(0, 255)
    return 0xFF000000.toInt() or (red shl 16) or (green shl 8) or blue
}

internal fun normalizeAppDrawerExtent(value: Int): Int = value.coerceIn(40, 100)

internal fun normalizeAppListIconSize(value: Int): Int = value.coerceIn(20, 96)

internal fun normalizeAppListLabelSize(value: Int): Int = value.coerceIn(8, 28)

internal fun defaultAppDrawerExtent(orientation: String): Int =
    if (orientation == "landscape") 62 else 88

internal fun appDrawerOpensFromEnd(position: String, direction: String): Boolean =
    position == "right" ||
        (position != "left" && position != "right" && taskbarDirectionIsReversed(direction))
