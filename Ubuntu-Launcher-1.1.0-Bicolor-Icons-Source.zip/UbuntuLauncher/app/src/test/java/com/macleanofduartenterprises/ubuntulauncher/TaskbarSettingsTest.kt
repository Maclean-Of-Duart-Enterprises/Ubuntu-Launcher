package com.macleanofduartenterprises.ubuntulauncher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskbarSettingsTest {
    @Test
    fun normalizesSixDigitTaskbarColor() {
        assertEquals("#E95420", normalizeHexColor(" e95420 "))
        assertEquals("#123ABC", normalizeHexColor("#123abc"))
    }

    @Test
    fun normalizesEightDigitTaskbarColor() {
        assertEquals("#80E95420", normalizeHexColor("80e95420"))
    }

    @Test
    fun rejectsIncompleteOrNonHexTaskbarColor() {
        assertNull(normalizeHexColor("#E9542"))
        assertNull(normalizeHexColor("#E9542Z"))
        assertNull(normalizeHexColor("orange"))
    }

    @Test
    fun offersVerticalDirectionsForSideTaskbars() {
        assertEquals(listOf("down", "up"), taskbarDirectionOptions("left"))
        assertEquals(listOf("down", "up"), taskbarDirectionOptions("right"))
    }

    @Test
    fun offersHorizontalDirectionsForTopAndBottomTaskbars() {
        assertEquals(listOf("right", "left"), taskbarDirectionOptions("top"))
        assertEquals(listOf("right", "left"), taskbarDirectionOptions("bottom"))
    }

    @Test
    fun normalizesDirectionAndIdentifiesReverseLayout() {
        assertEquals("down", normalizeTaskbarDirection("left", "left"))
        assertEquals("right", normalizeTaskbarDirection("bottom", "up"))
        assertEquals("up", normalizeTaskbarDirection("right", "up"))
        assertTrue(taskbarDirectionIsReversed("up"))
        assertTrue(taskbarDirectionIsReversed("left"))
        assertFalse(taskbarDirectionIsReversed("down"))
        assertFalse(taskbarDirectionIsReversed("right"))
    }

    @Test
    fun clampsAndConvertsTaskbarOpacity() {
        assertEquals(0, normalizeTaskbarOpacity(-5))
        assertEquals(48, normalizeTaskbarOpacity(48))
        assertEquals(100, normalizeTaskbarOpacity(150))
        assertEquals(0, taskbarOpacityAlpha(0))
        assertEquals(122, taskbarOpacityAlpha(48))
        assertEquals(255, taskbarOpacityAlpha(100))
        assertEquals(0.48f, taskbarOpacityFraction(48))
    }

    @Test
    fun normalizesPlaceholderStyleAndOpacity() {
        assertEquals("linear", normalizeTaskbarPlaceholderMode("linear"))
        assertEquals("checker", normalizeTaskbarPlaceholderMode("checker"))
        assertEquals("solid", normalizeTaskbarPlaceholderMode("unknown"))
        assertEquals(0, normalizeTaskbarPlaceholderOpacity(-10))
        assertEquals(65, normalizeTaskbarPlaceholderOpacity(65))
        assertEquals(100, normalizeTaskbarPlaceholderOpacity(110))
    }

    @Test
    fun parsesColorsAndAppliesPlaceholderOpacity() {
        assertEquals(0xFFE95420.toInt(), parseArgbColor("#E95420", 0))
        assertEquals(0x8033FF00.toInt(), parseArgbColor("8033FF00", 0))
        assertEquals("#33FF00", argbToOpaqueHex(0x8033FF00.toInt()))
        assertEquals(0x80E95420.toInt(), colorWithOpacity(0xFFE95420.toInt(), 50))
        assertEquals(0x4033FF00, colorWithOpacity(0x8033FF00.toInt(), 50))
    }

    @Test
    fun colorWheelConversionRoundTripsOpaqueColors() {
        listOf(0xFF33FF00.toInt(), 0xFFE95420.toInt(), 0xFF77216F.toInt()).forEach { color ->
            val hsv = argbToHsv(color)
            assertEquals(color, hsvToArgb(hsv.hue, hsv.saturation, hsv.value))
        }
    }

    @Test
    fun appDrawerExtentAndOpeningEdgeFollowOrientationAndTaskbar() {
        assertEquals(40, normalizeAppDrawerExtent(10))
        assertEquals(72, normalizeAppDrawerExtent(72))
        assertEquals(100, normalizeAppDrawerExtent(120))
        assertEquals(62, defaultAppDrawerExtent("landscape"))
        assertEquals(88, defaultAppDrawerExtent("portrait"))
        assertFalse(appDrawerOpensFromEnd("left", "down"))
        assertTrue(appDrawerOpensFromEnd("right", "up"))
        assertFalse(appDrawerOpensFromEnd("bottom", "right"))
        assertTrue(appDrawerOpensFromEnd("bottom", "left"))
    }

    @Test
    fun clampsOrientationSpecificApplicationListSizes() {
        assertEquals(20, normalizeAppListIconSize(1))
        assertEquals(48, normalizeAppListIconSize(48))
        assertEquals(96, normalizeAppListIconSize(200))
        assertEquals(8, normalizeAppListLabelSize(1))
        assertEquals(12, normalizeAppListLabelSize(12))
        assertEquals(28, normalizeAppListLabelSize(80))
    }
}
