package com.macleanofduartenterprises.ubuntulauncher

import org.junit.Assert.assertEquals
import org.junit.Test

class AppIconOpacityTest {
    @Test
    fun valuesInsideRangeArePreserved() {
        assertEquals(0, normalizeAppIconOpacity(0))
        assertEquals(42, normalizeAppIconOpacity(42))
        assertEquals(100, normalizeAppIconOpacity(100))
    }

    @Test
    fun negativeValuesAreClampedToTransparent() {
        assertEquals(0, normalizeAppIconOpacity(-1))
        assertEquals(0, normalizeAppIconOpacity(Int.MIN_VALUE))
    }

    @Test
    fun valuesAboveOneHundredAreClampedToOpaque() {
        assertEquals(100, normalizeAppIconOpacity(101))
        assertEquals(100, normalizeAppIconOpacity(Int.MAX_VALUE))
    }

    @Test
    fun percentageConvertsToComposeAlphaFraction() {
        assertEquals(0f, appIconOpacityFraction(-20), 0.0001f)
        assertEquals(0.42f, appIconOpacityFraction(42), 0.0001f)
        assertEquals(1f, appIconOpacityFraction(150), 0.0001f)
    }
}
