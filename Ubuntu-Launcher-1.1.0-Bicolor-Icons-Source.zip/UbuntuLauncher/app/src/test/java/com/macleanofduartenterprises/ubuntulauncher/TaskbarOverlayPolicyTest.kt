package com.macleanofduartenterprises.ubuntulauncher

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskbarOverlayPolicyTest {
    @Test
    fun overlayOnlyDisplaysWhenEveryRequirementIsSatisfied() {
        assertTrue(shouldDisplayTaskbarOverlay(true, true, false, false))
        assertFalse(shouldDisplayTaskbarOverlay(false, true, false, false))
        assertFalse(shouldDisplayTaskbarOverlay(true, false, false, false))
        assertFalse(shouldDisplayTaskbarOverlay(true, true, true, false))
        assertFalse(shouldDisplayTaskbarOverlay(true, true, false, true))
    }

    @Test
    fun overlayAutoHideOnlyRunsForAnActiveOutsideLauncherOverlay() {
        assertTrue(shouldScheduleTaskbarOverlayAutoHide(true, false, false))
        assertFalse(shouldScheduleTaskbarOverlayAutoHide(false, false, false))
        assertFalse(shouldScheduleTaskbarOverlayAutoHide(true, true, false))
        assertFalse(shouldScheduleTaskbarOverlayAutoHide(true, false, true))
        assertTrue(taskbarAutoHideDelayMillis(0) == 1_000L)
        assertTrue(taskbarAutoHideDelayMillis(3) == 3_000L)
    }
}
