package com.macleanofduartenterprises.ubuntulauncher

import org.junit.Assert.assertEquals
import org.junit.Test

class PinnedAppOrderTest {
    @Test
    fun unorderedLegacyPinsMigrateToInstalledDisplayOrder() {
        assertEquals(
            listOf("app.alpha", "app.beta"),
            resolvePinnedOrder(
                selected = setOf("app.beta", "app.alpha"),
                stored = null,
                installedInDisplayOrder = listOf("app.alpha", "app.beta", "app.gamma")
            )
        )
    }

    @Test
    fun savedOrderWinsAndNewPinsAreAppended() {
        assertEquals(
            listOf("app.beta", "app.alpha", "app.gamma"),
            resolvePinnedOrder(
                selected = setOf("app.alpha", "app.beta", "app.gamma"),
                stored = "app.beta\u001Fapp.alpha",
                installedInDisplayOrder = listOf("app.alpha", "app.beta", "app.gamma")
            )
        )
    }

    @Test
    fun staleUnselectedEntriesAreRemovedAndUnavailablePinsArePreserved() {
        assertEquals(
            listOf("app.alpha", "app.unavailable"),
            resolvePinnedOrder(
                selected = setOf("app.alpha", "app.unavailable"),
                stored = "app.deleted\u001Fapp.unavailable\u001Fapp.alpha",
                installedInDisplayOrder = listOf("app.alpha")
            )
        )
    }

    @Test
    fun pinCanMoveEarlierOrLaterWithinBounds() {
        val original = listOf("app.alpha", "app.beta", "app.gamma")
        assertEquals(
            listOf("app.alpha", "app.gamma", "app.beta"),
            movePinnedPackage(original, "app.beta", 1)
        )
        assertEquals(original, movePinnedPackage(original, "app.alpha", -1))
    }
}
