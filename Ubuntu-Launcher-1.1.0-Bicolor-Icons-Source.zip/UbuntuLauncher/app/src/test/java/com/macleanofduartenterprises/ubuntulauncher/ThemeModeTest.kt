package com.macleanofduartenterprises.ubuntulauncher

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ThemeModeTest {
    @Test
    fun explicitDarkAlwaysUsesDarkTheme() {
        assertTrue(resolveDarkThemeMode("dark", systemDark = false))
    }

    @Test
    fun explicitLightAlwaysUsesLightTheme() {
        assertFalse(resolveDarkThemeMode("light", systemDark = true))
    }

    @Test
    fun autoFollowsSystemTheme() {
        assertTrue(resolveDarkThemeMode("auto", systemDark = true))
        assertFalse(resolveDarkThemeMode("auto", systemDark = false))
    }

    @Test
    fun missingOrInvalidPreferenceFallsBackToSystem() {
        assertTrue(resolveDarkThemeMode(null, systemDark = true))
        assertFalse(resolveDarkThemeMode("unexpected", systemDark = false))
    }
}
