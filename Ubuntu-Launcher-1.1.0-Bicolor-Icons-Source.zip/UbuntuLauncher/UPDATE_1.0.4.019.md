# Ubuntu Launcher 1.0.4.019 — Application icon opacity

Under Settings > Applications list, select Portrait or Landscape and adjust **Application icon opacity** from 0–100%. This applies to actual app icons in both grid and list layouts, whether or not recoloring is enabled. Opacity is stored separately for each orientation and defaults to 100%, preserving existing appearance. The application name and package text remain unaffected.

The release was compiled with Android SDK 35, optimized with R8 and resource shrinking, signed with the established release identity, and verified without an emulator. Focused JVM coverage checks valid, transparent, opaque, and out-of-range opacity values in both debug and release test variants.
