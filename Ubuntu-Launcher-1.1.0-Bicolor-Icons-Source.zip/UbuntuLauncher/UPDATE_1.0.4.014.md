# Ubuntu Launcher 1.0.4.014 changes

- Added an actual interactive hue wheel with saturation and brightness sliders, swatch and validated hex input for icon tint, display text, and clock/date colors in both orientation profiles.
- Added separate applications drawer background color per orientation, applied to the drawer Surface and list-row backgrounds.
- Corrected the application grid/list settings to update Compose state when toggled.
- Existing application pinning, scrolling, font styles and file shortcut support are retained.

Verification: These changes are retained in 1.0.4.015, where they passed debug/release JVM tests, release compilation, lint, R8/resource optimization, ZIP alignment, and v2/v3 signature verification. No emulator or physical device was used.
