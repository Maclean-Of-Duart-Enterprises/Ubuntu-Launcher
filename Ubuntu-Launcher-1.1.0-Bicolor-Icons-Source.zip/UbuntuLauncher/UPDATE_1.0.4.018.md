# 1.0.4.018 — Application appearance

Display settings now includes Light, Dark, and Auto (Android system) theme selection. Choice persists in SharedPreferences, updates Compose Material color scheme, settings background and header, and status/navigation icon contrast. Existing wallpaper, icon tints, and explicitly chosen colors are not overridden.

Verification: debug and release compilation passed; 35 tests across 8 suites passed in each build variant; Android lint passed with 0 errors; R8 optimization, resource shrinking, APK alignment, archive integrity, and APK Signature Schemes v2/v3 passed. The unsafe Activity cast in the supplied theme implementation was replaced with lifecycle-safe `LocalActivity`, and system-bar icon contrast now remains synchronized after launcher resume and rotation. No emulator was used.

Brand-specific wallpaper, desktop, taskbar, and lock-screen styling plus explicitly chosen user colors remain intentional and are not overwritten by the application appearance setting.
