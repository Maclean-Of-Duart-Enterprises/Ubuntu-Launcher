# Ubuntu Launcher 1.0.4.013 — source changes

- Drawer: optional icon monochrome tint (separate portrait/landscape colors), grid vertical/horizontal scroll, pinned applications first in either grid/list. Long press an app to pin/unpin in drawer; taskbar pins remain independent.
- Orientation display settings: 10 Android font-family presets, 1–80 sp custom desktop text size, normal/bold/italic, and hex text colors. These typography settings affect the custom desktop text and drawer app names; the pre-existing drawer-specific label-size sliders remain separate.
- Desktop: pin individual files of any document type via Android Storage Access Framework, retain read URI permissions, use actual file names, and select folders through OpenDocumentTree. Folder launch depends on a compatible installed file manager; Android cannot guarantee a handler for every document MIME type.
- Original icons can be retained by disabling icon recoloring; enabled tint replaces icon colors.

## Verification status
Source patched and packaged. Android Gradle compilation was attempted but unavailable because the Gradle wrapper distribution was not installed and services.gradle.org could not be reached. No APK/device test was performed. Review/compile with Android SDK and Gradle before installing.
