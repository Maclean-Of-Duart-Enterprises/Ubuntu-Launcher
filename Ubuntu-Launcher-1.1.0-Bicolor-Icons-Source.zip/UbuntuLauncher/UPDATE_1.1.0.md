# Ubuntu Launcher 1.1.0 — Bi-color application icons

- Uses a user-selected colored background tile plus the original application artwork for a clear two-color appearance.
- Keeps application artwork intact and draws it at 78% scale over the tile.
- Applies the opacity setting to the complete tile-and-icon result.
- Keeps portrait and landscape preferences independent.
- Applies the same rendering in both application grid and list layouts.
- Leaves icons unchanged when recoloring is disabled.

Android version code: 29.

Release verification: 39 JVM tests passed across 9 release suites; lint-vital, R8 optimization, resource shrinking, ZIP alignment, APK integrity, and APK Signature Schemes v2/v3 all passed without an emulator.
