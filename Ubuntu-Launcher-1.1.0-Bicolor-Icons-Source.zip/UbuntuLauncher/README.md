# Ubuntu Launcher for Android

Ubuntu Launcher is a standalone Android HOME launcher with an Ubuntu-inspired aubergine and orange interface. It supports portrait and landscape layouts, a searchable application drawer, configurable taskbar, desktop shortcuts, Dumb Phone Mode, per-orientation appearance controls, launcher backup/restore, and an optional launcher-level lock.

## Release identity

- App name: **Ubuntu Launcher**
- Application ID: `com.macleanofduartenterprises.ubuntulauncher`
- Version: **1.0.4.016** (`versionCode 23`, independent orientation drawer profiles and placement)
- Developer: **Maclean Of Duart Enterprises Corp**
- Android support: API 26+; compile/target SDK 35
- APK format: universal ARM64, ARMv7, x86, and x86_64

## Features

- Android HOME/default-launcher role request with a dedicated single launcher task and reliable gesture-Home restoration
- Portrait and landscape-specific wallpapers, scaling, clock typography, independent 3×3 clock placement, desktop columns, custom text, and border style
- Independent portrait and landscape controls for hiding the Android status and navigation bars, applied immediately with transient swipe-to-reveal behavior
- Fast, failure-isolated asynchronous installed-app discovery and cached app icons
- Searchable popout application drawer with independently managed portrait and landscape profiles, grid/list modes, vertical or horizontal grid scrolling, and extent sliders
- Per-orientation Left, Center, or Right drawer placement; existing installations retain taskbar-edge placement until a position is selected
- Consolidated Applications-list settings for orientation-specific grid/list mode, placement, extent, icon and label sizes, scroll direction, icon tint, drawer background, and pinned-app guidance
- Independent portrait/landscape control for showing or hiding application names beneath grid icons
- Interactive color wheels, saturation/brightness controls, swatches, and validated hex input for application icons, drawer backgrounds, display text, and clock/date colors
- Unlimited scrollable taskbar pins with user-controlled ordering and independent portrait/landscape position, size, visibility, auto-hide delay, and flow direction
- Side taskbars can flow upward or downward; top/bottom taskbars can flow leftward or rightward
- Optional non-focusable taskbar overlay keeps the taskbar available over other apps using Android's explicit Display over other apps permission and a foreground-service notification
- Per-orientation 0–100% taskbar background opacity, including a fully transparent floating-icon style
- Foreground overlay follows the same per-orientation auto-hide delay and reveal-square configuration as the Home taskbar
- Optional keyboard-priority behavior keeps the overlay behind the soft keyboard so it cannot block keys
- Visual auto-hide placeholder designer with a color wheel, two saved colors, linear/radial gradients, stripe/dot/checker patterns, opacity, and live preview
- Customizable auto-hide reveal square aligned with the taskbar's nine-dot Applications-button slot
- Main and optional secondary desktop pages with unlimited vertically scrollable rows for files, folders, and website shortcuts
- Up to 14 desktop columns in landscape and up to 8 in portrait
- Clock/date content occupies its own grid row, so it never paints over shortcuts
- Three-second hold-to-move shortcut placement with drag, tap-to-place, occupied-slot swapping, and persistent per-page/per-orientation positions
- File image previews and directly downloaded, memory/disk-cached website favicons with HTML, web-manifest, and conventional favicon discovery
- Shortcut rename and removal from move mode
- Configurable weather-app shortcut and launcher swipe actions
- Dumb Phone Mode with an app allowlist and notification filtering that reconciles both new and already-active notifications
- App-specific Android notification-access guidance with live granted/not-granted status
- Launcher-level hidden-app list
- Optional launcher lock with hashed PIN/password, immediate activation, Lock now, incorrect-entry feedback, and automatic re-lock after leaving the launcher
- JSON settings backup and restore
- Safely centered adaptive and legacy launcher icons generated from the supplied Ubuntu Launcher artwork
- Live preference observation for clock placement and text, taskbar pins and layout, wallpapers, desktop shortcuts, and app-drawer presentation—no phone restart required
- Pinned-app management displays active pins first and provides accessible up/down controls; ordering is saved and reflected on the taskbar immediately

## Build

Use Android Studio with JDK 17, or run:

```bash
./gradlew --no-daemon assembleDebug
./gradlew --no-daemon testDebugUnitTest testReleaseUnitTest lintRelease assembleRelease
```

The Gradle wrapper uses Gradle 8.9. Release builds use R8 code optimization and resource shrinking.

### Signed release

Private signing material is intentionally excluded. Supply it through environment variables:

```bash
export ANDROID_KEYSTORE_PATH=/absolute/path/to/release.keystore
export ANDROID_KEYSTORE_PASSWORD='...'
export ANDROID_KEY_ALIAS='...'
export ANDROID_KEY_PASSWORD='...'
./gradlew --no-daemon clean lintRelease assembleRelease
```

The signed APK is written to `app/build/outputs/apk/release/app-release.apk`. The GitHub Actions workflow accepts the equivalent encrypted repository secrets and verifies the resulting APK signature.

## Enable the taskbar over other apps

1. Open **Ubuntu Launcher Settings → Desktop settings → Taskbar**.
2. Turn on **Show taskbar over other apps**.
3. Android opens **Display over other apps**; authorize Ubuntu Launcher and return.
4. Open another application. The taskbar uses the active portrait or landscape position, size, opacity, direction, pinned-app order, auto-hide delay, and complete placeholder design.

The overlay is deliberately non-focusable, remains below Android's protected system UI, and displays a foreground-service notification while enabled. Use the notification's **Turn off** action or the Taskbar setting to stop it. Per-orientation **Hide taskbar** suppresses the overlay, and **Auto hide** collapses it to the configured placeholder. **Let the keyboard cover the taskbar** prevents it from blocking keyboard keys.

## Enable Dumb Phone notification filtering

1. Open **Ubuntu Launcher Settings → Dumb Phone Settings**.
2. Choose the applications permitted in Dumb Phone Mode.
3. Turn on **Notification filter**. If access is missing, the launcher opens Android's app-specific notification-access page.
4. Enable **Ubuntu Launcher** and allow every notification type, then return to the launcher.
5. Turn on **Dumb Phone Mode**.

The settings page reports whether Android notification access is granted. When active, the service dismisses new and already-visible notifications from packages outside the Dumb Phone allowlist.

## Android limitations

Hidden Apps removes selected apps from this launcher's Home, drawer, search, and Dumb Phone Mode. It does not uninstall, disable, or system-lock other apps. The optional launcher lock protects this launcher UI but does not replace Android's secure system keyguard. Weather is an app shortcut rather than a live third-party widget; full widgets require AppWidgetHost integration. Android does not let a normal `TYPE_APPLICATION_OVERLAY` resize unrelated applications or reserve permanent taskbar space; true desktop-style reserved work areas require privileged system/OEM window management.

## License and trademarks

Ubuntu Launcher is distributed under the GNU Affero General Public License version 3. The complete license is included as `LICENSE`, bundled in the app, and viewable under **Ubuntu Launcher Settings → Licenses**.

Ubuntu and the Ubuntu logo are registered trademarks of Canonical Ltd. This independent project is not endorsed by or affiliated with Canonical.
