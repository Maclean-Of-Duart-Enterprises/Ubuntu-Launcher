# Ubuntu Launcher 1.0.4.015

- Moved drawer and grid controls into **Settings → Applications list** while retaining editable display-text typography under portrait and landscape Display settings.
- Added independent portrait/landscape controls for showing or hiding application names beneath grid icons.
- Repaired the color-control text-field state binding that blocked Kotlin compilation in the supplied source.

## Verification status

Verified on 2026-10-28 without an emulator. Debug and release unit-test suites each passed 31 tests across seven suites, release Kotlin/Java compilation passed, Android lint completed with zero errors, and the optimized signed release passed ZIP alignment plus APK Signature Schemes v2/v3 verification. No physical Android device was attached, so installation and touch interaction remain device-level acceptance checks.
