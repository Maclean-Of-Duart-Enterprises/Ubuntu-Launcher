# Ubuntu Launcher 1.0.4.020 — icon tint correction

## Root cause
The application drawer used `BlendMode.SrcIn`, replacing every pixel of the source icon with a flat tint color. Opacity applied to the resulting silhouette, so app artwork was lost.

## Fix
Application drawer icon tint now uses `BlendMode.Modulate`, multiplying source RGB channels by the chosen tint rather than replacing them. White tint preserves original icon RGB; other tints preserve luminance/detail where present. The existing Compose Image `alpha` still controls 0–100% opacity separately, for both grid and list layouts and portrait/landscape settings.

## Note
Strong saturated tints may still suppress some channels, by design. Disable recoloring to see the exact original icon colors. Opacity 0% makes the icon invisible.

## Verification
Source change and ZIP integrity verified. Android compilation and physical-device behavior not verified.
