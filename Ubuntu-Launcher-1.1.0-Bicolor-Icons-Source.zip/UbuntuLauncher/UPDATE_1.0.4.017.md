# Ubuntu Launcher 1.0.4.017 — drawer search layout fix

- Moved Settings and Close buttons to a separate full-width header row.
- Search field occupies its own full-width row; the placeholder is limited to one line and truncates rather than wrapping into a tall vertical column.
- Existing search behavior and orientation-specific drawer placement remain unchanged.
- Built as an optimized signed release and verified with debug/release unit tests, Android lint, APK alignment, archive-integrity checks, and APK Signature Schemes v2/v3. No emulator was used.
