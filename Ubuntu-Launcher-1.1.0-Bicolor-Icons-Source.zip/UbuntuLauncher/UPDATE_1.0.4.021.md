# Ubuntu Launcher 1.0.4.021 — Bi-color icon repair

- Replaces destructive icon color modulation with a separate, user-selected icon background color.
- Keeps the actual application artwork intact and draws it at 78% scale on the colored tile, providing two visually distinct layers.
- The opacity control now applies to the combined tile and icon.
- Portrait and landscape preference keys remain independent.
- Both grid and list rendering share the corrected AppIcon implementation.
- Default/unrecolored icons remain unchanged.

Note: The implementation is a two-layer colored background plus original icon, not automatic recoloring of individual foreground pixels.
