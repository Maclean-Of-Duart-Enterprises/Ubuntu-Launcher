# Ubuntu Launcher 1.0.4.016

- Application drawer settings now expose explicit Portrait and Landscape profile selectors.
- Grid/list mode is independently persisted for each orientation (existing global mode is fallback for old installs).
- Drawer placement can be set to Left, Center or Right separately for portrait and landscape.
- Drawer width, icon size, label size, grid label visibility, scroll direction, icon tint and background color remain separately configurable for each orientation.
- Drawer placement is applied in the actual drawer Surface layout, not just settings labels.
- Old taskbar-derived opening side remains fallback until a position is chosen.
- Repaired the Applications-settings orientation initializer that prevented the supplied source from compiling.

## Verification status

Verified on 2026-10-28 without an emulator. Debug and release unit-test suites each passed 31 tests across seven suites, release Kotlin/Java compilation passed, Android lint completed with zero errors, and the optimized signed release passed ZIP alignment plus APK Signature Schemes v2/v3 verification. No physical Android device was attached, so installation and touch interaction remain device-level acceptance checks.
