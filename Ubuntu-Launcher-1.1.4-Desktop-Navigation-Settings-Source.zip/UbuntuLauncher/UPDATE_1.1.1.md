# Ubuntu Launcher 1.1.1 — Swipe direction preferences

Desktop Settings > Swipe actions now offers three mutually exclusive modes:
- Disabled
- Swipe right for Applications, swipe left for Settings (existing behavior)
- Swipe left for Applications, swipe right for Settings (new reverse mode)

The gesture recognizer uses the saved selection; changes are applied on recomposition. Existing installations retain their previous swipe-actions preference when no new selection has been made. Preferences are persisted in `swipe_actions_mode` and the old `swipe_actions` boolean remains synchronized for compatibility.

Source-level verification: both gesture branches and selection UI have been updated. Full Android build/device test not completed.
