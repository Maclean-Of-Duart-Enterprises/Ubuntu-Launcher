# Ubuntu Launcher 1.1.3 — source update

- Desktop settings now configure Applications and Settings swipe gestures independently: Off, Left, Right. Legacy 1.1.2 swipe preferences migrate automatically as defaults. If both gestures use the same direction, Applications takes priority.
- Desktop settings add an increment/decrement control for the number of desktop screens, with no hard-coded maximum. Existing main and secondary desktop shortcuts remain on pages 1 and 2.
- Desktop pages now have Previous/Next navigation, each with its own file and website shortcuts, positioning, and widget list.
- Each desktop screen can host Android app widgets through the system widget picker. Widget binding/configuration is delegated to Android; widgets render using AppWidgetHost and AppWidgetHostView. A single widget fills available page space; multiple widgets on a page stack vertically. Widgets can be removed individually.
- New file, folder, and website shortcuts can be targeted to any configured screen through Desktop settings > Shared shortcut destination.
- Existing startup repair code remains unchanged.

## Verification
Release compilation, all 39 existing JVM tests across 9 suites, full Android release lint (zero errors, one dependency-version advisory), R8 optimization, resource shrinking, APK integrity, ZIP alignment, and APK Signature Schemes v2/v3 passed on 2026-11-10 without an emulator. Kotlin explicitly targets JVM 17 to match the Java build target.

No physical Android device was attached; the existing JVM tests do not validate system widget binding/configuration, widget touch behavior, or swipe interaction. These require acceptance testing on the phone. Widget availability depends on apps publishing standard Android AppWidgetProvider components; not every installed app offers widgets. Widgets cannot be assumed to survive a launcher data restore on a different installation because host widget IDs are Android-managed.
