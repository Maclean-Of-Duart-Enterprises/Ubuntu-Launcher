Ubuntu Launcher 1.1.3 navigation update

- Desktop navigation by optional edge tapping and horizontal swipe.
- Removed bottom desktop navigation and Add Widget buttons.
- Independent tap and swipe directions for Applications list and Settings.
- Widget picker and per-screen widget removal in Desktop settings.
- Screen count, screen selection, shortcut destination, and reorder controls in Desktop settings.
- Gesture priority: Applications, Settings, then desktop navigation.

This supplied navigation revision was promoted to release 1.1.4 (versionCode 33). Its malformed Add/Remove Widget click handlers were repaired. Release compilation, 39 existing unit tests, full Android release lint, optimization, signed assembly, APK integrity, ZIP alignment, and v2/v3 signature verification passed without an emulator on 2026-11-10. Physical-device navigation and widget behavior remain unverified; see BUILD_VERIFICATION.md.
