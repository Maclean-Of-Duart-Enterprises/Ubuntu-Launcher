# Ubuntu Launcher 1.1.4 — Desktop navigation settings

- Version name 1.1.4; Android version code 33.
- Builds the supplied edge-tap/swipe desktop navigation and removes the former bottom desktop navigation/Widget buttons.
- Retains independent Applications and Settings swipe and edge-tap preferences.
- Places desktop-screen selection, order, shortcut destination, widget addition/removal, and navigation options in Desktop settings.
- Corrects malformed Add/Remove Widget click handlers and uses LocalActivity to access the host activity safely from those controls.
- Retains the package name and established release signing identity for in-place upgrades.

Verification: all 39 existing release JVM tests passed; full release lint reported no issues; R8 and resource optimization, signed assembly, APK integrity, alignment, and v2/v3 signature verification passed. No emulator or physical Android device was used. The existing tests do not exercise touch gestures or Android's widget picker/configuration workflow; check these on the phone.
