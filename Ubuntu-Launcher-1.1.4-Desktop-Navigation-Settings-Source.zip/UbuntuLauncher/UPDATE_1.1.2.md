# 1.1.2 — Home resume initialization

- Keep HOME activity registration unchanged; Android is responsible for starting the selected default Home app.
- Refresh installed app inventory whenever the launcher resumes, including return from boot/unlock and other applications.
- Keep first Home composition immediate; app inventory loads asynchronously.
- Do not erase an existing app inventory when a refresh fails.
- Increment versionCode to 31 and versionName to 1.1.2.

## Device verification required

Set Ubuntu Launcher as the Android default Home application, reboot and unlock, then confirm Home renders without manual refresh. Test Home key and returning from another app. Android OEM boot restrictions and the taskbar overlay may require separate investigation if the issue persists.
