# Ubuntu Launcher 1.1.4

## Desktop navigation and settings management (`versionCode 33`)

- Builds the supplied desktop-navigation update as version 1.1.4 with a higher Android version code.
- Removes bottom-of-desktop Previous, Next, and Add Widget buttons; desktop screens use configurable edge taps and horizontal swipes instead.
- Adds independent left/right/off edge-tap controls for Applications and Settings alongside their independent swipe controls.
- Moves screen selection, ordering, shortcut destination, widget addition/removal, and navigation controls into Desktop settings.
- Repairs the supplied Add/Remove Widget click handlers so they compile and invoke the selected screen's widget actions directly.
- Retains JVM 17 targeting, the established release certificate, and existing launcher preferences.
- Built and verified without an emulator: all 39 existing release unit tests and full release lint passed, followed by R8/resource optimization and APK integrity, alignment, and v2/v3 signature verification. Physical-device navigation and widget interaction remain acceptance checks.

## Previous 1.1.3 independent swipes and multi-screen widgets (`versionCode 32`)

- Independently selects Off, Left, or Right for the Applications-list and Settings swipe actions, retaining legacy preferences as migration defaults.
- Supports adding desktop screens without a fixed page-count limit, with Previous/Next navigation and per-page shortcut storage.
- Hosts standard Android app widgets on each desktop screen using the Android widget picker; a single widget fills the available page area, while multiple widgets stack vertically.
- Adds per-widget removal and a configurable destination page for shared files, folders, and website shortcuts.
- Retains the supplied Home startup/resume repair and existing launcher features.
- Explicitly targets JVM 17 for Java and Kotlin to keep release builds consistent across host JDKs.
- Built, optimized, signed, and verified without an emulator. All 39 existing release tests passed; full release lint passed with zero errors and one dependency-version advisory. Physical-device widget and gesture acceptance remains required.

## Previous 1.1.0 bi-color application icons (`versionCode 29`)

- Replaced destructive icon recoloring with a separate user-selected background tile and intact application artwork.
- Draws the original application icon at 78% scale over the selected tile color for two distinct, readable color layers.
- Applies opacity to the combined tile and icon while keeping portrait and landscape settings independent.
- Uses the corrected implementation consistently in grid and list layouts; unrecolored icons remain unchanged.
- Promoted the completed bi-color revision to version 1.1.0 for release.

## Previous 1.0.4.020 application icon tint and opacity correction (`versionCode 27`)

- Replaced flat `SrcIn` recoloring with `Modulate` tinting so application artwork remains recognizable instead of becoming a solid silhouette.
- Kept tint and opacity as separate controls in portrait and landscape, across both grid and list layouts.
- Preserved exact original colors when recoloring is disabled; white tint preserves source RGB when recoloring is enabled.
- Built, optimized, signed, and verified without an emulator.

## Previous 1.0.4.019 per-orientation application icon opacity (`versionCode 26`)

- Added independent 0–100% application-icon opacity controls for portrait and landscape under **Settings → Applications list**.
- Applied opacity to actual application icons in both grid and list layouts, with or without icon recoloring.
- Left application labels and package text fully readable while icon transparency changes.
- Added normalized preference handling and four focused tests for valid, transparent, opaque, and out-of-range values.
- Built, optimized, signed, and verified without an emulator.

## Previous 1.0.4.018 Light, Dark, and Auto application appearance (`versionCode 25`)

- Added persistent Light, Dark, and Auto (Android system) appearance choices under **Display settings**.
- Applied the selected mode immediately to Material settings surfaces, menus, dialogs, headers, and status/navigation icon contrast.
- Preserved wallpapers, desktop/taskbar styling, icon tints, clock colors, and other explicitly customized colors.
- Repaired the supplied theme implementation to use lifecycle-safe `LocalActivity` instead of casting `LocalContext`.
- Kept system-bar icon contrast synchronized after launcher resume, rotation, and system-bar visibility changes.
- Added four focused unit tests for Light, Dark, Auto, and preference-fallback behavior.
- Built, optimized, signed, and verified without an emulator.

## Previous 1.0.4.017 compact application-drawer search layout (`versionCode 24`)

- Moved the Settings and Close controls into a dedicated full-width header above the search bar.
- Gave the search field its own full-width row so it stays usable in narrow portrait and landscape popout drawers.
- Kept the search input and placeholder to one line, with ellipsis overflow instead of vertical character wrapping.
- Preserved search behavior, independent portrait/landscape drawer placement, popout extent, and taskbar-derived edge selection.
- Built, optimized, signed, and verified without an emulator.

## Previous 1.0.4.016 independent orientation drawer profiles and placement (`versionCode 23`)

- Added explicit Portrait and Landscape profile selectors under **Settings → Applications list**.
- Stored grid/list mode independently for each orientation while retaining the former global choice as an upgrade fallback.
- Added independent Left, Center, and Right application-panel placement for portrait and landscape.
- Kept panel extent, icon and label sizes, grid-label visibility, scroll direction, icon tint, and background color independent for each orientation.
- Applied the selected placement to the actual application-panel surface; taskbar-derived placement remains the fallback until a choice is saved.
- Repaired the supplied orientation-selector initializer so the new settings compile correctly.

## Previous 1.0.4.015 consolidated Applications settings and grid-label visibility (`versionCode 22`)

- Moved application drawer and grid controls into **Settings → Applications list**, while keeping editable display-text typography under portrait and landscape Display settings.
- Added independent portrait/landscape switches for showing or hiding application names beneath icons in grid view.
- Retained grid/list selection, popout extent, icon size, label size, grid scroll direction, icon recoloring, drawer background color, and pinned-app guidance in the Applications section.
- Repaired the color-control text field state binding that prevented the supplied source from compiling.

## Previous 1.0.4.014 interactive application and display colors (`versionCode 21`)

- Added reusable interactive hue wheels with saturation and brightness controls, a live swatch, and validated hex input.
- Applied the controls to application-icon tint, application-drawer background, display text, and clock/date colors.
- Added separate application-drawer background colors for portrait and landscape.
- Corrected application grid/list controls so Compose state updates immediately.

## Previous 1.0.4.013 application-list personalization and document shortcuts (`versionCode 20`)

- Added optional per-orientation application-icon tinting and vertical or horizontal grid scrolling.
- Added long-press drawer pins with pinned-first ordering in grid and list modes.
- Added ten display-text style presets, 1–80 sp sizing, normal/bold/italic choices, and per-orientation text colors.
- Added Android document-picker actions for pinning individual files and folders while retaining read access.

## Previous 1.0.4.012 landscape display-settings repair (`versionCode 19`)

- Moved system-bar controls into the same bounded, scrollable display-settings list as the remaining orientation controls.
- Constrained portrait and landscape settings to the available screen area and added bottom content padding so every control remains reachable.
- Added horizontal scrolling to image-scaling, clock-font, and border-design choices so narrow landscape layouts no longer clip or block options.
- Preserved independent portrait and landscape values and immediate live updates.

## Previous 1.0.4.011 orientation-specific application-list sizing (`versionCode 18`)

- Added independent application icon-size controls under portrait and landscape display settings.
- Added independent application label/text-size controls under portrait and landscape display settings.
- Applied the selected sizes immediately to both grid and list application-drawer layouts.
- Adjusted adaptive grid cell sizing and multi-line labels so larger icons and text remain readable.
- Added range normalization and unit coverage for restored or malformed size preferences.

## Previous 1.0.4.010 visual taskbar placeholder and popout application drawer (`versionCode 17`)

- Replaced the placeholder's code-only color setup with an interactive hue wheel plus saturation and brightness controls.
- Added independent primary and secondary placeholder colors with a live preview; the optional hex field remains available for exact values.
- Added Solid, Linear gradient, Radial gradient, Stripes, Dots, and Checker placeholder designs.
- Added a separate 0–100% placeholder opacity control without altering either saved color.
- Applied the complete placeholder design consistently to the Home taskbar and the foreground draw-over-apps taskbar.
- Converted the application drawer from a full-screen page into a rounded popout panel over a dismissible desktop scrim.
- Added independent portrait and landscape **Applications popout edge** sliders from 40–100%; defaults are 88% in portrait and 62% in landscape.
- The popout automatically opens from the same edge as the taskbar Applications button, including reversed top/bottom taskbar directions.

## Previous 1.0.4.009 transparent, keyboard-safe and auto-hiding overlay taskbar (`versionCode 16`)

- Added independent portrait and landscape **Background opacity** controls from 0–100%; 0% leaves floating taskbar icons with no dark strip.
- Applied the chosen opacity immediately to both the Home taskbar and the taskbar displayed over other apps.
- The foreground overlay now follows each orientation's existing **Auto hide** setting and delay.
- When auto-hide collapses the overlay, it shows the same configurable reveal square in the nine-dot Applications-button slot; tapping it restores the full taskbar.
- Touching or scrolling the foreground taskbar restarts its auto-hide countdown.
- Added **Let the keyboard cover the taskbar**, enabled by default, so the taskbar cannot block keyboard keys while typing; users can turn it off when they prefer the taskbar to stay above the keyboard.
- Documented Android's platform limitation: a normal draw-over-apps window cannot resize unrelated applications or reserve permanent desktop space without privileged system/OEM support.

## Previous 1.0.4.008 optional taskbar over other apps (`versionCode 15`)

- Added **Show taskbar over other apps** under **Settings → Desktop settings → Taskbar**.
- Uses Android's explicit **Display over other apps** permission and a user-visible foreground-service notification.
- The overlay follows the active portrait/landscape taskbar position, size, flow direction, and pinned-app order.
- The nine-dot Applications button opens Ubuntu Launcher's app drawer; pinned applications launch directly from the overlay.
- The overlay is non-focusable, so it does not capture typing, and it is removed while Ubuntu Launcher itself is visible to prevent a duplicate taskbar.
- Per-orientation **Hide taskbar** remains authoritative. Version 1.0.4.009 extends the existing **Auto hide** behavior to the foreground overlay.
- Added a notification action that immediately turns off the taskbar overlay.

## Previous 1.0.4.007 configurable taskbar flow direction (`versionCode 14`)

- Added a contextual **Direction** control under each portrait and landscape taskbar configuration.
- Left/right taskbars can start from the top and flow downward or start from the bottom and flow upward.
- Top/bottom taskbars can start from the left and flow rightward or start from the right and flow leftward.
- The nine-dot Applications button, pinned-app order, scrolling direction, auto-hide control, and hidden reveal square all follow the selected direction.
- Existing installations default to the prior behavior: downward for side taskbars and rightward for top/bottom taskbars.

## Previous 1.0.4.006 orientation-specific taskbar and reveal square (`versionCode 13`)

- Added a Portrait/Landscape selector under **Settings → Desktop settings → Taskbar**.
- Position, size, hidden state, auto-hide state, and auto-hide delay are now stored independently for each orientation.
- Existing taskbar choices remain the migration defaults until the user customizes an orientation, so upgrades preserve the current layout.
- Replaced the 14 dp orange auto-hide dot with a larger 26 dp rounded square and added a manual `#RRGGBB` / `#AARRGGBB` color setting.
- The reveal square now occupies the exact screen slot used by the nine-dot Applications button when the taskbar is visible.
- Taskbar changes continue to apply immediately without restarting the phone.

## Previous 1.0.4.005 orientation-specific system bars (`versionCode 12`)

- Added **Hide Android status bar** and **Hide Android navigation bar** under both portrait and landscape display settings.
- Portrait and landscape choices are stored independently and default to disabled for backward-compatible behavior.
- Changes apply immediately and are restored after rotation or returning to the launcher without restarting the phone.
- Uses Android's compatibility insets controller with transient swipe-to-reveal behavior instead of deprecated system-UI flags.

## Previous 1.0.4.004 ordered taskbar pins (`versionCode 11`)

- Added a dedicated pinned-app ordering section at the top of **Settings → Desktop settings → Taskbar pinned apps**.
- Pinned apps can be moved earlier or later with clear arrow controls, allowing any taskbar order without gesture conflicts.
- New pins are appended to the chosen order, removed pins are deleted cleanly, and changes appear on the home-screen taskbar immediately.
- Existing unordered pins migrate automatically into a stable order without losing the user's selections.
- Preserves unavailable pinned package entries so their chosen position can be recovered if an app is reinstalled.

## Previous 1.0.4.003 live settings refresh hotfix (`versionCode 10`)

- Fixed launcher settings that were saved but did not appear until the phone restarted.
- Clock placement, clock text, typography, color, and visibility now update on the launcher immediately.
- Taskbar pinned apps, taskbar position, size, visibility, and auto-hide settings now refresh immediately.
- Wallpaper, desktop layout, shared shortcuts, weather, swipe actions, and app-drawer presentation now observe the same live preference revision.
- Retains the Dumb Phone notification-filter, Home-gesture, favicon, icon, lock-screen, and desktop-layout fixes from prior 1.0.4 builds.

## Dumb Phone notification-filter hotfix (`versionCode 9`, version 1.0.4.002)

- Repaired Dumb Phone notification filtering for apps outside the selected allowlist.
- The listener now filters newly posted notifications and immediately reconciles already-active notifications when it connects or when Dumb Phone settings change.
- Added automatic listener rebind recovery and explicit support for conversation, alerting, silent, and ongoing notification types.
- Enabling the filter without Android notification access now opens Ubuntu Launcher's app-specific permission screen.
- Dumb Phone Settings now shows whether notification access is granted and clearly warns when the filter cannot run.
- Android still controls protected system and non-dismissible foreground-service notifications; those cannot always be removed by a third-party listener.

## Swipe/Home hotfix (`versionCode 8`)

- Repaired the black screen that could appear when Android returned to the launcher with an upward Home gesture.
- Aligned the HOME activity task and restoration behavior with Android Launcher3: single launcher task, cleared stale task state, state-not-needed recovery, and empty task affinity.
- System **All Apps** intents now open the application drawer; ordinary Home, icon-launch, and Share intents restore the desktop.
- Isolated installed-app and third-party icon failures so one invalid app entry cannot take down the Home surface.
- Added an aubergine window fallback while Compose restores, avoiding a black launch window.
- Reframed the supplied icon inside Android's adaptive safe area so the complete centered artwork remains visible under device-specific masks.

## Desktop layout

- The clock and custom text now occupy a reserved grid row and cannot overlap shared files or website links.
- Hold a file or website shortcut for three seconds to enter move mode. Drag it to a visible slot, or release, scroll, and tap any destination. Moving onto an occupied slot swaps the two shortcuts.
- Shortcut positions are saved independently for the main and secondary pages in portrait and landscape.
- Landscape supports 2–14 columns; portrait supports 2–8 columns.
- File and link rows expand as needed and scroll vertically in both orientations.

## Website icons

- Restored favicon loading without a background WebView.
- Discovers page icon links, Apple touch icons, web-manifest icons, and conventional favicon locations.
- Follows redirects and caches successful icons in memory and on disk for faster subsequent launches.

## Existing 1.0.3.002 improvements retained

- Updated Ubuntu Launcher app icon.
- Separate portrait and landscape display settings, including top/center/bottom and left/center/right clock placement.
- Launcher PIN/password activation, immediate **Lock now**, incorrect-entry feedback, and automatic re-lock after the launcher leaves the foreground.

The launcher lock protects the Ubuntu Launcher interface; Android's secure system keyguard remains the device-level lock.
