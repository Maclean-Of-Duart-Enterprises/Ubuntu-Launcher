package com.macleanofduartenterprises.ubuntulauncher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.*
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.automirrored.filled.ViewSidebar
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.graphics.ColorFilter
import android.provider.OpenableColumns
import android.provider.DocumentsContract
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.*
import java.security.MessageDigest
import java.text.*
import java.util.*
import org.json.JSONObject
import org.json.JSONArray

private val Aubergine=Color(0xFF2C001E); private val Aubergine2=Color(0xFF3D1230); private val Orange=Color(0xFFE95420); private val Warm=Color(0xFFF7F3F0)
private const val PIN_ORDER_PREFERENCE="pins_order"
private const val PIN_ORDER_SEPARATOR="\u001F"
private const val THEME_MODE_KEY = "launcher_theme_mode"
data class AppItem(val label:String,val packageName:String,val activityName:String,val icon:Drawable)
data class SettingItem(val label:String,val subtitle:String,val action:String)

internal fun opensAppDrawerForLauncherAction(action:String?):Boolean =
    action=="android.intent.action.ALL_APPS"||
        action=="android.intent.action.SHOW_WORK_APPS"

internal fun resolveDarkThemeMode(mode:String?,systemDark:Boolean):Boolean=when(mode){
    "dark"->true
    "light"->false
    else->systemDark
}

class MainActivity:ComponentActivity(){
    private val fullscreenPreferenceListener =
        android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key?.startsWith("hide_system_") == true || key == THEME_MODE_KEY) applySystemBars()
        }

    private fun applySystemBars() {
        val orientation = if (resources.configuration.orientation ==
            android.content.res.Configuration.ORIENTATION_LANDSCAPE) "landscape" else "portrait"
        val hideStatus = prefs.getBoolean("hide_system_status_$orientation", false)
        val hideNavigation = prefs.getBoolean("hide_system_navigation_$orientation", false)
        val systemDark = (resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val dark = resolveDarkThemeMode(prefs.getString(THEME_MODE_KEY, "auto"), systemDark)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (hideStatus) hide(WindowInsetsCompat.Type.statusBars())
            else show(WindowInsetsCompat.Type.statusBars())
            if (hideNavigation) hide(WindowInsetsCompat.Type.navigationBars())
            else show(WindowInsetsCompat.Type.navigationBars())
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }

    override fun onResume() {
        super.onResume()
        applySystemBars()
        homeResumeRevision++
        TaskbarOverlayController.sync(this, prefs, launcherVisible = true)
    }

    override fun onPause() {
        TaskbarOverlayController.setLauncherVisible(this, prefs, visible = false)
        super.onPause()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applySystemBars()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(fullscreenPreferenceListener)
        super.onDestroy()
    }

    private val widgetHost by lazy { AppWidgetHost(this, 73019) }
    private val widgetManager by lazy { AppWidgetManager.getInstance(this) }
    private var pendingWidgetId = -1
    private var pendingWidgetPage = 0
    private val configureWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) savePendingWidget() else discardPendingWidget()
    }
    private val bindWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) finishWidgetBinding() else discardPendingWidget()
    }
    private val selectWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK) { discardPendingWidget(); return@registerForActivityResult }
        val data = result.data
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
        if (id != pendingWidgetId || id < 0) { discardPendingWidget(); return@registerForActivityResult }
        finishWidgetBinding()
    }
    fun createHostedWidgetView(context: Context, id: Int, info: AppWidgetProviderInfo) =
        widgetHost.createView(context, id, info).apply { setAppWidget(id, info) }
    fun addWidgetToPage(page: Int) {
        if (pendingWidgetId >= 0) return
        pendingWidgetPage = page
        pendingWidgetId = widgetHost.allocateAppWidgetId()
        val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId)
        }
        runCatching { selectWidget.launch(intent) }.onFailure { discardPendingWidget() }
    }
    private fun finishWidgetBinding() {
        val id = pendingWidgetId
        if (id < 0) return
        val info = widgetManager.getAppWidgetInfo(id)
        if (info == null) { discardPendingWidget(); return }
        if (info.configure != null) {
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                component = info.configure
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            }
            runCatching { configureWidget.launch(intent) }.onFailure { discardPendingWidget() }
        } else savePendingWidget()
    }
    private fun savePendingWidget() {
        val id = pendingWidgetId
        if (id < 0) return
        if (widgetManager.getAppWidgetInfo(id) == null) { discardPendingWidget(); return }
        val key = "desktop_widget_page_$pendingWidgetPage"
        prefs.edit().putString(key, (prefs.getString(key, "").orEmpty().split(',').mapNotNull { it.toIntOrNull() } + id).distinct().joinToString(",")).apply()
        pendingWidgetId = -1
    }
    private fun discardPendingWidget() {
        if (pendingWidgetId >= 0) runCatching { widgetHost.deleteAppWidgetId(pendingWidgetId) }
        pendingWidgetId = -1
    }
    fun removeWidgetFromPage(page: Int, id: Int) {
        val key = "desktop_widget_page_$page"
        val remaining = prefs.getString(key, "").orEmpty().split(',').mapNotNull { it.toIntOrNull() }.filter { it != id }
        prefs.edit().putString(key, remaining.joinToString(",")).apply()
        runCatching { widgetHost.deleteAppWidgetId(id) }
    }
    override fun onStart() { super.onStart(); runCatching { widgetHost.startListening() } }
    override fun onStop() { runCatching { widgetHost.stopListening() }; super.onStop() }
    private val prefs by lazy{getSharedPreferences("launcher",MODE_PRIVATE)}
    private var launcherIntentRevision by mutableIntStateOf(0)
    private var homeResumeRevision by mutableIntStateOf(0)
    private var launcherIntentOpensApps by mutableStateOf(false)
    private val roleRequest=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){}
    private val photos=registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->
        if(uris.isNotEmpty()){uris.forEach{runCatching{contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}};prefs.edit().putStringSet(wallKey(prefs,prefs.getBoolean("picking_dumb",false),prefs.getString("picking_orientation","portrait") ?: "portrait"),uris.map{it.toString()}.toSet()).apply()}
    }
    private val file=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri-> uri?.let{
        runCatching{contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
        val page=prefs.getString("shortcut_target_page","main")?:"main"; val key="desktop_files_$page"; val set=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();val name=runCatching{contentResolver.query(it,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{cursor->if(cursor.moveToFirst())cursor.getString(0) else null}}.getOrNull()?:"Pinned file";set.add("${it}|${name.replace("|"," ")}");prefs.edit().putStringSet(key,set).apply()
    }}
    private val folder=registerForActivityResult(ActivityResultContracts.OpenDocumentTree()){uri->uri?.let{
        runCatching{contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
        val page=prefs.getString("shortcut_target_page","main")?:"main"
        val key="desktop_files_$page"
        val name=runCatching{DocumentsContract.getTreeDocumentId(it).substringAfterLast(':').substringAfterLast('/')}.getOrDefault("Folder")
        val set=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.add("$it|${name.replace("|"," ")}");prefs.edit().putStringSet(key,set).apply()
    }}
    fun chooseFolder(){folder.launch(null)}
    val backupOut=registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->uri?.let{exportBackup(it)}}
    val backupIn=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->uri?.let{importBackup(it);recreate()}}
    private fun exportBackup(uri:Uri){val root=JSONObject();prefs.all.forEach{(k,v)->when(v){is String->root.put(k,v);is Boolean->root.put(k,v);is Int->root.put(k,v);is Long->root.put(k,v);is Float->root.put(k,v);is Set<*>->root.put(k,JSONArray(v.filterIsInstance<String>()))}};contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(root.toString(2))}}
    private fun importBackup(uri:Uri){val text=contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:return;val root=JSONObject(text);val e=prefs.edit().clear();root.keys().forEach{k->when(val v=root.get(k)){is Boolean->e.putBoolean(k,v);is Int->e.putInt(k,v);is Long->e.putLong(k,v);is Double->e.putFloat(k,v.toFloat());is JSONArray->{val set=mutableSetOf<String>();for(i in 0 until v.length())set.add(v.getString(i));e.putStringSet(k,set)}else->e.putString(k,v.toString())}};e.apply()}
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        prefs.registerOnSharedPreferenceChangeListener(fullscreenPreferenceListener)
        applySystemBars()
        consumeLauncherIntent(intent,notifyComposition=false)
        setContent{
            LauncherApp(
                prefs,
                {d,o->prefs.edit().putBoolean("picking_dumb",d).putString("picking_orientation",o).apply();photos.launch(arrayOf("image/*"))},
                {file.launch(arrayOf("*/*"))},
                launcherIntentRevision,
                launcherIntentOpensApps,
                homeResumeRevision
            )
        }
    }
    override fun onNewIntent(intent:Intent){
        super.onNewIntent(intent)
        setIntent(intent)
        consumeLauncherIntent(intent,notifyComposition=true)
    }
    private fun consumeLauncherIntent(intent:Intent,notifyComposition:Boolean){
        acceptShare(intent)
        launcherIntentOpensApps=opensAppDrawerForLauncherAction(intent.action)
        if(notifyComposition)launcherIntentRevision++
    }
    private fun acceptShare(i:Intent){if(i.action!=Intent.ACTION_SEND)return; val e=prefs.edit(); val uri=if(Build.VERSION.SDK_INT>=33)i.getParcelableExtra(Intent.EXTRA_STREAM,Uri::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM); val page=prefs.getString("shortcut_target_page","main")?:"main"; val suffix=page; if(uri!=null){if(i.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION!=0&&i.flags and Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION!=0)runCatching{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)};val key="desktop_files_$suffix";val s=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();s.add("$uri|Shared file");e.putStringSet(key,s)}; i.getStringExtra(Intent.EXTRA_TEXT)?.let{t->if(t.startsWith("http")){val key="desktop_links_$suffix";val s=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();s.add("$t|Shared link");e.putStringSet(key,s)}};e.apply()}
    fun requestHome(){if(Build.VERSION.SDK_INT>=29){val r=getSystemService(RoleManager::class.java);if(r.isRoleAvailable(RoleManager.ROLE_HOME)&&!r.isRoleHeld(RoleManager.ROLE_HOME))roleRequest.launch(r.createRequestRoleIntent(RoleManager.ROLE_HOME))}else startActivity(Intent(Settings.ACTION_HOME_SETTINGS))}
}
fun loadApps(c:Context):List<AppItem>{
 val manager=c.packageManager
 val query=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
 return runCatching{manager.queryIntentActivities(query,0)}.getOrDefault(emptyList())
  .filter{it.activityInfo.packageName!=c.packageName}
  .mapNotNull{info->runCatching{AppItem(info.loadLabel(manager).toString(),info.activityInfo.packageName,info.activityInfo.name,info.loadIcon(manager))}.getOrNull()}
  .distinctBy{it.packageName+it.activityName}
  .sortedBy{it.label.lowercase()}
}
fun launch(c:Context,a:AppItem)=runCatching{c.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(ComponentName(a.packageName,a.activityName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}.let{}
fun openSetting(c:Context,a:String)=runCatching{c.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}.let{}
fun hash(v:String)=MessageDigest.getInstance("SHA-256").digest(v.toByteArray()).joinToString(""){"%02x".format(it)}

internal fun resolvePinnedOrder(
 selected:Set<String>,
 stored:String?,
 installedInDisplayOrder:List<String>
):List<String>{
 val installed=installedInDisplayOrder.distinct()
 val installedSet=installed.toSet()
 val saved=stored.orEmpty().split(PIN_ORDER_SEPARATOR).filter{it.isNotBlank()}.distinct()
 val orderedInstalled=saved.filter{it in selected&&it in installedSet}.toMutableList()
 orderedInstalled.addAll(installed.filter{it in selected&&it !in orderedInstalled})
 val unavailable=saved.filter{it in selected&&it !in installedSet}.toMutableList()
 unavailable.addAll(selected.filter{it !in installedSet&&it !in unavailable}.sorted())
 return orderedInstalled+unavailable
}

internal fun movePinnedPackage(order:List<String>,packageName:String,offset:Int):List<String>{
 val from=order.indexOf(packageName)
 if(from<0)return order
 val to=(from+offset).coerceIn(0,order.lastIndex)
 if(from==to)return order
 return order.toMutableList().apply{add(to,removeAt(from))}
}

internal fun orderedPinnedPackages(p:android.content.SharedPreferences,apps:List<AppItem>)=
 resolvePinnedOrder(
  p.getStringSet("pins",emptySet()).orEmpty(),
  p.getString(PIN_ORDER_PREFERENCE,null),
  apps.map{it.packageName}
 )

private fun savePinnedApps(p:android.content.SharedPreferences,selected:Set<String>,order:List<String>){
 val normalized=resolvePinnedOrder(selected,order.joinToString(PIN_ORDER_SEPARATOR),order)
 p.edit().putStringSet("pins",selected).putString(PIN_ORDER_PREFERENCE,normalized.joinToString(PIN_ORDER_SEPARATOR)).apply()
}

private fun notificationFilterComponent(context:Context)=
 ComponentName(context,NotificationFilterService::class.java)

fun hasNotificationListenerAccess(context:Context):Boolean {
 val component=notificationFilterComponent(context)
 return if(Build.VERSION.SDK_INT>=27){
  runCatching{context.getSystemService(NotificationManager::class.java).isNotificationListenerAccessGranted(component)}
   .getOrElse{context.packageName in NotificationManagerCompat.getEnabledListenerPackages(context)}
 }else context.packageName in NotificationManagerCompat.getEnabledListenerPackages(context)
}

fun openNotificationListenerSettings(context:Context){
 val component=notificationFilterComponent(context)
 val detail=if(Build.VERSION.SDK_INT>=30){
  Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
   .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,component.flattenToString())
 }else null
 val destination=listOfNotNull(detail,Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
  .firstOrNull{it.resolveActivity(context.packageManager)!=null}
 destination?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let{runCatching{context.startActivity(it)}}
}

@Composable
private fun rememberNotificationListenerAccess(context:Context):Boolean {
 val lifecycleOwner=LocalLifecycleOwner.current
 var granted by remember(context){mutableStateOf(hasNotificationListenerAccess(context))}
 DisposableEffect(lifecycleOwner,context){
  val observer=LifecycleEventObserver{_,event->
   if(event==Lifecycle.Event.ON_RESUME)granted=hasNotificationListenerAccess(context)
  }
  lifecycleOwner.lifecycle.addObserver(observer)
  onDispose{lifecycleOwner.lifecycle.removeObserver(observer)}
 }
 return granted
}

@Composable
private fun rememberTaskbarOverlayPermission(context:Context):Boolean {
 val lifecycleOwner=LocalLifecycleOwner.current
 var granted by remember(context){mutableStateOf(TaskbarOverlayController.hasPermission(context))}
 DisposableEffect(lifecycleOwner,context){
  val observer=LifecycleEventObserver{_,event->
   if(event==Lifecycle.Event.ON_RESUME)granted=TaskbarOverlayController.hasPermission(context)
  }
  lifecycleOwner.lifecycle.addObserver(observer)
  onDispose{lifecycleOwner.lifecycle.removeObserver(observer)}
 }
 return granted
}

@Composable fun LauncherApp(p:android.content.SharedPreferences,pickPhotos:(Boolean,String)->Unit,pickFile:()->Unit,launcherIntentRevision:Int=0,launcherIntentOpensApps:Boolean=false,homeResumeRevision:Int=0){
 val c=LocalContext.current;val appContext=c.applicationContext;val scope=rememberCoroutineScope();var apps by remember{mutableStateOf<List<AppItem>>(emptyList())};var settings by remember{mutableStateOf(false)};var drawer by remember{mutableStateOf(false)};var q by remember{mutableStateOf("")};var preferenceRevision by remember{mutableIntStateOf(0)}
 LaunchedEffect(launcherIntentRevision){settings=false;drawer=launcherIntentOpensApps;q=""}
 suspend fun refreshApps(){
  val loaded=withContext(Dispatchers.IO){runCatching{loadApps(appContext)}.getOrNull()}
  if(loaded!=null) apps=loaded
 }
 // A HOME activity can be retained while Android switches away and back. Reload
 // the installed apps on each foreground transition instead of requiring a
 // manual desktop refresh; the initial HOME composition remains immediate.
 LaunchedEffect(appContext,homeResumeRevision){refreshApps()}
 DisposableEffect(p){
  val listener=android.content.SharedPreferences.OnSharedPreferenceChangeListener{_,_->preferenceRevision++}
  p.registerOnSharedPreferenceChangeListener(listener)
  onDispose{p.unregisterOnSharedPreferenceChangeListener(listener)}
 }
 DisposableEffect(appContext){val r=object:BroadcastReceiver(){override fun onReceive(x:Context?,i:Intent?){scope.launch{refreshApps()}}};val f=IntentFilter().apply{addAction(Intent.ACTION_PACKAGE_ADDED);addAction(Intent.ACTION_PACKAGE_REMOVED);addAction(Intent.ACTION_PACKAGE_CHANGED);addDataScheme("package")};ContextCompat.registerReceiver(appContext,r,f,ContextCompat.RECEIVER_EXPORTED);onDispose{runCatching{appContext.unregisterReceiver(r)}}}
 val hidden=remember(preferenceRevision){p.getStringSet("hidden",emptySet()).orEmpty()};val dumb=remember(preferenceRevision){p.getBoolean("dumb_mode",false)};val allow=remember(preferenceRevision){p.getStringSet("dumb",emptySet()).orEmpty()};val visible=remember(apps,hidden,dumb,allow){apps.filter{it.packageName !in hidden&&(!dumb||it.packageName in allow)}}
 val lockEnabled=remember(preferenceRevision){p.getBoolean("lock_enabled",false)}
 val lockHash=remember(preferenceRevision){p.getString("lock_hash","").orEmpty()}
 val lockRequest=remember(preferenceRevision){p.getLong("lock_request",0L)}
 val hasLockCredential=lockHash.isNotBlank()
 var unlocked by remember{mutableStateOf(!(lockEnabled&&hasLockCredential))}
 LaunchedEffect(lockEnabled,lockHash,lockRequest){unlocked=!(lockEnabled&&hasLockCredential)}
 val lifecycleOwner=LocalLifecycleOwner.current
 DisposableEffect(lifecycleOwner,lockEnabled,hasLockCredential){
  val observer=LifecycleEventObserver{_,event->if(event==Lifecycle.Event.ON_STOP&&lockEnabled&&hasLockCredential)unlocked=false}
  lifecycleOwner.lifecycle.addObserver(observer)
  onDispose{lifecycleOwner.lifecycle.removeObserver(observer)}
 }
 UbuntuTheme(p,preferenceRevision){Box(Modifier.fillMaxSize()){Wallpaper(p,dumb,preferenceRevision);HomeShell(visible,apps,p,dumb,preferenceRevision,{drawer=true},{settings=true},pickFile){preferenceRevision++};if(drawer)AppDrawer(visible,q,{q=it},{drawer=false},{settings=true},p,preferenceRevision){preferenceRevision++};if(settings)LauncherSettings(apps,p,{settings=false},{preferenceRevision++},pickPhotos,pickFile,{(c as? MainActivity)?.backupOut?.launch("ubuntu-launcher-backup.json")},{(c as? MainActivity)?.backupIn?.launch(arrayOf("application/json","text/plain"))});if(!unlocked&&lockEnabled&&hasLockCredential)LockOverlay(p){unlocked=true}}}
}

fun decodeSampledImage(c:Context,uri:Uri,requestWidth:Int,requestHeight:Int):ImageBitmap?{val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};c.contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it,null,bounds)};if(bounds.outWidth<=0||bounds.outHeight<=0)return null;var sample=1;while(bounds.outWidth/(sample*2)>=requestWidth&&bounds.outHeight/(sample*2)>=requestHeight)sample*=2;val options=BitmapFactory.Options().apply{inSampleSize=sample;inPreferredConfig=Bitmap.Config.ARGB_8888};return c.contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it,null,options)}?.asImageBitmap()}

@Composable fun Wallpaper(p:android.content.SharedPreferences,dumb:Boolean,preferenceRevision:Int){val configuration=LocalConfiguration.current;val orientation=orientationName(configuration.orientation);val key=wallKey(p,dumb,orientation);val legacy=if(dumb)"wall_dumb" else "wall_regular";val uris=remember(preferenceRevision,key,legacy){p.getStringSet(key,p.getStringSet(legacy,emptySet())).orEmpty().toList()};var idx by remember(uris){mutableIntStateOf(0)};val interval=remember(preferenceRevision,dumb){p.getInt(if(dumb)"slide_dumb" else "slide_regular",15).coerceAtLeast(3)};val scale=remember(preferenceRevision,legacy,orientation){scaleFor(p.getString(settingKey("${legacy}_scale",orientation),"crop")?:"crop")};if(uris.size>1)LaunchedEffect(uris,interval){while(true){delay(interval*1000L);idx=(idx+1)%uris.size}};val c=LocalContext.current;val density=LocalDensity.current;val requestWidth=with(density){configuration.screenWidthDp.dp.roundToPx()};val requestHeight=with(density){configuration.screenHeightDp.dp.roundToPx()};val bm by produceState<ImageBitmap?>(null,uris,idx,requestWidth,requestHeight){value=uris.getOrNull(idx)?.let{u->withContext(Dispatchers.IO){runCatching{decodeSampledImage(c,Uri.parse(u),requestWidth,requestHeight)}.getOrNull()}}};if(bm!=null)Image(bm!!,null,Modifier.fillMaxSize(),contentScale=scale)else Box(Modifier.fillMaxSize().background(Aubergine2));Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=.18f)))}

@Composable fun HomeShell(visible:List<AppItem>,all:List<AppItem>,p:android.content.SharedPreferences,dumb:Boolean,preferenceRevision:Int,drawer:()->Unit,settings:()->Unit,pickFile:()->Unit,changed:()->Unit){
 val orientation=orientationName(LocalConfiguration.current.orientation)
 val defaultPosition=if(orientation=="landscape")"left" else "bottom"
 val pos=remember(preferenceRevision,orientation){p.getString(settingKey("taskbar_pos",orientation),p.getString("taskbar_pos",defaultPosition))?:defaultPosition}
 val size=remember(preferenceRevision,orientation){p.getInt(settingKey("taskbar_size",orientation),p.getInt("taskbar_size",64)).coerceIn(44,110)}
 val hide=remember(preferenceRevision,orientation){p.getBoolean(settingKey("taskbar_hide",orientation),p.getBoolean("taskbar_hide",false))}
 var autoShown by remember(orientation){mutableStateOf(true)}
 val auto=remember(preferenceRevision,orientation){p.getBoolean(settingKey("taskbar_auto",orientation),p.getBoolean("taskbar_auto",false))}
 val autoSeconds=remember(preferenceRevision,orientation){p.getInt(settingKey("taskbar_auto_seconds",orientation),p.getInt("taskbar_auto_seconds",3)).coerceAtLeast(1)}
 val revealStyle=remember(preferenceRevision,orientation){readTaskbarPlaceholderStyle(p,orientation)}
 val opacity=remember(preferenceRevision,orientation){normalizeTaskbarOpacity(p.getInt(settingKey("taskbar_opacity",orientation),p.getInt("taskbar_opacity",DEFAULT_TASKBAR_OPACITY_PERCENT)))}
 val direction=remember(preferenceRevision,orientation,pos){normalizeTaskbarDirection(pos,p.getString(settingKey("taskbar_direction",orientation),p.getString("taskbar_direction",defaultTaskbarDirection(pos)))?:defaultTaskbarDirection(pos))}
 val content: @Composable () -> Unit = { DesktopContent(visible,all,p,dumb,preferenceRevision,drawer,settings,pickFile,changed) }
 if(auto&&!hide) LaunchedEffect(pos,autoShown,autoSeconds,orientation){if(autoShown){delay(autoSeconds*1000L);autoShown=false}}
 Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()){
  if(!hide&&(!auto||autoShown)&&pos=="top")Taskbar(all,p,preferenceRevision,drawer,false,size,direction,opacity,auto){autoShown=!autoShown}
  Row(Modifier.weight(1f)){
   if(!hide&&(!auto||autoShown)&&pos=="left")Taskbar(all,p,preferenceRevision,drawer,true,size,direction,opacity,auto){autoShown=!autoShown}
   Box(Modifier.weight(1f)){content();if(!hide&&auto&&!autoShown)TaskbarRevealHandle(pos,direction,size,revealStyle){autoShown=true}}
   if(!hide&&(!auto||autoShown)&&pos=="right")Taskbar(all,p,preferenceRevision,drawer,true,size,direction,opacity,auto){autoShown=!autoShown}
  }
  if(!hide&&(!auto||autoShown)&&pos=="bottom")Taskbar(all,p,preferenceRevision,drawer,false,size,direction,opacity,auto){autoShown=!autoShown}
 }
}
@Composable private fun BoxScope.TaskbarRevealHandle(pos:String,direction:String,taskbarSize:Int,style:TaskbarPlaceholderStyle,show:()->Unit){
 val reversed=taskbarDirectionIsReversed(direction)
 val alignment=when(pos){
  "top"->if(reversed)Alignment.TopEnd else Alignment.TopStart
  "left"->if(reversed)Alignment.BottomStart else Alignment.TopStart
  "right"->if(reversed)Alignment.BottomEnd else Alignment.TopEnd
  else->if(reversed)Alignment.BottomEnd else Alignment.BottomStart
 }
 val slot=if(pos=="left"||pos=="right")Modifier.width(taskbarSize.dp).height(48.dp) else Modifier.width(48.dp).height(taskbarSize.dp)
 Box(Modifier.align(alignment).then(slot).clickable(onClickLabel="Show taskbar",onClick=show),contentAlignment=Alignment.Center){
  TaskbarPlaceholderPreview(style,Modifier.size(26.dp))
 }
}

@Composable
private fun TaskbarPlaceholderPreview(
 style:TaskbarPlaceholderStyle,
 modifier:Modifier=Modifier
){
 val primary=Color(colorWithOpacity(style.primaryArgb,style.opacityPercent))
 val secondary=Color(colorWithOpacity(style.secondaryArgb,style.opacityPercent))
 Canvas(modifier.clip(RoundedCornerShape(4.dp))){
  when(style.mode){
   "linear"->drawRect(brush=Brush.linearGradient(listOf(primary,secondary)))
   "radial"->drawCircle(brush=Brush.radialGradient(listOf(primary,secondary),center=center,radius=size.maxDimension*.72f),radius=size.maxDimension,center=center)
   "stripes"->{
    drawRect(primary)
    val gap=(size.minDimension/3f).coerceAtLeast(3f)
    var start=-size.height
    while(start<size.width){drawLine(secondary,Offset(start,size.height),Offset(start+size.height,0f),strokeWidth=(gap*.48f).coerceAtLeast(2f));start+=gap}
   }
   "dots"->{
    drawRect(primary)
    val gap=(size.minDimension/3f).coerceAtLeast(4f);val radius=(gap*.22f).coerceAtLeast(1f)
    var y=gap/2f
    while(y<size.height){var x=gap/2f;while(x<size.width){drawCircle(secondary,radius,Offset(x,y));x+=gap};y+=gap}
   }
   "checker"->{
    drawRect(primary)
    val square=(size.minDimension/3f).coerceAtLeast(3f);var row=0;var y=0f
    while(y<size.height){var column=0;var x=0f;while(x<size.width){if((row+column)%2==0)drawRect(secondary,Offset(x,y),androidx.compose.ui.geometry.Size(square,square));x+=square;column++};y+=square;row++}
   }
   else->drawRect(primary)
  }
 }
}

@Composable
private fun ColorWheelPicker(initialArgb:Int,onColorChanged:(Int)->Unit){
 val initial=remember(initialArgb){argbToHsv(initialArgb)}
 var hue by remember{mutableFloatStateOf(initial.hue)}
 var saturation by remember{mutableFloatStateOf(initial.saturation)}
 var brightness by remember{mutableFloatStateOf(initial.value)}
 fun updateHue(offset:Offset,width:Int,height:Int){
  val centerX=width/2f;val centerY=height/2f
  hue=((Math.toDegrees(atan2((offset.y-centerY).toDouble(),(offset.x-centerX).toDouble())).toFloat()+90f+360f)%360f)
  onColorChanged(hsvToArgb(hue,saturation,brightness))
 }
 Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxWidth()){
  Canvas(
   Modifier.size(196.dp).pointerInput(Unit){
    detectDragGestures(
     onDragStart={offset->updateHue(offset,size.width,size.height)},
     onDrag={change,_->change.consume();updateHue(change.position,size.width,size.height)}
    )
   }
  ){
   val wheelStroke=size.minDimension*.17f
   repeat(72){index->drawArc(Color(hsvToArgb(index*5f,1f,1f)),startAngle=index*5f-90f,sweepAngle=5.4f,useCenter=false,style=Stroke(wheelStroke))}
   val angle=Math.toRadians((hue-90f).toDouble());val indicatorRadius=size.minDimension/2f-wheelStroke/2f
   val indicator=center+Offset((cos(angle)*indicatorRadius).toFloat(),(sin(angle)*indicatorRadius).toFloat())
   drawCircle(Color.White,radius=wheelStroke*.25f,center=indicator,style=Stroke(width=3.dp.toPx()))
   drawCircle(Color(hsvToArgb(hue,saturation,brightness)),radius=size.minDimension*.22f,center=center)
  }
  Text("Saturation: ${(saturation*100).roundToInt()}%",Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=2.dp))
  Slider(saturation,{saturation=it;onColorChanged(hsvToArgb(hue,saturation,brightness))},modifier=Modifier.padding(horizontal=16.dp))
  Text("Brightness: ${(brightness*100).roundToInt()}%",Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=2.dp))
  Slider(brightness,{brightness=it;onColorChanged(hsvToArgb(hue,saturation,brightness))},modifier=Modifier.padding(horizontal=16.dp))
  Text(argbToOpaqueHex(hsvToArgb(hue,saturation,brightness)),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
 }
}

@Composable
private fun LauncherColorControl(label:String, initial:String, onChange:(String)->Unit) {
 var value by remember(initial) { mutableStateOf(initial) }
 var expanded by remember { mutableStateOf(false) }
 Column(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=6.dp)) {
  Row(verticalAlignment=Alignment.CenterVertically) {
   Text(label,Modifier.weight(1f),fontWeight=FontWeight.SemiBold)
   Box(Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)).background(chosenColor(value,Color.Black)))
   TextButton(onClick={expanded=!expanded}) { Text(if(expanded) "Close wheel" else "Choose color") }
  }
  if(expanded) {
   ColorWheelPicker(parseArgbColor(value,0xFFFFFFFF.toInt())) { selected ->
    val hex=argbToOpaqueHex(selected);value=hex;onChange(hex)
   }
  }
  OutlinedTextField(value=value,onValueChange={new->
   value=new
   if(normalizeHexColor(new)!=null)onChange(new)
  },label={Text("Hex color (#RRGGBB)")},singleLine=true,modifier=Modifier.fillMaxWidth())
 }
}

private enum class DesktopShortcutKind { FILE, WEBSITE, WEATHER }

private data class DesktopShortcut(
    val id: String,
    val kind: DesktopShortcutKind,
    val target: String,
    val label: String,
    val preferenceKey: String?,
    val entry: String
)

private fun desktopShortcutId(kind: DesktopShortcutKind, target: String): String =
    hash("desktop|" + kind.name + "|" + target)

private fun desktopPositionKey(page: String, orientation: String): String =
    "desktop_positions_" + page + "_" + orientation

private fun readDesktopPositions(
    preferences: android.content.SharedPreferences,
    key: String
): Map<String, Int> =
    parseDesktopPositions(preferences.getStringSet(key, emptySet()).orEmpty())

private fun saveDesktopPositions(
    preferences: android.content.SharedPreferences,
    key: String,
    positions: Map<String, Int>
) {
    preferences.edit().putStringSet(key, encodeDesktopPositions(positions)).apply()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DesktopContent(
    visible: List<AppItem>,
    all: List<AppItem>,
    p: android.content.SharedPreferences,
    dumb: Boolean,
    preferenceRevision: Int,
    drawer: () -> Unit,
    settings: () -> Unit,
    pickFile: () -> Unit,
    changed: () -> Unit
) {
    val context = LocalContext.current
    val orientation = orientationName(LocalConfiguration.current.orientation)
    val maxColumns = if (orientation == "landscape") 14 else 8
    val columns = remember(preferenceRevision, orientation) {
        p.getInt(
            settingKey("desktop_cols", orientation),
            p.getInt("desktop_cols", 4)
        ).coerceIn(2, maxColumns)
    }
    val pageCount = remember(preferenceRevision) {
        p.getInt("desktop_page_count", if(p.getBoolean("secondary_page_enabled",false)) 2 else 1).coerceAtLeast(1)
    }
    val pageSwipe = p.getString("desktop_page_swipe", "off") ?: "off"
    val pageTap = p.getBoolean("desktop_page_edge_tap", true)
    val appsSwipe = p.getString("swipe_apps_direction", "off") ?: "off"
    val settingsSwipe = p.getString("swipe_settings_direction", "off") ?: "off"
    val appsTap = p.getString("tap_apps_side", "off") ?: "off"
    val settingsTap = p.getString("tap_settings_side", "off") ?: "off"
    var pageIndex by remember { mutableIntStateOf(0) }
    if (pageIndex >= pageCount) pageIndex = pageCount - 1
    val page = if (pageIndex == 0) "main" else if (pageIndex == 1) "secondary" else "page_$pageIndex"
    val suffix = page
    val filePreferenceKey = "desktop_files_" + suffix
    val linkPreferenceKey = "desktop_links_" + suffix
    val files = remember(preferenceRevision, filePreferenceKey) {
        p.getStringSet(filePreferenceKey, emptySet()).orEmpty().toList()
    }
    val links = remember(preferenceRevision, linkPreferenceKey) {
        p.getStringSet(linkPreferenceKey, emptySet()).orEmpty().toList()
    }
    val weatherPackage = remember(preferenceRevision) {
        p.getStringSet("weather_app", emptySet()).orEmpty().firstOrNull()
    }
    val showWeather = remember(preferenceRevision) {
        p.getBoolean("show_weather", true)
    }

    val shortcuts = buildList {
        files.forEach { entry ->
            val parts = entry.split("|", limit = 2)
            val target = parts[0]
            add(
                DesktopShortcut(
                    desktopShortcutId(DesktopShortcutKind.FILE, target),
                    DesktopShortcutKind.FILE,
                    target,
                    parts.getOrElse(1) { "File" },
                    filePreferenceKey,
                    entry
                )
            )
        }
        links.forEach { entry ->
            val parts = entry.split("|", limit = 2)
            val target = parts[0]
            add(
                DesktopShortcut(
                    desktopShortcutId(DesktopShortcutKind.WEBSITE, target),
                    DesktopShortcutKind.WEBSITE,
                    target,
                    parts.getOrElse(1) { "Website" },
                    linkPreferenceKey,
                    entry
                )
            )
        }
        if (page == "main" && showWeather && weatherPackage != null) {
            add(
                DesktopShortcut(
                    desktopShortcutId(DesktopShortcutKind.WEATHER, weatherPackage),
                    DesktopShortcutKind.WEATHER,
                    weatherPackage,
                    "Weather",
                    null,
                    weatherPackage
                )
            )
        }
    }

    val itemIds = shortcuts.map { it.id }
    val positionKey = desktopPositionKey(suffix, orientation)
    val desktopIdentity = positionKey + "|" + itemIds.joinToString(",")
    var positions by remember(desktopIdentity) {
        mutableStateOf(
            normalizeDesktopPositions(itemIds, readDesktopPositions(p, positionKey))
        )
    }
    LaunchedEffect(desktopIdentity) {
        saveDesktopPositions(p, positionKey, positions)
    }

    var addLink by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }
    var label by remember { mutableStateOf("") }
    var manage by remember { mutableStateOf<Pair<String, String>?>(null) }
    var movingId by remember { mutableStateOf<String?>(null) }
    var dragSourceSlot by remember { mutableStateOf<Int?>(null) }
    var dropTargetSlot by remember { mutableStateOf<Int?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    val gridState = rememberLazyGridState()

    LaunchedEffect(page, orientation) {
        movingId = null
        dragSourceSlot = null
        dropTargetSlot = null
        dragOffset = Offset.Zero
    }

    fun commitMove(id: String, targetSlot: Int) {
        val updated = moveDesktopItem(positions, id, targetSlot)
        if (updated != positions) {
            positions = updated
            saveDesktopPositions(p, positionKey, updated)
        }
    }

    fun openShortcut(shortcut: DesktopShortcut) {
        when (shortcut.kind) {
            DesktopShortcutKind.FILE -> runCatching {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW).apply {
                        val uri=Uri.parse(shortcut.target)
                        setDataAndType(uri,if(shortcut.target.contains("/tree/")) "vnd.android.document/directory" else context.contentResolver.getType(uri)?:"*/*")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                )
            }
            DesktopShortcutKind.WEBSITE -> runCatching {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(shortcut.target)))
            }
            DesktopShortcutKind.WEATHER -> all.firstOrNull {
                it.packageName == shortcut.target
            }?.let { launch(context, it) }
        }
    }

    val showClock = remember(preferenceRevision, orientation) {
        p.getBoolean(
            settingKey("show_clock", orientation),
            p.getBoolean("show_clock", true)
        )
    }
    val customText = remember(preferenceRevision, orientation) {
        p.getString(
            settingKey("custom_text", orientation),
            p.getString("custom_text", "")
        ).orEmpty()
    }
    val clockVisible = showClock || customText.isNotBlank()
    val clockVertical = remember(preferenceRevision, orientation) {
        p.getString(settingKey("clock_vertical", orientation), "top") ?: "top"
    }
    val clockHorizontal = remember(preferenceRevision, orientation) {
        p.getString(settingKey("clock_horizontal", orientation), "left") ?: "left"
    }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    if (showClock) {
        LaunchedEffect(Unit) {
            while (true) {
                now = System.currentTimeMillis()
                delay(1_000L - (now % 1_000L))
            }
        }
    }

    val systemViewConfiguration = LocalViewConfiguration.current
    val moveViewConfiguration = remember(systemViewConfiguration) {
        object : ViewConfiguration by systemViewConfiguration {
            override val longPressTimeoutMillis: Long = SHORTCUT_MOVE_HOLD_MILLIS
        }
    }

    var horizontalDrag by remember { mutableFloatStateOf(0f) }
    val navigationModifier = Modifier.pointerInput(pageSwipe, appsSwipe, settingsSwipe, pageCount) {
        detectHorizontalDragGestures(
            onDragStart = { horizontalDrag = 0f },
            onHorizontalDrag = { _, distance -> horizontalDrag += distance },
            onDragEnd = {
                val direction = if(horizontalDrag > 120f) "right" else if(horizontalDrag < -120f) "left" else "off"
                if(direction != "off") {
                    when {
                        appsSwipe == direction -> drawer()
                        settingsSwipe == direction -> settings()
                        pageSwipe == "both" || pageSwipe == direction -> {
                            pageIndex = (pageIndex + if(direction == "left") 1 else -1).coerceIn(0,pageCount-1)
                        }
                    }
                }
                horizontalDrag = 0f
            }
        )
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        BoxWithConstraints(Modifier.weight(1f).then(navigationModifier)) {
            if(pageTap || appsTap != "off" || settingsTap != "off") {
                Row(Modifier.fillMaxSize().zIndex(20f),horizontalArrangement=Arrangement.SpaceBetween) {
                    listOf("left","right").forEach { side ->
                        val action = when {
                            appsTap == side -> "apps"
                            settingsTap == side -> "settings"
                            pageTap -> "page"
                            else -> "off"
                        }
                        Box(Modifier.width(36.dp).fillMaxHeight().then(if(action != "off") Modifier.clickable {
                            when(action) {
                                "apps" -> drawer()
                                "settings" -> settings()
                                "page" -> pageIndex=(pageIndex+if(side=="right")1 else -1).coerceIn(0,pageCount-1)
                            }
                        } else Modifier))
                    }
                }
            }
            val widgetIds = remember(preferenceRevision,pageIndex) {
                p.getString("desktop_widget_page_$pageIndex", "").orEmpty().split(',').mapNotNull { it.toIntOrNull() }
            }
            if (widgetIds.isNotEmpty()) {
                Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface.copy(alpha=.92f))) {
                    widgetIds.forEach { widgetId ->
                        key(widgetId) {
                            val host = context as? MainActivity
                            val info = remember(widgetId) { AppWidgetManager.getInstance(context).getAppWidgetInfo(widgetId) }
                            if (host != null && info != null) {
                                AndroidView(factory={ ctx -> host.createHostedWidgetView(ctx,widgetId,info) },modifier=Modifier.fillMaxWidth().weight(1f))
                            } else Text("Widget unavailable: $widgetId")
                            TextButton(onClick={ (context as? MainActivity)?.removeWidgetFromPage(pageIndex,widgetId) }){Text("Remove widget")}
                        }
                    }
                }
            } else {
            val tileWidth = maxWidth / columns
            val visibleRows = ceil(
                maxHeight.value / tileWidth.value.coerceAtLeast(1f)
            ).toInt().coerceAtLeast(1)
            val highestUsedSlot = positions.values.maxOrNull() ?: -1
            val requiredSlots = maxOf(
                visibleRows * columns,
                highestUsedSlot + 1,
                shortcuts.size
            )
            val rows = ((requiredSlots + columns - 1) / columns)
                .coerceAtLeast(visibleRows) + 1
            val clockRow = when (clockVertical) {
                "center" -> visibleRows / 2
                "bottom" -> (visibleRows - 1).coerceAtLeast(0)
                else -> 0
            }
            val shortcutsBySlot = shortcuts.mapNotNull { shortcut ->
                positions[shortcut.id]?.let { slot -> slot to shortcut }
            }.toMap()

            CompositionLocalProvider(
                LocalViewConfiguration provides moveViewConfiguration
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    modifier = Modifier.fillMaxSize(),
                    state = gridState,
                    userScrollEnabled = dragSourceSlot == null
                ) {
                    for (row in 0 until rows) {
                        if (clockVisible && row == clockRow) {
                            item(
                                key = "desktop-clock",
                                span = { GridItemSpan(maxLineSpan) }
                            ) {
                                DesktopClockRow(
                                    p,
                                    orientation,
                                    preferenceRevision,
                                    now,
                                    showClock,
                                    customText,
                                    clockHorizontal,
                                    tileWidth
                                )
                            }
                        }
                        items(
                            count = columns,
                            key = { column -> "slot-" + (row * columns + column) }
                        ) { column ->
                            val slot = row * columns + column
                            val shortcut = shortcutsBySlot[slot]
                            val activelyDragging =
                                dragSourceSlot == slot && dragOffset != Offset.Zero
                            DesktopSlot(
                                shortcut = shortcut,
                                selected = shortcut?.id == movingId,
                                dropTarget = slot == dropTargetSlot &&
                                    dropTargetSlot != dragSourceSlot,
                                moveMode = movingId != null,
                                dragOffset = if (activelyDragging) dragOffset else Offset.Zero,
                                onActivate = {
                                    val selectedId = movingId
                                    if (selectedId != null) {
                                        if (selectedId == shortcut?.id) {
                                            movingId = null
                                        } else {
                                            commitMove(selectedId, slot)
                                            movingId = null
                                        }
                                        dragSourceSlot = null
                                        dropTargetSlot = null
                                        dragOffset = Offset.Zero
                                    } else if (shortcut != null) {
                                        openShortcut(shortcut)
                                    }
                                },
                                onDragStart = {
                                    if (shortcut != null) {
                                        movingId = shortcut.id
                                        dragSourceSlot = slot
                                        dropTargetSlot = slot
                                        dragOffset = Offset.Zero
                                    }
                                },
                                onDrag = { delta ->
                                    dragOffset += delta
                                    val sourceSlot = dragSourceSlot
                                    if (sourceSlot != null) {
                                        val sourceInfo =
                                            gridState.layoutInfo.visibleItemsInfo.firstOrNull {
                                                it.key == "slot-" + sourceSlot
                                            }
                                        if (sourceInfo != null) {
                                            val centerX = sourceInfo.offset.x +
                                                sourceInfo.size.width / 2f + dragOffset.x
                                            val centerY = sourceInfo.offset.y +
                                                sourceInfo.size.height / 2f + dragOffset.y
                                            val targetInfo =
                                                gridState.layoutInfo.visibleItemsInfo.firstOrNull {
                                                    val key = it.key as? String
                                                    key?.startsWith("slot-") == true &&
                                                        centerX >= it.offset.x &&
                                                        centerX < it.offset.x + it.size.width &&
                                                        centerY >= it.offset.y &&
                                                        centerY < it.offset.y + it.size.height
                                                }
                                            dropTargetSlot = (targetInfo?.key as? String)
                                                ?.removePrefix("slot-")
                                                ?.toIntOrNull()
                                        }
                                    }
                                },
                                onDragEnd = {
                                    val selectedId = movingId
                                    val sourceSlot = dragSourceSlot
                                    val targetSlot = dropTargetSlot
                                    if (
                                        selectedId != null &&
                                        sourceSlot != null &&
                                        targetSlot != null &&
                                        targetSlot != sourceSlot
                                    ) {
                                        commitMove(selectedId, targetSlot)
                                        movingId = null
                                    }
                                    dragSourceSlot = null
                                    dropTargetSlot = null
                                    dragOffset = Offset.Zero
                                },
                                onDragCancel = {
                                    dragSourceSlot = null
                                    dropTargetSlot = null
                                    dragOffset = Offset.Zero
                                }
                            )
                        }
                    }
                }
            }
        }

        }
        shortcuts.firstOrNull { it.id == movingId }?.let { movingShortcut ->
            Surface(
                color = Aubergine.copy(alpha = .94f),
                shape = RoundedCornerShape(14.dp),
                tonalElevation = 5.dp
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Moving " + movingShortcut.label +
                            ". Drag it, or scroll and tap a destination.",
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall
                    )
                    movingShortcut.preferenceKey?.let { preferenceKey ->
                        TextButton(
                            onClick = {
                                manage = preferenceKey to movingShortcut.entry
                                movingId = null
                            }
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null)
                            Text("Manage")
                        }
                    }
                    IconButton(
                        onClick = {
                            movingId = null
                            dragSourceSlot = null
                            dropTargetSlot = null
                            dragOffset = Offset.Zero
                        }
                    ) {
                        Icon(Icons.Default.Close, "Finish moving", tint = Color.White)
                    }
                }
            }
        }

        // Navigation controls are intentionally absent from the desktop surface.
    }

    if (addLink) {
        AlertDialog(
            onDismissRequest = { addLink = false },
            title = {
                Text(
                    "Pin website to " +
                        "Page ${pageIndex+1}"
                )
            },
            text = {
                Column {
                    OutlinedTextField(label, { label = it }, label = { Text("Name") })
                    OutlinedTextField(url, { url = it }, label = { Text("https://...") })
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (url.startsWith("http")) {
                            val key = "desktop_links_" + suffix
                            val set = p.getStringSet(key, emptySet())
                                .orEmpty()
                                .toMutableSet()
                            set.add(url + "|" + label.ifBlank { "Website" })
                            p.edit().putStringSet(key, set).apply()
                            changed()
                        }
                        addLink = false
                    }
                ) {
                    Text("Pin")
                }
            },
            dismissButton = {
                TextButton(onClick = { addLink = false }) { Text("Cancel") }
            }
        )
    }
    manage?.let { (key, entry) ->
        ShortcutManageDialog(
            p,
            key,
            entry,
            {
                manage = null
                changed()
            },
            { manage = null }
        )
    }
}

@Composable
private fun DesktopClockRow(
    p: android.content.SharedPreferences,
    orientation: String,
    preferenceRevision: Int,
    now: Long,
    showClock: Boolean,
    customText: String,
    horizontal: String,
    minimumHeight: androidx.compose.ui.unit.Dp
) {
    val textAlignment = when (horizontal) {
        "center" -> Alignment.CenterHorizontally
        "right" -> Alignment.End
        else -> Alignment.Start
    }
    val rowAlignment = when (horizontal) {
        "center" -> Alignment.Center
        "right" -> Alignment.CenterEnd
        else -> Alignment.CenterStart
    }
    val clockSize = remember(preferenceRevision, orientation) {
        p.getInt(
            settingKey("clock_size", orientation),
            p.getInt("clock_size", 22)
        ).sp
    }
    val clockColor = remember(preferenceRevision, orientation) {
        runCatching {
            Color(
                android.graphics.Color.parseColor(
                    p.getString(
                        settingKey("clock_color", orientation),
                        p.getString("clock_color", "#FFFFFF")
                    )
                )
            )
        }.getOrDefault(Color.White)
    }
    val clockFont = remember(preferenceRevision, orientation) {
        when (
            p.getString(
                settingKey("clock_font", orientation),
                p.getString("clock_font", "sans")
            )
        ) {
            "serif" -> FontFamily.Serif
            "mono" -> FontFamily.Monospace
            "cursive" -> FontFamily.Cursive
            else -> FontFamily.SansSerif
        }
    }
    val rowHeight = if (minimumHeight < 56.dp) 56.dp else minimumHeight
    Box(Modifier.fillMaxWidth().heightIn(min = rowHeight).padding(4.dp)) {
        Column(
            Modifier.align(rowAlignment)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black.copy(alpha = .32f))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = textAlignment
        ) {
            if (showClock) {
                Text(
                    SimpleDateFormat("EEE, MMM d   HH:mm", Locale.getDefault())
                        .format(Date(now)),
                    color = clockColor,
                    fontSize = clockSize,
                    fontFamily = clockFont
                )
            }
            if (customText.isNotBlank()) {
                Text(customText, color = chosenColor(p.getString(settingKey("display_text_color",orientation),"#FFFFFF")?:"#FFFFFF"),fontSize=p.getInt(settingKey("display_text_size",orientation),16).coerceIn(1,80).sp,fontFamily=chosenFont(p.getString(settingKey("display_text_font",orientation),"Sans")?:"Sans"),fontWeight=chosenWeight(p.getString(settingKey("display_text_weight",orientation),"Normal")?:"Normal"),fontStyle=chosenStyle(p.getString(settingKey("display_text_weight",orientation),"Normal")?:"Normal"))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DesktopSlot(
    shortcut: DesktopShortcut?,
    selected: Boolean,
    dropTarget: Boolean,
    moveMode: Boolean,
    dragOffset: Offset,
    onActivate: () -> Unit,
    onDragStart: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit
) {
    val activelyDragging = dragOffset != Offset.Zero
    var modifier = Modifier
        .padding(4.dp)
        .aspectRatio(1f)
        .zIndex(if (activelyDragging) 5f else 0f)
        .graphicsLayer {
            translationX = dragOffset.x
            translationY = dragOffset.y
            if (activelyDragging) {
                scaleX = 1.06f
                scaleY = 1.06f
                shadowElevation = 10f
            }
        }
        .clickable(
            enabled = shortcut != null || moveMode,
            onClick = onActivate
        )

    if (shortcut != null) {
        modifier = modifier.pointerInput(shortcut.id) {
            detectDragGesturesAfterLongPress(
                onDragStart = { onDragStart() },
                onDragEnd = onDragEnd,
                onDragCancel = onDragCancel,
                onDrag = { change, amount ->
                    change.consume()
                    onDrag(amount)
                }
            )
        }
    }

    Box(modifier) {
        if (shortcut == null) {
            if (moveMode) {
                Box(
                    Modifier.fillMaxSize()
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            1.dp,
                            Orange.copy(alpha = .35f),
                            RoundedCornerShape(14.dp)
                        )
                )
            }
        } else {
            when (shortcut.kind) {
                DesktopShortcutKind.FILE -> FileShortcutTile(
                    Uri.parse(shortcut.target),
                    shortcut.label,
                    Modifier.fillMaxSize()
                )
                DesktopShortcutKind.WEBSITE -> WebsiteShortcutTile(
                    shortcut.target,
                    shortcut.label,
                    Modifier.fillMaxSize()
                )
                DesktopShortcutKind.WEATHER -> ShortcutTile(
                    Icons.Default.Cloud,
                    shortcut.label,
                    Modifier.fillMaxSize()
                )
            }
            if (selected || dropTarget) {
                Box(
                    Modifier.fillMaxSize()
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            width = if (dropTarget) 3.dp else 2.dp,
                            color = if (dropTarget) Color.White else Orange,
                            shape = RoundedCornerShape(14.dp)
                        )
                )
            }
        }
    }
}

@Composable fun ShortcutManageDialog(p:android.content.SharedPreferences,key:String,entry:String,done:()->Unit,cancel:()->Unit){val parts=entry.split("|",limit=2);var name by remember(entry){mutableStateOf(parts.getOrElse(1){"Shortcut"})};AlertDialog(onDismissRequest=cancel,title={Text("Manage shortcut")},text={OutlinedTextField(name,{name=it},label={Text("Name")})},confirmButton={Row{TextButton({val set=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.remove(entry);set.add("${parts[0]}|${name.ifBlank{"Shortcut"}}");p.edit().putStringSet(key,set).apply();done()}){Text("Rename")};TextButton({val set=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.remove(entry);p.edit().putStringSet(key,set).apply();done()}){Text("Remove",color=MaterialTheme.colorScheme.error)}}},dismissButton={TextButton(cancel){Text("Cancel")}})}
@Composable
fun FileShortcutTile(
    uri: Uri,
    label: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var preview by remember(uri) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(uri) {
        preview = withContext(Dispatchers.IO) {
            runCatching { decodeSampledImage(context, uri, 512, 512) }.getOrNull()
        }
    }
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = .38f))
    ) {
        if (preview != null) {
            Image(
                preview!!,
                label,
                Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Icon(
                Icons.Default.Description,
                contentDescription = "File",
                tint = Color.White,
                modifier = Modifier.align(Alignment.Center).fillMaxSize(.46f)
            )
        }
        Box(
            Modifier.fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = .62f))
                .padding(5.dp)
        ) {
            Text(label, color = Color.White, maxLines = 2)
        }
    }
}

@Composable
fun WebsiteShortcutTile(
    url: String,
    label: String,
    modifier: Modifier = Modifier
) {
    val applicationContext = LocalContext.current.applicationContext
    var favicon by remember(url) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(url) {
        favicon = withContext(Dispatchers.IO) {
            FaviconLoader.load(applicationContext, url)
        }?.asImageBitmap()
    }
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = .30f))
    ) {
        if (favicon != null) {
            Image(
                favicon!!,
                label,
                Modifier.align(Alignment.Center).fillMaxSize(.66f),
                contentScale = ContentScale.Fit
            )
        } else {
            Icon(
                Icons.Default.Language,
                contentDescription = "Website",
                tint = Color.White,
                modifier = Modifier.align(Alignment.Center).fillMaxSize(.46f)
            )
        }
        Box(
            Modifier.fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = .62f))
                .padding(5.dp)
        ) {
            Text(label, color = Color.White, maxLines = 2)
        }
    }
}

@Composable
fun ShortcutTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = .30f))
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = Color.White,
            modifier = Modifier.align(Alignment.Center).fillMaxSize(.46f)
        )
        Box(
            Modifier.fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = .62f))
                .padding(5.dp)
        ) {
            Text(label, color = Color.White, maxLines = 2)
        }
    }
}

private val launcherTextStyles = listOf("Sans", "Serif", "Monospace", "Cursive", "Gothic", "Calligraphy", "Rounded", "Condensed", "Slab", "Casual")
private fun chosenFont(name:String):FontFamily = when(name){
 "Serif", "Gothic", "Slab" -> FontFamily.Serif
 "Monospace" -> FontFamily.Monospace
 "Cursive", "Calligraphy", "Casual" -> FontFamily.Cursive
 else -> FontFamily.SansSerif
}
private fun chosenWeight(name:String) = if(name=="Bold") FontWeight.Bold else FontWeight.Normal
private fun chosenStyle(name:String) = if(name=="Italic") FontStyle.Italic else FontStyle.Normal
private fun chosenColor(value:String, fallback:Color=Color.White):Color = runCatching{Color(android.graphics.Color.parseColor(value))}.getOrDefault(fallback)

@Composable fun AppIcon(a:AppItem,pixels:Int,modifier:Modifier=Modifier,tint:Color?=null,opacity:Float=1f){
 val image=remember(a.packageName,a.activityName,a.icon){runCatching{a.icon.toBitmap(pixels,pixels).asImageBitmap()}.getOrNull()}
 // Bi-color: the chosen color is a distinct background, never a filter over the artwork.
 // Preserve the actual application icon's foreground colors and transparency.
 Box(modifier.graphicsLayer { alpha = opacity.coerceIn(0f, 1f) },contentAlignment=Alignment.Center) {
   if(tint!=null) Box(Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).background(tint))
   if(image!=null) Image(image,a.label,Modifier.fillMaxSize(if(tint==null) 1f else .78f))
   else Icon(Icons.Default.Android,"${a.label} icon",Modifier.fillMaxSize(.65f),tint=if(tint==null) Color.White else if(tint.luminance()>.45f) Color.Black else Color.White)
 }
}
@OptIn(ExperimentalFoundationApi::class) @Composable fun AppTile(a:AppItem,onClick:()->Unit,onLong:(()->Unit)?=null,iconSize:Int=48,labelSize:Int=12,tint:Color?=null,opacity:Float=1f,textColor:Color=Color.White,font:FontFamily=FontFamily.SansSerif,weight:FontWeight=FontWeight.Normal,style:FontStyle=FontStyle.Normal,showLabel:Boolean=true){Column(Modifier.padding(4.dp).clip(RoundedCornerShape(12.dp)).combinedClickable(onClick=onClick,onLongClick=onLong).padding(4.dp),horizontalAlignment=Alignment.CenterHorizontally){AppIcon(a,(iconSize*2).coerceAtLeast(32),Modifier.size(iconSize.dp),tint,opacity);if(showLabel)Text(a.label,color=textColor,maxLines=2,fontSize=labelSize.sp,lineHeight=(labelSize+2).sp,fontFamily=font,fontWeight=weight,fontStyle=style)}}
fun toggleSet(p:android.content.SharedPreferences,key:String,value:String){val s=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();if(!s.add(value))s.remove(value);p.edit().putStringSet(key,s).apply()}

@Composable fun Taskbar(all:List<AppItem>,p:android.content.SharedPreferences,preferenceRevision:Int,drawer:()->Unit,vertical:Boolean,sizeDp:Int,direction:String,opacityPercent:Int,auto:Boolean,toggle:()->Unit){
 val c=LocalContext.current;val size=sizeDp.dp;val reverse=taskbarDirectionIsReversed(direction);val pins=remember(preferenceRevision,all){orderedPinnedPackages(p,all).mapNotNull{x->all.firstOrNull{a->a.packageName==x}}};val mod=if(vertical)Modifier.width(size).fillMaxHeight() else Modifier.height(size).fillMaxWidth();Surface(mod,color=Color.Black.copy(alpha=taskbarOpacityFraction(opacityPercent))){if(vertical)LazyColumn(reverseLayout=reverse,horizontalAlignment=Alignment.CenterHorizontally){item{IconButton(drawer){Icon(Icons.Default.Apps,"Apps",tint=Color.White)}};items(pins,key={it.packageName}){a->AppIcon(a,72,Modifier.padding(5.dp).size(36.dp).clickable{launch(c,a)})};if(auto)item{IconButton(toggle){Icon(Icons.Default.UnfoldLess,"Auto hide",tint=Color.White)}}}else LazyRow(reverseLayout=reverse,verticalAlignment=Alignment.CenterVertically){item{IconButton(drawer){Icon(Icons.Default.Apps,"Apps",tint=Color.White)}};items(pins,key={it.packageName}){a->AppIcon(a,72,Modifier.padding(horizontal=7.dp).size(36.dp).clickable{launch(c,a)})};if(auto)item{IconButton(toggle){Icon(Icons.Default.UnfoldLess,"Auto hide",tint=Color.White)}}}}}

val settingItems=listOf(SettingItem("Wi-Fi","Networks and Internet",Settings.ACTION_WIFI_SETTINGS),SettingItem("Bluetooth","Connected devices",Settings.ACTION_BLUETOOTH_SETTINGS),SettingItem("Display","Brightness and display",Settings.ACTION_DISPLAY_SETTINGS),SettingItem("Sound","Volume and sound",Settings.ACTION_SOUND_SETTINGS),SettingItem("Storage","Device storage",Settings.ACTION_INTERNAL_STORAGE_SETTINGS),SettingItem("Accessibility","Accessibility",Settings.ACTION_ACCESSIBILITY_SETTINGS),SettingItem("System settings","All Android settings",Settings.ACTION_SETTINGS))
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppDrawer(
    apps: List<AppItem>,
    q: String,
    setQ: (String) -> Unit,
    close: () -> Unit,
    settings: () -> Unit,
    p: android.content.SharedPreferences,
    preferenceRevision: Int,
    changed: () -> Unit
) {
    val context = LocalContext.current
    val orientation = orientationName(LocalConfiguration.current.orientation)
    val showGridLabels = remember(preferenceRevision,orientation) { p.getBoolean(settingKey("app_grid_show_labels",orientation),true) }
    val grid = remember(preferenceRevision,orientation) { p.getBoolean(settingKey("app_grid",orientation),p.getBoolean("app_grid",true)) }
    val horizontalGrid = remember(preferenceRevision,orientation) { p.getString(settingKey("app_grid_scroll",orientation),"vertical")=="horizontal" }
    val tintIcons = remember(preferenceRevision,orientation) { p.getBoolean(settingKey("app_icon_tint_enabled",orientation),false) }
    val drawerBackground = chosenColor(p.getString(settingKey("app_list_background_color",orientation),"#2C1236")?:"#2C1236",Aubergine)
    val iconOpacity = remember(preferenceRevision,orientation) {
        appIconOpacityFraction(p.getInt(settingKey("app_icon_opacity",orientation),100))
    }
    val iconTint = if(tintIcons) chosenColor(p.getString(settingKey("app_icon_tint",orientation),"#FFFFFF")?:"#FFFFFF") else null
    val textColor = chosenColor(p.getString(settingKey("display_text_color",orientation),"#FFFFFF")?:"#FFFFFF")
    val font = chosenFont(p.getString(settingKey("display_text_font",orientation),"Sans")?:"Sans")
    val weight = chosenWeight(p.getString(settingKey("display_text_weight",orientation),"Normal")?:"Normal")
    val style = chosenStyle(p.getString(settingKey("display_text_weight",orientation),"Normal")?:"Normal")
    val iconSize = remember(preferenceRevision, orientation) { normalizeAppListIconSize(p.getInt(settingKey("app_list_icon_size", orientation), 48)) }
    val labelSize = remember(preferenceRevision, orientation) { normalizeAppListLabelSize(p.getInt(settingKey("app_list_label_size", orientation), 12)) }
    val extent = remember(preferenceRevision, orientation) {
        normalizeAppDrawerExtent(
            p.getInt(
                settingKey("app_drawer_extent", orientation),
                defaultAppDrawerExtent(orientation)
            )
        )
    }
    val defaultPosition = if (orientation == "landscape") "left" else "bottom"
    val taskbarPosition = remember(preferenceRevision, orientation) {
        p.getString(
            settingKey("taskbar_pos", orientation),
            p.getString("taskbar_pos", defaultPosition)
        ) ?: defaultPosition
    }
    val taskbarDirection = remember(preferenceRevision, orientation, taskbarPosition) {
        normalizeTaskbarDirection(
            taskbarPosition,
            p.getString(
                settingKey("taskbar_direction", orientation),
                p.getString("taskbar_direction", defaultTaskbarDirection(taskbarPosition))
            ) ?: defaultTaskbarDirection(taskbarPosition)
        )
    }
    val drawerAlignment = remember(preferenceRevision, orientation) {
        when (p.getString(settingKey("app_drawer_position", orientation), "auto")) {
            "left" -> Alignment.CenterStart
            "center" -> Alignment.Center
            "right" -> Alignment.CenterEnd
            else -> if (appDrawerOpensFromEnd(taskbarPosition, taskbarDirection)) Alignment.CenterEnd else Alignment.CenterStart
        }
    }
    val opensFromEnd = drawerAlignment == Alignment.CenterEnd
    val results = remember(apps, q, preferenceRevision) { apps.filter {
        it.label.contains(q, ignoreCase = true) ||
            it.packageName.contains(q, ignoreCase = true)
    } }
    val pinned = remember(preferenceRevision) { p.getStringSet("drawer_pins",emptySet()).orEmpty() }
    val orderedResults = results.sortedWith(compareByDescending<AppItem>{it.packageName in pinned}.thenBy{it.label.lowercase()})
    var selectedApp by remember { mutableStateOf<AppItem?>(null) }
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.matchParentSize()
                .background(Color.Black.copy(alpha = .28f))
                .clickable(onClickLabel = "Close applications", onClick = close)
        )
        Surface(
            modifier = Modifier.align(drawerAlignment)
                .fillMaxHeight().fillMaxWidth(extent/100f),
            color = drawerBackground,
            shape = when(drawerAlignment) {
                Alignment.CenterEnd -> RoundedCornerShape(topStart=22.dp,bottomStart=22.dp)
                Alignment.Center -> RoundedCornerShape(22.dp)
                else -> RoundedCornerShape(topEnd=22.dp,bottomEnd=22.dp)
            },
            shadowElevation = 18.dp
        ) {
        Column(
            modifier = Modifier.statusBarsPadding().navigationBarsPadding().padding(16.dp)
        ) {
            // Keep the search field on its own row so narrow drawers cannot squeeze
            // the placeholder into a tall column of individual characters.
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClick = settings) {
                    Icon(Icons.Default.Settings, contentDescription = "Launcher settings", tint = Color.White)
                }
                IconButton(onClick = close) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }
            OutlinedTextField(
                value = q,
                onValueChange = setQ,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Search apps and settings", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
            )
            if (q.isNotBlank()) {
                settingItems.filter {
                    it.label.contains(q, ignoreCase = true) ||
                        it.subtitle.contains(q, ignoreCase = true)
                }.forEach { setting ->
                    ListItem(
                        headlineContent = { Text(setting.label) },
                        supportingContent = { Text(setting.subtitle) },
                        modifier = Modifier.clickable { openSetting(context, setting.action) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            if (grid) {
                val columns = GridCells.Adaptive((iconSize + 34).coerceAtLeast(58).dp)
                val tile: @Composable (AppItem) -> Unit = { app ->
                    Box {
                        AppTile(app,onClick={launch(context,app)},onLong={selectedApp=app},iconSize=iconSize,labelSize=labelSize,tint=iconTint,opacity=iconOpacity,textColor=textColor,font=font,weight=weight,style=style,showLabel=showGridLabels)
                        if(app.packageName in pinned) Icon(Icons.Default.PushPin,"Pinned",tint=Color.Yellow,modifier=Modifier.align(Alignment.TopEnd).size(14.dp))
                    }
                }
                if(horizontalGrid) {
                    LazyHorizontalGrid(rows=GridCells.Adaptive((iconSize+48).coerceAtLeast(70).dp),modifier=Modifier.fillMaxSize()) {
                        items(orderedResults,key={it.packageName+it.activityName}){app->tile(app)}
                    }
                } else {
                    LazyVerticalGrid(columns=columns) {
                        items(orderedResults,key={it.packageName+it.activityName}){app->tile(app)}
                    }
                }
            } else {
                LazyColumn {
                    items(orderedResults,key={it.packageName+it.activityName}) { app ->
                        ListItem(
                            headlineContent={Text(app.label,fontSize=labelSize.sp,color=textColor,fontFamily=font,fontWeight=weight,fontStyle=style)},
                            supportingContent={Text(app.packageName,fontSize=(labelSize-2).coerceAtLeast(8).sp,color=textColor.copy(alpha=.75f),fontFamily=font)},
                            leadingContent={AppIcon(app,iconSize*2,Modifier.size(iconSize.dp),iconTint,iconOpacity)},
                            trailingContent={if(app.packageName in pinned)Icon(Icons.Default.PushPin,"Pinned")},
                            colors=ListItemDefaults.colors(containerColor=drawerBackground),
                            modifier=Modifier.combinedClickable(onClick={launch(context,app)},onLongClick={selectedApp=app})
                        )
                    }
                }
            }
            selectedApp?.let { app ->
                AlertDialog(onDismissRequest={selectedApp=null},title={Text(app.label)},text={Text("Pin this application to the top of the applications list?")},confirmButton={TextButton({toggleSet(p,"drawer_pins",app.packageName);changed();selectedApp=null}){Text(if(app.packageName in pinned)"Unpin" else "Pin")}},dismissButton={TextButton({selectedApp=null}){Text("Cancel")}})
            }
        }
        }
    }
}

@Composable fun LauncherSettings(apps:List<AppItem>,p:android.content.SharedPreferences,close:()->Unit,changed:()->Unit,pickPhotos:(Boolean,String)->Unit,pickFile:()->Unit,exportBackup:()->Unit,importBackup:()->Unit){val c=LocalContext.current;var page by remember{mutableStateOf("main")};var tick by remember{mutableIntStateOf(0)};var addWebsite by remember{mutableStateOf(false)};var websiteUrl by remember{mutableStateOf("")};var websiteLabel by remember{mutableStateOf("")};fun ch(){tick++;changed()};Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background){Column(Modifier.statusBarsPadding().navigationBarsPadding()){Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer).padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton({if(page=="main")close()else page="main"}){Icon(Icons.AutoMirrored.Filled.ArrowBack,"Back",tint=MaterialTheme.colorScheme.onPrimaryContainer)};Text(pageTitle(page),color=MaterialTheme.colorScheme.onPrimaryContainer,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)};when(page){
"hidden"->AppSelector(apps,p,"hidden",true){ch()};"dumbapps"->AppSelector(apps,p,"dumb",false){ch()};"taskbarapps"->PinnedAppsSettings(apps,p){ch()};"weather"->WeatherSettings(apps,p){ch()};"appearance"->LazyColumn{item{ThemeModeSettings(p){ch()}};item{SettingRow(Icons.Default.PhoneAndroid,"Portrait orientation","Configure portrait wallpapers, clock and desktop layout"){page="portrait"}};item{SettingRow(Icons.Default.DesktopWindows,"Landscape orientation","Configure landscape wallpapers, clock and desktop layout"){page="landscape"}}};"portrait"->AppearanceSettings(p,"portrait",pickPhotos){ch()};"landscape"->AppearanceSettings(p,"landscape",pickPhotos){ch()};"taskbar"->TaskbarSettings(p){ch()};"apps"->AppsSettings(p){ch()};"lock"->LockSettings(p){ch()};"licenses"->LicenseScreen();"about"->AboutScreen();
"desktop"->LazyColumn {
 item { SettingRow(Icons.Default.Description,"Pin file","Choose a file for the selected shortcut destination"){pickFile()} }
 item { SettingRow(Icons.Default.Folder,"Pin folder","Select a directory using Android's document picker"){(c as? MainActivity)?.chooseFolder()} }
 item { SettingRow(Icons.Default.AddLink,"Add website","Create a website shortcut on the selected desktop page"){addWebsite=true} }
 item { SettingRow(Icons.AutoMirrored.Filled.ViewSidebar,"Taskbar","Overlay, position, direction, size, visibility and auto-hide"){page="taskbar"} }
 item { SettingRow(Icons.Default.PushPin,"Taskbar pinned apps","Choose apps for the taskbar"){page="taskbarapps"} }
 item { DesktopScreenSettings(p){ch()} }
 item { SwipeActionSettings(p){ch()} }
 item { SettingRow(Icons.Default.Cloud,"Weather app","Choose the app opened by the weather shortcut"){page="weather"} }
}

"dumbsettings"->DumbPhoneSettings(p,{page="dumbapps"}){ch()};
else->LazyColumn{item{SettingRow(Icons.Default.Home,"Make default Home","Set Ubuntu Launcher as Android Home"){(c as? MainActivity)?.requestHome()}};item{SettingRow(Icons.Default.Wallpaper,"Display settings","Wallpaper, clock/date, colors, fonts and desktop appearance"){page="appearance"}};item{SettingRow(Icons.Default.DesktopWindows,"Desktop settings","Taskbar, pinned apps, secondary page, shared shortcuts and weather"){page="desktop"}};item{SettingRow(Icons.Default.PhoneAndroid,"Dumb Phone Settings","Mode, app allowlist and notification management"){page="dumbsettings"}};item{SettingRow(Icons.Default.Apps,"Applications list","Grid/list, scrolling, icon colors and pinned applications"){page="apps"}};item{SettingRow(Icons.Default.Lock,"Ubuntu-style lock layer","PIN/password and lock-screen appearance"){page="lock"}};item{SettingRow(Icons.Default.VisibilityOff,"Hidden apps","Only accessible through launcher settings"){page="hidden"}};item{SettingRow(Icons.Default.Save,"Launcher backup","Download a complete launcher settings backup"){exportBackup()}};item{SettingRow(Icons.Default.Restore,"Restore launcher backup","Upload a launcher backup and restore settings"){importBackup()}};item{SettingRow(Icons.Default.Settings,"Android Settings","Open system settings"){openSetting(c,Settings.ACTION_SETTINGS)}};item{SettingRow(Icons.Default.Description,"Licenses","GNU AGPLv3"){page="licenses"}};item{SettingRow(Icons.Default.Info,"About","Version and developer information"){page="about"}}}}}
 if(addWebsite)AlertDialog(onDismissRequest={addWebsite=false},title={Text("Add website")},text={Column{OutlinedTextField(websiteLabel,{websiteLabel=it},label={Text("Name")});OutlinedTextField(websiteUrl,{websiteUrl=it},label={Text("Website URL")})}},confirmButton={TextButton({val normalized=if(websiteUrl.startsWith("https://")||websiteUrl.startsWith("http://"))websiteUrl else "https://$websiteUrl";val uri=runCatching{Uri.parse(normalized)}.getOrNull();if(uri?.host!=null){val target=p.getString("shortcut_target_page","main")?:"main";val key="desktop_links_$target";val links=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();links.add("$normalized|${websiteLabel.ifBlank{uri.host?:"Website"}}");p.edit().putStringSet(key,links).apply();ch()};addWebsite=false;websiteUrl="";websiteLabel=""}){Text("Add")}},dismissButton={TextButton({addWebsite=false}){Text("Cancel")}})
 }}

@Composable
fun DumbPhoneSettings(
 p:android.content.SharedPreferences,
 manageApps:()->Unit,
 changed:()->Unit
){
 val context=LocalContext.current
 val notificationAccess=rememberNotificationListenerAccess(context)
 val dumbMode=p.getBoolean(DUMB_MODE_PREFERENCE,false)
 val notificationFilter=p.getBoolean(DUMB_NOTIFICATION_FILTER_PREFERENCE,false)
 LazyColumn{
  item{
   SettingRow(
    Icons.Default.PhoneAndroid,
    "Dumb Phone Mode",
    if(dumbMode)"Enabled" else "Disabled",
    dumbMode
   ){
    val enabling=!dumbMode
    p.edit().putBoolean(DUMB_MODE_PREFERENCE,enabling).apply()
    changed()
    if(enabling&&notificationFilter&&!notificationAccess)openNotificationListenerSettings(context)
   }
  }
  item{SettingRow(Icons.Default.Checklist,"Choose Dumb Phone apps","Manage accessible apps",click=manageApps)}
  item{
   SettingRow(
    Icons.Default.NotificationsOff,
    "Notification filter",
    if(notificationAccess)"Dismiss notifications from apps outside the Dumb Phone allowlist"
    else "Android notification access is required; enabling opens the permission screen",
    notificationFilter
   ){
    val enabling=!notificationFilter
    p.edit().putBoolean(DUMB_NOTIFICATION_FILTER_PREFERENCE,enabling).apply()
    changed()
    if(enabling&&!notificationAccess)openNotificationListenerSettings(context)
   }
  }
  item{
   SettingRow(
    Icons.Default.Notifications,
    "Notification access & types",
    if(notificationAccess)"Granted — Ubuntu Launcher can filter notifications"
    else "Not granted — tap to authorize Ubuntu Launcher"
   ){openNotificationListenerSettings(context)}
  }
  if(notificationFilter&&!notificationAccess){
   item{
    Text(
     "Filtering cannot work until Android Notification access is granted. On the next screen, enable Ubuntu Launcher and allow every notification type.",
     color=MaterialTheme.colorScheme.error,
     modifier=Modifier.padding(horizontal=16.dp,vertical=10.dp)
    )
   }
  }
 }
}

fun pageTitle(p:String)=when(p){"hidden"->"Hidden applications";"dumbapps"->"Dumb Phone applications";"taskbarapps"->"Taskbar pinned applications";"weather"->"Weather";"appearance"->"Display settings";"portrait"->"Portrait orientation";"landscape"->"Landscape orientation";"desktop"->"Desktop settings";"dumbsettings"->"Dumb Phone Settings";"taskbar"->"Taskbar";"apps"->"Applications list";"lock"->"Lock screen";"licenses"->"Licenses";"about"->"About";else->"Ubuntu Launcher Settings"}

private fun swapDesktopScreens(p: android.content.SharedPreferences, first:Int, second:Int) {
 if(first<0 || second<0) return
 val a=if(first==0)"main" else if(first==1)"secondary" else "page_$first"
 val b=if(second==0)"main" else if(second==1)"secondary" else "page_$second"
 val keys=p.all.keys.toList()
 val pairs=mutableListOf<Pair<String,String>>()
 for(key in keys) {
  val other=when {
   key.endsWith("_$a") -> key.removeSuffix("_$a")+"_$b"
   key=="desktop_widget_page_$first" -> "desktop_widget_page_$second"
   else -> null
  }
  if(other!=null) pairs.add(key to other)
 }
 val snapshot=p.all.toMap()
 val editor=p.edit()
 fun put(key:String,value:Any?) {
  when(value){
   null->editor.remove(key)
   is String->editor.putString(key,value)
   is Int->editor.putInt(key,value)
   is Boolean->editor.putBoolean(key,value)
   is Long->editor.putLong(key,value)
   is Float->editor.putFloat(key,value)
   is Set<*>->editor.putStringSet(key,value.filterIsInstance<String>().toSet())
  }
 }
 pairs.forEach{(x,y)->put(x,snapshot[y]);put(y,snapshot[x])}
 editor.apply()
}

@Composable
fun DesktopScreenSettings(p: android.content.SharedPreferences, changed: () -> Unit) {
 val count = p.getInt("desktop_page_count",if(p.getBoolean("secondary_page_enabled",false))2 else 1).coerceAtLeast(1)
 var selected by remember { mutableIntStateOf(0) }
 if(selected >= count) selected = count-1
 Column(Modifier.padding(16.dp)) {
  Text("Desktop screens",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium)
  Row(verticalAlignment=Alignment.CenterVertically) {
   Text("$count screens",Modifier.weight(1f))
   TextButton(onClick={if(count>1){p.edit().putInt("desktop_page_count",count-1).apply();changed()}}){Text("−")}
   TextButton(onClick={p.edit().putInt("desktop_page_count",count+1).apply();changed()}){Text("+")}
  }
  Text("Select a screen to manage its widgets and shortcuts.",style=MaterialTheme.typography.bodySmall)
  Row(verticalAlignment=Alignment.CenterVertically) {
   TextButton(onClick={selected=(selected-1).coerceAtLeast(0)},enabled=selected>0){Text("Previous")}
   Text("Screen ${selected+1} / $count",Modifier.weight(1f))
   TextButton(onClick={selected=(selected+1).coerceAtMost(count-1)},enabled=selected<count-1){Text("Next")}
  }
  Row(verticalAlignment=Alignment.CenterVertically) {
   Text("Screen order",Modifier.weight(1f))
   TextButton(onClick={swapDesktopScreens(p,selected,selected-1);selected--;changed()},enabled=selected>0){Text("Move left")}
   TextButton(onClick={swapDesktopScreens(p,selected,selected+1);selected++;changed()},enabled=selected<count-1){Text("Move right")}
  }
  val target = if(selected==0)"main" else if(selected==1)"secondary" else "page_$selected"
  val currentTarget = p.getString("shortcut_target_page","main")
  SettingRow(Icons.Default.PushPin,"Shortcut destination",if(currentTarget==target)"Selected screen" else "Set screen ${selected+1} as destination") {
   p.edit().putString("shortcut_target_page",target).apply();changed()
  }
  val activity = LocalActivity.current as? MainActivity
  TextButton(onClick={activity?.addWidgetToPage(selected)}) { Text("+ Add widget to screen ${selected+1}") }
  val widgetIds = p.getString("desktop_widget_page_$selected","").orEmpty().split(',').mapNotNull{it.toIntOrNull()}
  widgetIds.forEach { id ->
   Row(verticalAlignment=Alignment.CenterVertically) {
    Text("Widget $id",Modifier.weight(1f))
    TextButton(onClick={activity?.removeWidgetFromPage(selected,id);changed()}){Text("Remove")}
   }
  }
  Text("Screen navigation",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp))
  val swipe = p.getString("desktop_page_swipe","off")?:"off"
  listOf("off" to "Off","both" to "Swipe both directions","left" to "Swipe left only","right" to "Swipe right only").forEach{(value,label)->
   Row(Modifier.fillMaxWidth().clickable{p.edit().putString("desktop_page_swipe",value).apply();changed()},verticalAlignment=Alignment.CenterVertically){RadioButton(selected=swipe==value,onClick={p.edit().putString("desktop_page_swipe",value).apply();changed()});Text(label)}
  }
  val taps=p.getBoolean("desktop_page_edge_tap",true)
  Row(Modifier.fillMaxWidth().clickable{p.edit().putBoolean("desktop_page_edge_tap",!taps).apply();changed()},verticalAlignment=Alignment.CenterVertically){Checkbox(checked=taps,onCheckedChange={p.edit().putBoolean("desktop_page_edge_tap",it).apply();changed()});Text("Tap left/right edges to change screens")}
 }
}

@Composable
fun SwipeActionSettings(p: android.content.SharedPreferences, changed: () -> Unit) {
 Column(Modifier.padding(16.dp)) {
  Text("Application list and Settings gestures",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium)
  Text("Each action can be disabled independently. Application list takes priority if gestures overlap; screen navigation runs only if no action claims that gesture.",style=MaterialTheme.typography.bodySmall)
  listOf(Triple("Applications list","swipe_apps_direction","tap_apps_side"),Triple("Settings","swipe_settings_direction","tap_settings_side")).forEach{(label,swipeKey,tapKey)->
   Text(label,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=12.dp))
   listOf(swipeKey to "Swipe",tapKey to "Tap edge").forEach{(key,kind)->
    val value=p.getString(key,"off")?:"off"
    Text(kind,style=MaterialTheme.typography.bodySmall)
    listOf("off" to "Off","left" to "Left","right" to "Right").forEach{(option,title)->
     Row(Modifier.fillMaxWidth().clickable{p.edit().putString(key,option).apply();changed()},verticalAlignment=Alignment.CenterVertically){RadioButton(selected=value==option,onClick={p.edit().putString(key,option).apply();changed()});Text(title)}
    }
   }
  }
 }
}

@Composable fun SettingRow(icon:androidx.compose.ui.graphics.vector.ImageVector,title:String,sub:String,switch:Boolean?=null,click:()->Unit){Row(Modifier.fillMaxWidth().clickable(onClick=click).padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Orange);Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.SemiBold);Text(sub,color=Color.Gray,style=MaterialTheme.typography.bodySmall)};if(switch!=null)Switch(switch,{click()})}}

fun orientationName(orientation:Int):String=if(orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE)"landscape" else "portrait"
fun wallKey(p:android.content.SharedPreferences,dumb:Boolean,orientation:String):String {
 val base=if(dumb)"wall_dumb" else "wall_regular"
 return "${base}_${orientation}"
}
fun settingKey(base:String,orientation:String)="${base}_${orientation}"
internal fun taskbarDirectionOptions(position:String):List<String> =
 if(position=="left"||position=="right")listOf("down","up") else listOf("right","left")
internal fun defaultTaskbarDirection(position:String):String=taskbarDirectionOptions(position).first()
internal fun normalizeTaskbarDirection(position:String,direction:String):String=
 direction.takeIf{it in taskbarDirectionOptions(position)}?:defaultTaskbarDirection(position)
internal fun taskbarDirectionIsReversed(direction:String):Boolean=direction=="up"||direction=="left"
internal fun normalizeTaskbarOpacity(value:Int):Int=value.coerceIn(0,100)
internal fun taskbarOpacityAlpha(value:Int):Int=(normalizeTaskbarOpacity(value)*255+50)/100
internal fun taskbarOpacityFraction(value:Int):Float=normalizeTaskbarOpacity(value)/100f
internal fun normalizeAppIconOpacity(value:Int):Int=value.coerceIn(0,100)
internal fun appIconOpacityFraction(value:Int):Float=normalizeAppIconOpacity(value)/100f
fun scaleFor(name:String):ContentScale=when(name){"fit"->ContentScale.Fit;"fill"->ContentScale.FillBounds;"zoom"->ContentScale.FillHeight;else->ContentScale.Crop}
@Composable
fun SystemBarsSettings(p: android.content.SharedPreferences, orientation: String, changed: () -> Unit) {
    val statusKey = "hide_system_status_$orientation"
    val navigationKey = "hide_system_navigation_$orientation"
    var hideStatus by remember(orientation) { mutableStateOf(p.getBoolean(statusKey, false)) }
    var hideNavigation by remember(orientation) { mutableStateOf(p.getBoolean(navigationKey, false)) }
    Column {
        SettingRow(Icons.Default.VisibilityOff, "Hide Android status bar",
            "Hide system time, weather, signal and battery icons", hideStatus) {
            hideStatus = !hideStatus
            p.edit().putBoolean(statusKey, hideStatus).apply()
            changed()
        }
        SettingRow(Icons.Default.VisibilityOff, "Hide Android navigation bar",
            "Hide system navigation controls (swipe from edge to reveal)", hideNavigation) {
            hideNavigation = !hideNavigation
            p.edit().putBoolean(navigationKey, hideNavigation).apply()
            changed()
        }
    }
}

@Composable fun AppearanceSettings(p:android.content.SharedPreferences,orientation:String,pick:(Boolean,String)->Unit,changed:()->Unit){
 val key:(String)->String={settingKey(it,orientation)}
 val maxColumns=if(orientation=="landscape")14 else 8
 var cols by remember(orientation){mutableIntStateOf(p.getInt(key("desktop_cols"),p.getInt("desktop_cols",4)).coerceIn(2,maxColumns))}
 var clock by remember(orientation){mutableStateOf(p.getBoolean(key("show_clock"),p.getBoolean("show_clock",true)))}
 var clockSize by remember(orientation){mutableIntStateOf(p.getInt(key("clock_size"),p.getInt("clock_size",22)))}
 var clockColor by remember(orientation){mutableStateOf(p.getString(key("clock_color"),p.getString("clock_color","#FFFFFF"))?:"#FFFFFF")}
 var clockFont by remember(orientation){mutableStateOf(p.getString(key("clock_font"),p.getString("clock_font","sans"))?:"sans")}
 var clockVertical by remember(orientation){mutableStateOf(p.getString(key("clock_vertical"),"top")?:"top")}
 var clockHorizontal by remember(orientation){mutableStateOf(p.getString(key("clock_horizontal"),"left")?:"left")}
 var custom by remember(orientation){mutableStateOf(p.getString(key("custom_text"),p.getString("custom_text",""))?:"")}
 LazyColumn(modifier=Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=24.dp)) {
  item(key="system_bars") { SystemBarsSettings(p,orientation,changed) }
  listOf(false,true).forEach{dumb->
   item {
    val label=if(dumb)"Dumb Phone" else "Regular launcher"
    val base=if(dumb)"wall_dumb" else "wall_regular"
    val wkey=wallKey(p,dumb,orientation)
    Text("$label wallpaper",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)
    Row(Modifier.padding(horizontal=16.dp)){
     Button({pick(dumb,orientation)}){Text("Choose photos")}
     Spacer(Modifier.width(8.dp))
     OutlinedButton({p.edit().remove(wkey).apply();changed()}){Text("Remove wallpaper")}
    }
    var mode by remember(orientation,dumb){mutableStateOf(p.getString(key("${base}_scale"),"crop")?:"crop")}
    Text("Image scaling",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=8.dp)){
     listOf("crop","fill","fit","zoom").forEach{option->
      FilterChip(mode==option,{mode=option;p.edit().putString(key("${base}_scale"),option).apply();changed()},label={Text(option.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(2.dp))
     }
    }
   }
  }
  item {
   var textFont by remember(orientation){mutableStateOf(p.getString(key("display_text_font"),"Sans")?:"Sans")}
   var textWeight by remember(orientation){mutableStateOf(p.getString(key("display_text_weight"),"Normal")?:"Normal")}
   var textSize by remember(orientation){mutableFloatStateOf(p.getInt(key("display_text_size"),16).toFloat())}
   var textColor by remember(orientation){mutableStateOf(p.getString(key("display_text_color"),"#FFFFFF")?:"#FFFFFF")}
   Text("Display text settings",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)
   Text("Text style",Modifier.padding(horizontal=16.dp))
   Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp)){launcherTextStyles.forEach{x->FilterChip(textFont==x,{textFont=x;p.edit().putString(key("display_text_font"),x).apply();changed()},{Text(x)},modifier=Modifier.padding(3.dp))}}
   Text("Size: ${textSize.toInt()} sp (1–80)",Modifier.padding(horizontal=16.dp))
   Slider(textSize,{textSize=it;p.edit().putInt(key("display_text_size"),it.toInt().coerceIn(1,80)).apply();changed()},valueRange=1f..80f,modifier=Modifier.padding(horizontal=16.dp))
   Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp)){listOf("Normal","Bold","Italic").forEach{x->FilterChip(textWeight==x,{textWeight=x;p.edit().putString(key("display_text_weight"),x).apply();changed()},{Text(x)},modifier=Modifier.padding(3.dp))}}
   LauncherColorControl("Display text color",textColor){textColor=it;p.edit().putString(key("display_text_color"),it).apply();changed()}
  }
  item{Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("Show clock and date",Modifier.weight(1f));Switch(clock,{clock=it;p.edit().putBoolean(key("show_clock"),it).apply();changed()})}}
  item{Text("Clock/date size: $clockSize sp",Modifier.padding(16.dp));Slider(clockSize.toFloat(),{clockSize=it.toInt();p.edit().putInt(key("clock_size"),clockSize).apply();changed()},valueRange=12f..64f,modifier=Modifier.padding(horizontal=16.dp))}
  item{LauncherColorControl("Clock/date color",clockColor){clockColor=it;p.edit().putString(key("clock_color"),it).apply();changed()}}
  item{Text("Clock/date font",Modifier.padding(horizontal=16.dp),fontWeight=FontWeight.Bold);Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(12.dp)){listOf("sans","serif","mono","cursive").forEach{x->FilterChip(clockFont==x,{clockFont=x;p.edit().putString(key("clock_font"),x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(3.dp))}}}
  item{
   Text("Clock placement",Modifier.padding(start=16.dp,top=16.dp,bottom=6.dp),fontWeight=FontWeight.Bold)
   Text("Vertical",Modifier.padding(horizontal=16.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
   Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){listOf("top","center","bottom").forEach{x->FilterChip(clockVertical==x,{clockVertical=x;p.edit().putString(key("clock_vertical"),x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.weight(1f).padding(3.dp))}}
   Text("Horizontal",Modifier.padding(start=16.dp,top=8.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
   Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){listOf("left","center","right").forEach{x->FilterChip(clockHorizontal==x,{clockHorizontal=x;p.edit().putString(key("clock_horizontal"),x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.weight(1f).padding(3.dp))}}
  }
  item{Text("Desktop columns: $cols",Modifier.padding(16.dp));Slider(cols.toFloat(),{cols=it.toInt().coerceIn(2,maxColumns);p.edit().putInt(key("desktop_cols"),cols).apply();changed()},valueRange=2f..maxColumns.toFloat(),steps=maxColumns-3,modifier=Modifier.padding(horizontal=16.dp));Text("Shortcuts use unlimited scrollable rows. Hold a file or website for 3 seconds to move it.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)}
  item{OutlinedTextField(custom,{custom=it;p.edit().putString(key("custom_text"),it).apply();changed()},label={Text("Desktop custom text")},modifier=Modifier.fillMaxWidth().padding(16.dp))}
  item{Text("Border design",Modifier.padding(16.dp),fontWeight=FontWeight.Bold);var border by remember(orientation){mutableStateOf(p.getString(key("border_style"),p.getString("border_style","rounded"))?:"rounded")};Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=12.dp)){listOf("none","rounded","ubuntu").forEach{x->FilterChip(border==x,{border=x;p.edit().putString(key("border_style"),x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(3.dp))}}}
 }
}

@Composable fun TaskbarSettings(p:android.content.SharedPreferences,changed:()->Unit){
 val context=LocalContext.current
 val overlayPermission=rememberTaskbarOverlayPermission(context)
 val overlayEnabled=p.getBoolean(TASKBAR_OVERLAY_ENABLED,false)
 var keyboardPriority by remember{mutableStateOf(p.getBoolean(TASKBAR_OVERLAY_KEYBOARD_PRIORITY,true))}
 val currentOrientation=orientationName(LocalConfiguration.current.orientation)
 var orientation by remember(currentOrientation){mutableStateOf(currentOrientation)}
 Column{
  SettingRow(
   Icons.Default.PictureInPictureAlt,
   "Show taskbar over other apps",
   when{
    overlayEnabled&&overlayPermission->"Enabled — taskbar remains visible when other apps are open"
    overlayEnabled->"Permission required before the taskbar can appear over other apps"
    else->"Keep the taskbar in the foreground while using other apps"
   },
   overlayEnabled
  ){
   val enabling=!overlayEnabled
   p.edit().putBoolean(TASKBAR_OVERLAY_ENABLED,enabling).apply();changed()
   if(enabling){
    if(overlayPermission)TaskbarOverlayController.sync(context,p,launcherVisible=true)
    else TaskbarOverlayController.openPermissionSettings(context)
   }else TaskbarOverlayController.sync(context,p,launcherVisible=true)
  }
  if(overlayEnabled&&!overlayPermission){
   Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically){
    Text("Android's Display over other apps permission is not granted.",Modifier.weight(1f),color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)
    TextButton({TaskbarOverlayController.openPermissionSettings(context)}){Text("Grant")}
   }
  }
  SettingRow(
   Icons.Default.Keyboard,
   "Let the keyboard cover the taskbar",
   if(keyboardPriority)"Prevents the overlay from covering keyboard keys" else "Taskbar stays above the keyboard",
   keyboardPriority
  ){
   keyboardPriority=!keyboardPriority
   p.edit().putBoolean(TASKBAR_OVERLAY_KEYBOARD_PRIORITY,keyboardPriority).apply();changed()
  }
  Text("The overlay follows the active orientation's position, size, opacity, direction, pinned-app order, auto-hide delay and placeholder design. Hide taskbar still takes priority.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  Text("Android does not let a normal draw-over-apps taskbar resize unrelated apps or reserve permanent desktop space. Keyboard priority prevents key overlap by placing the taskbar behind the keyboard while typing.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  HorizontalDivider(Modifier.padding(top=8.dp))
  Text("Taskbar orientation",Modifier.padding(start=16.dp,top=16.dp,bottom=6.dp),fontWeight=FontWeight.Bold)
  Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){
   listOf("portrait","landscape").forEach{option->
    FilterChip(
     selected=orientation==option,
     onClick={orientation=option},
     label={Text(option.replaceFirstChar{it.uppercase()})},
     leadingIcon={Icon(if(option=="portrait")Icons.Default.PhoneAndroid else Icons.Default.DesktopWindows,null)},
     modifier=Modifier.weight(1f).padding(3.dp)
    )
   }
  }
  Text("Portrait and landscape taskbars are configured independently.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  HorizontalDivider(Modifier.padding(top=8.dp))
  key(orientation){Box(Modifier.weight(1f)){TaskbarOrientationSettings(p,orientation,changed)}}
 }
}

@Composable fun TaskbarOrientationSettings(p:android.content.SharedPreferences,orientation:String,changed:()->Unit){
 val key:(String)->String={settingKey(it,orientation)}
 val defaultPosition=if(orientation=="landscape")"left" else "bottom"
 var pos by remember(orientation){mutableStateOf(p.getString(key("taskbar_pos"),p.getString("taskbar_pos",defaultPosition))?:defaultPosition)}
 var size by remember(orientation){mutableIntStateOf(p.getInt(key("taskbar_size"),p.getInt("taskbar_size",64)).coerceIn(44,110))}
 var opacity by remember(orientation){mutableIntStateOf(normalizeTaskbarOpacity(p.getInt(key("taskbar_opacity"),p.getInt("taskbar_opacity",DEFAULT_TASKBAR_OPACITY_PERCENT))))}
 var hide by remember(orientation){mutableStateOf(p.getBoolean(key("taskbar_hide"),p.getBoolean("taskbar_hide",false)))}
 var auto by remember(orientation){mutableStateOf(p.getBoolean(key("taskbar_auto"),p.getBoolean("taskbar_auto",false)))}
 var seconds by remember(orientation){mutableStateOf(p.getInt(key("taskbar_auto_seconds"),p.getInt("taskbar_auto_seconds",3)).coerceAtLeast(1).toString())}
 var direction by remember(orientation){mutableStateOf(normalizeTaskbarDirection(pos,p.getString(key("taskbar_direction"),p.getString("taskbar_direction",defaultTaskbarDirection(pos)))?:defaultTaskbarDirection(pos)))}
 LazyColumn{
  item{
   Text("Position",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)
   Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){listOf("left","right","top","bottom").forEach{option->
    FilterChip(pos==option,{
     val nextDirection=normalizeTaskbarDirection(option,direction)
     pos=option;direction=nextDirection
     p.edit().putString(key("taskbar_pos"),option).putString(key("taskbar_direction"),nextDirection).apply();changed()
    },{Text(option.replaceFirstChar{it.uppercase()})},modifier=Modifier.weight(1f).padding(3.dp))
   }}
  }
  item{
   val options=taskbarDirectionOptions(pos)
   Text("Direction",Modifier.padding(start=16.dp,top=16.dp,bottom=6.dp),fontWeight=FontWeight.Bold)
   Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){options.forEach{option->
    val icon=when(option){"up"->Icons.Default.ArrowUpward;"down"->Icons.Default.ArrowDownward;"left"->Icons.Default.West;else->Icons.Default.East}
    FilterChip(direction==option,{direction=option;p.edit().putString(key("taskbar_direction"),option).apply();changed()},{Text(option.replaceFirstChar{it.uppercase()})},leadingIcon={Icon(icon,null)},modifier=Modifier.weight(1f).padding(3.dp))
   }}
   val description=when(direction){
    "up"->"The Applications button starts at the bottom; pinned apps extend upward."
    "down"->"The Applications button starts at the top; pinned apps extend downward."
    "left"->"The Applications button starts at the right; pinned apps extend leftward."
    else->"The Applications button starts at the left; pinned apps extend rightward."
   }
   Text(description,Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  }
  item{
   Text("Size: $size dp",Modifier.padding(16.dp))
   Slider(size.toFloat(),{size=it.toInt();p.edit().putInt(key("taskbar_size"),size).apply();changed()},valueRange=44f..110f,modifier=Modifier.padding(horizontal=16.dp))
  }
  item{
   Text("Background opacity: $opacity%",Modifier.padding(start=16.dp,top=16.dp,bottom=4.dp))
   Slider(opacity.toFloat(),{opacity=it.toInt();p.edit().putInt(key("taskbar_opacity"),opacity).apply();changed()},valueRange=0f..100f,modifier=Modifier.padding(horizontal=16.dp))
   Text("Use 0% for floating icons with no taskbar background, or raise it for stronger contrast.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  }
  item{SettingRow(Icons.Default.VisibilityOff,"Hide taskbar","Never show the taskbar in this orientation",hide){hide=!hide;p.edit().putBoolean(key("taskbar_hide"),hide).apply();changed()}}
  item{SettingRow(Icons.Default.UnfoldLess,"Auto hide","Hide the taskbar after the configured delay",auto){auto=!auto;p.edit().putBoolean(key("taskbar_auto"),auto).apply();changed()}}
  if(auto)item{
   OutlinedTextField(seconds,{value->if(value.all{it.isDigit()}&&value.length<=5){seconds=value;value.toIntOrNull()?.coerceAtLeast(1)?.let{p.edit().putInt(key("taskbar_auto_seconds"),it).apply();changed()}}},label={Text("Auto-hide duration (seconds)")},singleLine=true,modifier=Modifier.fillMaxWidth().padding(16.dp))
  }
  item{TaskbarPlaceholderSettings(p,orientation,changed)}
 }
}

@Composable
private fun TaskbarPlaceholderSettings(
 p:android.content.SharedPreferences,
 orientation:String,
 changed:()->Unit
){
 val key:(String)->String={settingKey(it,orientation)}
 var primary by remember(orientation){mutableStateOf(p.getString(key("taskbar_handle_color"),p.getString("taskbar_handle_color",DEFAULT_TASKBAR_PLACEHOLDER_PRIMARY))?:DEFAULT_TASKBAR_PLACEHOLDER_PRIMARY)}
 var secondary by remember(orientation){mutableStateOf(p.getString(key("taskbar_handle_secondary_color"),p.getString("taskbar_handle_secondary_color",DEFAULT_TASKBAR_PLACEHOLDER_SECONDARY))?:DEFAULT_TASKBAR_PLACEHOLDER_SECONDARY)}
 var mode by remember(orientation){mutableStateOf(normalizeTaskbarPlaceholderMode(p.getString(key("taskbar_handle_style"),p.getString("taskbar_handle_style",DEFAULT_TASKBAR_PLACEHOLDER_MODE))))}
 var placeholderOpacity by remember(orientation){mutableIntStateOf(normalizeTaskbarPlaceholderOpacity(p.getInt(key("taskbar_handle_opacity"),p.getInt("taskbar_handle_opacity",DEFAULT_TASKBAR_PLACEHOLDER_OPACITY))))}
 var editSecondary by remember(orientation){mutableStateOf(false)}
 val selectedText=if(editSecondary)secondary else primary
 val selectedFallback=if(editSecondary)0xFF77216F.toInt() else 0xFFE95420.toInt()
 val style=TaskbarPlaceholderStyle(
  primaryArgb=parseArgbColor(primary,0xFFE95420.toInt()),
  secondaryArgb=parseArgbColor(secondary,0xFF77216F.toInt()),
  mode=mode,
  opacityPercent=placeholderOpacity
 )
 fun saveSelected(value:String){
  if(editSecondary){secondary=value;p.edit().putString(key("taskbar_handle_secondary_color"),value).apply()}
  else{primary=value;p.edit().putString(key("taskbar_handle_color"),value).apply()}
  changed()
 }
 Column(Modifier.fillMaxWidth()){
  HorizontalDivider(Modifier.padding(top=8.dp))
  Text("Hidden taskbar placeholder",Modifier.padding(start=16.dp,top=16.dp,bottom=4.dp),fontWeight=FontWeight.Bold)
  Text("Tap this square to restore an auto-hidden taskbar.",Modifier.padding(horizontal=16.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  Box(Modifier.fillMaxWidth().height(86.dp),contentAlignment=Alignment.Center){TaskbarPlaceholderPreview(style,Modifier.size(66.dp))}
  Text("Design",Modifier.padding(horizontal=16.dp,vertical=4.dp),fontWeight=FontWeight.SemiBold)
  val labels=mapOf("solid" to "Solid","linear" to "Linear","radial" to "Radial","stripes" to "Stripes","dots" to "Dots","checker" to "Checker")
  TASKBAR_PLACEHOLDER_MODES.chunked(3).forEach{rowModes->
   Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){rowModes.forEach{option->
    FilterChip(
     selected=mode==option,
     onClick={mode=option;p.edit().putString(key("taskbar_handle_style"),option).apply();changed()},
     label={Text(labels[option]?:option)},
     modifier=Modifier.weight(1f).padding(3.dp)
    )
   }}
  }
  Text("Colors",Modifier.padding(start=16.dp,top=14.dp,bottom=4.dp),fontWeight=FontWeight.SemiBold)
  Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){
   listOf(false,true).forEach{secondaryOption->
    val swatch=if(secondaryOption)style.secondaryArgb else style.primaryArgb
    FilterChip(
     selected=editSecondary==secondaryOption,
     onClick={editSecondary=secondaryOption},
     label={Text(if(secondaryOption)"Color 2" else "Color 1")},
     leadingIcon={Box(Modifier.size(18.dp).clip(RoundedCornerShape(4.dp)).background(Color(swatch)))},
     modifier=Modifier.weight(1f).padding(3.dp)
    )
   }
  }
  key(editSecondary){ColorWheelPicker(parseArgbColor(selectedText,selectedFallback)){saveSelected(argbToOpaqueHex(it))}}
  val validColor=normalizeHexColor(selectedText)
  OutlinedTextField(
   value=selectedText,
   onValueChange={value->
    if(editSecondary)secondary=value else primary=value
    normalizeHexColor(value)?.let(::saveSelected)
   },
   label={Text("Selected color (optional hex)")},
   supportingText={Text(if(validColor==null)"Use the wheel or enter #RRGGBB" else "The color wheel means no code is required")},
   isError=validColor==null,
   singleLine=true,
   trailingIcon={Box(Modifier.size(28.dp).clip(RoundedCornerShape(4.dp)).background(Color(parseArgbColor(selectedText,selectedFallback))))},
   modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=8.dp)
  )
  Text("Placeholder opacity: $placeholderOpacity%",Modifier.padding(start=16.dp,top=8.dp,bottom=4.dp))
  Slider(
   placeholderOpacity.toFloat(),
   {placeholderOpacity=normalizeTaskbarPlaceholderOpacity(it.roundToInt());p.edit().putInt(key("taskbar_handle_opacity"),placeholderOpacity).apply();changed()},
   valueRange=0f..100f,
   modifier=Modifier.padding(horizontal=16.dp)
  )
  Text("Gradients and patterns use both colors. Opacity changes the complete placeholder without changing either saved color.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  Text("When auto-hide conceals the taskbar, the placeholder remains in the same screen slot as the nine-dot Applications button.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
 }
}
@Composable fun AppsSettings(p:android.content.SharedPreferences,changed:()->Unit){
 var orientation by remember { mutableStateOf("portrait") }
 val key:(String)->String={settingKey(it,orientation)}
 var grid by remember(orientation) { mutableStateOf(p.getBoolean(key("app_grid"),p.getBoolean("app_grid",true))) }
 var drawerExtent by remember(orientation){mutableIntStateOf(normalizeAppDrawerExtent(p.getInt(key("app_drawer_extent"),defaultAppDrawerExtent(orientation))))}
 var appIconSize by remember(orientation){mutableIntStateOf(normalizeAppListIconSize(p.getInt(key("app_list_icon_size"),48)))}
 var appLabelSize by remember(orientation){mutableIntStateOf(normalizeAppListLabelSize(p.getInt(key("app_list_label_size"),12)))}
 var showGridLabels by remember(orientation){mutableStateOf(p.getBoolean(key("app_grid_show_labels"),true))}
 LazyColumn(modifier=Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=24.dp)) {
  item {
   Text("Configure applications list for",Modifier.padding(start=16.dp,top=12.dp,bottom=4.dp),fontWeight=FontWeight.Bold)
   Row(Modifier.padding(horizontal=12.dp)) {
    listOf("portrait","landscape").forEach { option ->
     FilterChip(orientation==option,{orientation=option}, {Text(option.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(4.dp))
    }
   }
   Text("Each orientation saves its own layout, placement, colors and sizes.",Modifier.padding(horizontal=16.dp),style=MaterialTheme.typography.bodySmall)
  }
  item {
   var position by remember(orientation) { mutableStateOf(p.getString(key("app_drawer_position"),"auto")?:"auto") }
   Text("Applications list position",Modifier.padding(start=16.dp,top=16.dp,bottom=4.dp),fontWeight=FontWeight.Bold)
   Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=12.dp)) {
    listOf("left","center","right").forEach { option ->
     FilterChip(position==option,{position=option;p.edit().putString(key("app_drawer_position"),option).apply();changed()}, {Text(option.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(4.dp))
    }
   }
   Text("Move the applications panel to the left, center or right independently of the taskbar. The panel width is controlled below.",Modifier.padding(horizontal=16.dp,vertical=4.dp),style=MaterialTheme.typography.bodySmall)
  }
  item { SettingRow(Icons.Default.GridView,"Grid view","Show apps as icons in a grid",grid){grid=true;p.edit().putBoolean(key("app_grid"),true).apply();changed()} }
  item { SettingRow(Icons.AutoMirrored.Filled.ViewList,"List view","Show apps in a detailed list",!grid){grid=false;p.edit().putBoolean(key("app_grid"),false).apply();changed()} }
  item { SettingRow(Icons.Default.Description,"Show app text in grid","Show or hide application names beneath grid icons",showGridLabels){showGridLabels=!showGridLabels;p.edit().putBoolean(key("app_grid_show_labels"),showGridLabels).apply();changed()} }
  item{
   Text("Applications popout edge: $drawerExtent%",Modifier.padding(start=16.dp,top=16.dp,bottom=4.dp),fontWeight=FontWeight.Bold)
   Slider(
    value=drawerExtent.toFloat(),
    onValueChange={drawerExtent=normalizeAppDrawerExtent(it.roundToInt());p.edit().putInt(key("app_drawer_extent"),drawerExtent).apply();changed()},
    valueRange=40f..100f,
    steps=59,
    modifier=Modifier.padding(horizontal=16.dp)
   )
   Text("Sets where the inside edge of the app list stops. The panel can be positioned left, center or right; 100% uses the whole screen.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  }
  item {
   Text("Applications list icon size: $appIconSize dp",Modifier.padding(start=16.dp,top=16.dp,bottom=4.dp),fontWeight=FontWeight.Bold)
   Slider(appIconSize.toFloat(),{appIconSize=normalizeAppListIconSize(it.roundToInt());p.edit().putInt(key("app_list_icon_size"),appIconSize).apply();changed()},valueRange=20f..96f,modifier=Modifier.padding(horizontal=16.dp))
   Text("Adjusts application icons in both grid and list views for this orientation.",Modifier.padding(horizontal=16.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  }
  item {
   Text("Applications list text size: $appLabelSize sp",Modifier.padding(start=16.dp,top=16.dp,bottom=4.dp),fontWeight=FontWeight.Bold)
   Slider(appLabelSize.toFloat(),{appLabelSize=normalizeAppListLabelSize(it.roundToInt());p.edit().putInt(key("app_list_label_size"),appLabelSize).apply();changed()},valueRange=8f..28f,steps=19,modifier=Modifier.padding(horizontal=16.dp))
   Text("Adjusts application names and list descriptions for this orientation.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
  }
  item {
   var direction by remember(orientation){mutableStateOf(p.getString(key("app_grid_scroll"),"vertical")?:"vertical")}
   Text("Applications grid scroll direction",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)
   Row(Modifier.padding(horizontal=12.dp)){listOf("vertical","horizontal").forEach{x->FilterChip(direction==x,{direction=x;p.edit().putString(key("app_grid_scroll"),x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(4.dp))}}
  }
  item {
   var enabled by remember(orientation){mutableStateOf(p.getBoolean(key("app_icon_tint_enabled"),false))}
   var tint by remember(orientation){mutableStateOf(p.getString(key("app_icon_tint"),"#FFFFFF")?:"#FFFFFF")}
   Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("Two-color application icons",Modifier.weight(1f));Switch(enabled,{enabled=it;p.edit().putBoolean(key("app_icon_tint_enabled"),it).apply();changed()})}
   LauncherColorControl("Application icon background color",tint){tint=it;p.edit().putString(key("app_icon_tint"),it).apply();changed()}
   var opacity by remember(orientation) { mutableIntStateOf(normalizeAppIconOpacity(p.getInt(key("app_icon_opacity"),100))) }
   Text("Application icon opacity: $opacity%",Modifier.padding(start=16.dp,top=12.dp,bottom=4.dp),fontWeight=FontWeight.Bold)
   Slider(value=opacity.toFloat(),onValueChange={ value ->
       opacity=normalizeAppIconOpacity(value.roundToInt())
       p.edit().putInt(key("app_icon_opacity"),opacity).apply()
       changed()
   },valueRange=0f..100f,modifier=Modifier.padding(horizontal=16.dp))
   Text("Controls icon transparency in grid and list views, with or without icon recoloring. 100% is fully visible; 0% is invisible. Each orientation is independent.",Modifier.padding(horizontal=16.dp,vertical=4.dp),style=MaterialTheme.typography.bodySmall)

   Text("Two-color mode places the original application artwork over a separately colored background. The background color is selectable, and the opacity slider affects the entire icon. This avoids turning icons into solid silhouettes.",Modifier.padding(16.dp),style=MaterialTheme.typography.bodySmall)
  }
  item {
   var background by remember(orientation){mutableStateOf(p.getString(key("app_list_background_color"),"#2C1236")?:"#2C1236")}
   LauncherColorControl("Applications list background",background){background=it;p.edit().putString(key("app_list_background_color"),it).apply();changed()}
  }
  item { Text("Pinned applications",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)
   Text("Long-press an application in the drawer to pin or unpin it. Pinned applications appear first.",Modifier.padding(horizontal=16.dp,vertical=4.dp),style=MaterialTheme.typography.bodySmall) }
 }
}
@Composable fun LockSettings(p:android.content.SharedPreferences,changed:()->Unit){
 var hasCredential by remember{mutableStateOf(p.getString("lock_hash","").orEmpty().isNotBlank())}
 var enabled by remember{mutableStateOf(p.getBoolean("lock_enabled",false)&&hasCredential)}
 var pass by remember{mutableStateOf("")}
 var message by remember{mutableStateOf<String?>(if(p.getBoolean("lock_enabled",false)&&!hasCredential)"Save a PIN or password before enabling the lock." else null)}
 Column(Modifier.padding(16.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){
   Text("Enable launcher lock layer",Modifier.weight(1f))
   Switch(enabled,{requested->
    if(requested&&!hasCredential)message="Save a PIN or password first."
    else{enabled=requested;message=if(requested)"Lock enabled. The lock screen is now active." else "Lock disabled.";p.edit().putBoolean("lock_enabled",requested).putLong("lock_request",System.currentTimeMillis()).apply();changed()}
   })
  }
  OutlinedTextField(pass,{pass=it;message=null},label={Text("New PIN or password")},singleLine=true,visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Password),modifier=Modifier.fillMaxWidth())
  Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){
   Button({
    if(pass.length<4)message="Use at least 4 characters."
    else{p.edit().putString("lock_hash",hash(pass)).putLong("lock_request",System.currentTimeMillis()).apply();pass="";hasCredential=true;message=if(enabled)"PIN/password saved. Lock screen activated." else "PIN/password saved. Turn on the lock when ready.";changed()}
   }){Text("Save PIN/password")}
   if(enabled&&hasCredential){Spacer(Modifier.width(8.dp));OutlinedButton({p.edit().putLong("lock_request",System.currentTimeMillis()).apply();changed()}){Text("Lock now")}}
  }
  message?.let{Text(it,Modifier.padding(top=10.dp),color=if(it.contains("first")||it.contains("least"))MaterialTheme.colorScheme.error else Color.DarkGray)}
  Text("When enabled, the launcher locks immediately and re-locks whenever it leaves the foreground. Android's system keyguard remains the authoritative device lock; this layer protects the launcher UI but does not replace Android secure lock-screen enforcement.",Modifier.padding(top=18.dp),color=Color.Gray)
 }
}
@Composable fun LockOverlay(p:android.content.SharedPreferences,unlock:()->Unit){
 BackHandler(enabled=true){}
 var v by remember{mutableStateOf("")};var error by remember{mutableStateOf<String?>(null)};var now by remember{mutableLongStateOf(System.currentTimeMillis())}
 fun submit(){if(hash(v)==p.getString("lock_hash","")){error=null;v="";unlock()}else error="Incorrect PIN or password."}
 LaunchedEffect(Unit){while(true){now=System.currentTimeMillis();delay(1000L-(now%1000L))}}
 Surface(Modifier.fillMaxSize(),color=Aubergine){
  Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
   Icon(Icons.Default.Lock,"Launcher locked",tint=Orange,modifier=Modifier.size(72.dp))
   Text(SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date(now)),color=Color.White,style=MaterialTheme.typography.displayMedium)
   Text(DateFormat.getDateInstance().format(Date(now)),color=Color.White)
   OutlinedTextField(v,{v=it;error=null},label={Text("PIN or password")},singleLine=true,isError=error!=null,visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Password,imeAction=ImeAction.Done),keyboardActions=KeyboardActions(onDone={submit()}),modifier=Modifier.padding(top=24.dp))
   error?.let{Text(it,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(top=8.dp))}
   Button({submit()},Modifier.padding(top=12.dp),enabled=v.isNotBlank()){Text("Unlock")}
  }
 }
}

@Composable fun WeatherSettings(apps:List<AppItem>,p:android.content.SharedPreferences,changed:()->Unit){
 var show by remember{mutableStateOf(p.getBoolean("show_weather",true))}
 Column{
  SettingRow(Icons.Default.Cloud,"Show weather emblem","Show or hide the selected weather app emblem on the main desktop",show){show=!show;p.edit().putBoolean("show_weather",show).apply();changed()}
  Text("Weather application",Modifier.padding(start=16.dp,top=14.dp,bottom=6.dp),fontWeight=FontWeight.Bold)
  Box(Modifier.weight(1f)){AppSelector(apps,p,"weather_app",false,single=true,changed=changed)}
 }
}
@Composable fun PinnedAppsSettings(apps:List<AppItem>,p:android.content.SharedPreferences,changed:()->Unit){
 val uniqueApps=remember(apps){apps.distinctBy{it.packageName}}
 var selected by remember{mutableStateOf(p.getStringSet("pins",emptySet()).orEmpty())}
 var order by remember(apps){mutableStateOf(resolvePinnedOrder(selected,p.getString(PIN_ORDER_PREFERENCE,null),uniqueApps.map{it.packageName}))}
 fun persist(nextSelected:Set<String>,nextOrder:List<String>){
  val normalized=resolvePinnedOrder(nextSelected,nextOrder.joinToString(PIN_ORDER_SEPARATOR),uniqueApps.map{it.packageName})
  selected=nextSelected
  order=normalized
  savePinnedApps(p,nextSelected,normalized)
  changed()
 }
 val pinned=order.mapNotNull{packageName->uniqueApps.firstOrNull{it.packageName==packageName}}
 val available=uniqueApps.filter{it.packageName !in selected}
 LazyColumn{
  item{
   Text("Pinned app order",Modifier.padding(start=16.dp,top=16.dp,end=16.dp),fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium)
   Text("Use the arrows to arrange the taskbar. Changes appear on the home screen immediately.",Modifier.padding(horizontal=16.dp,vertical=6.dp),color=Color.Gray)
  }
  if(pinned.isEmpty())item{Text("No apps are pinned yet.",Modifier.padding(16.dp),color=Color.Gray)}
  items(pinned,key={"pinned:${it.packageName}"}){app->
   val index=order.indexOf(app.packageName)
   Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically){
    AppIcon(app,64,Modifier.size(38.dp));Spacer(Modifier.width(10.dp));Text(app.label,Modifier.weight(1f),maxLines=1)
    IconButton({persist(selected,movePinnedPackage(order,app.packageName,-1))},enabled=index>0){Icon(Icons.Default.ArrowUpward,"Move ${app.label} earlier")}
    IconButton({persist(selected,movePinnedPackage(order,app.packageName,1))},enabled=index>=0&&index<pinned.lastIndex){Icon(Icons.Default.ArrowDownward,"Move ${app.label} later")}
    Checkbox(true,{persist(selected-app.packageName,order-app.packageName)})
   }
  }
  item{HorizontalDivider(Modifier.padding(top=8.dp));Text("Available apps",Modifier.padding(16.dp),fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium)}
  items(available,key={"available:${it.packageName}"}){app->
   Row(Modifier.fillMaxWidth().clickable{persist(selected+app.packageName,order+app.packageName)}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
    AppIcon(app,64,Modifier.size(38.dp));Spacer(Modifier.width(12.dp));Text(app.label,Modifier.weight(1f));Checkbox(false,null)
   }
  }
 }
}
@Composable fun AppSelector(apps:List<AppItem>,p:android.content.SharedPreferences,key:String,launchable:Boolean,single:Boolean=false,changed:()->Unit){val c=LocalContext.current;var selected by remember{mutableStateOf(p.getStringSet(key,emptySet()).orEmpty())};LazyColumn{items(apps,key={it.packageName+it.activityName}){a->Row(Modifier.fillMaxWidth().clickable{val s=if(single)mutableSetOf<String>() else selected.toMutableSet();if(single)s.add(a.packageName) else if(!s.add(a.packageName))s.remove(a.packageName);selected=s;p.edit().putStringSet(key,s).apply();changed()}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){AppIcon(a,64,Modifier.size(38.dp));Spacer(Modifier.width(12.dp));Text(a.label,Modifier.weight(1f));if(launchable)IconButton({launch(c,a)}){Icon(Icons.AutoMirrored.Filled.OpenInNew,"Open")};Checkbox(a.packageName in selected,null)}}}}
@Composable fun LicenseScreen(){val c=LocalContext.current;val t=remember{runCatching{c.resources.openRawResource(R.raw.agpl_3_0).bufferedReader().use{it.readText()}}.getOrElse{"Unable to load license."}};LazyColumn(Modifier.padding(18.dp)){item{Text("GNU Affero General Public License",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge,color=Aubergine);Text("Version 3, 19 November 2007",color=Color.Gray);Spacer(Modifier.height(16.dp));Text(t,style=MaterialTheme.typography.bodySmall)}}}
@Composable fun AboutScreen(){Column(Modifier.padding(18.dp)){Text("Ubuntu Launcher",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.headlineSmall,color=Aubergine);Text("Version ${BuildConfig.VERSION_NAME}");Spacer(Modifier.height(16.dp));Text("Developer",fontWeight=FontWeight.Bold);Text("Maclean Of Duart Enterprises Corp");Text(BuildConfig.APPLICATION_ID);Spacer(Modifier.height(16.dp));Text("Licensed under GNU AGPLv3. Ubuntu is a registered trademark of Canonical Ltd. This independent launcher is not endorsed by or affiliated with Canonical.",color=Color.DarkGray)}}
@Composable
fun ThemeModeSettings(p: android.content.SharedPreferences, changed: () -> Unit) {
 var selected by remember { mutableStateOf(p.getString(THEME_MODE_KEY, "auto") ?: "auto") }
 Column(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=12.dp)) {
  Text("Application appearance", style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold)
  Text("Controls launcher menus, settings, dialogs and other Material surfaces. Auto follows Android's system appearance.", color=MaterialTheme.colorScheme.onSurfaceVariant)
  listOf("light" to "Light", "dark" to "Dark", "auto" to "Auto (system)").forEach { (value, label) ->
   Row(Modifier.fillMaxWidth().clickable {
    selected=value
    p.edit().putString(THEME_MODE_KEY,value).apply()
    changed()
   }.padding(vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
    RadioButton(selected == value, onClick={selected=value;p.edit().putString(THEME_MODE_KEY,value).apply();changed()})
    Text(label, Modifier.padding(start=8.dp))
   }
  }
 }
}

@Composable
fun UbuntuTheme(p:android.content.SharedPreferences, revision:Int, content: @Composable () -> Unit) {
 val mode=remember(revision){p.getString(THEME_MODE_KEY,"auto")?:"auto"}
 val dark=resolveDarkThemeMode(mode,isSystemInDarkTheme())
 val scheme=if(dark) darkColorScheme(
  primary=Color(0xFFFFA36B),onPrimary=Color(0xFF351A0A),
  primaryContainer=Color(0xFF3D1230),onPrimaryContainer=Color.White,
  secondary=Color(0xFFE5B5CE),background=Color(0xFF17121A),onBackground=Color(0xFFF3EDF3),
  surface=Color(0xFF211A25),onSurface=Color(0xFFF3EDF3),
  surfaceVariant=Color(0xFF3A303E),onSurfaceVariant=Color(0xFFD4C5D5)
 ) else lightColorScheme(
  primary=Orange,onPrimary=Color.White,primaryContainer=Aubergine,onPrimaryContainer=Color.White,
  secondary=Aubergine,background=Warm,onBackground=Color(0xFF211A22),
  surface=Warm,onSurface=Color(0xFF211A22),surfaceVariant=Color(0xFFEAE0E6),onSurfaceVariant=Color(0xFF635B64)
 )
 val activity=LocalActivity.current
 SideEffect {
  activity?.window?.let { window ->
   WindowCompat.getInsetsController(window,window.decorView).apply {
    isAppearanceLightStatusBars=!dark
    isAppearanceLightNavigationBars=!dark
   }
  }
 }
 MaterialTheme(colorScheme=scheme,content=content)
}
