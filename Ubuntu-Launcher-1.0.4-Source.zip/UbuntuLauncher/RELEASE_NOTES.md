# Ubuntu Launcher 1.0.4

## Desktop layout

- The clock and custom text now occupy a reserved grid row and cannot overlap shared files or website links.
- Hold a file or website shortcut for three seconds to enter move mode. Drag it to a visible slot, or release, scroll, and tap any destination. Moving onto an occupied slot swaps the two shortcuts.
- Shortcut positions are saved independently for the main and secondary pages in portrait and landscape.
- Landscape supports 2–14 columns; portrait supports 2–8 columns.
- File and link rows expand as needed and scroll vertically in both orientations.

## Website icons

- Restored favicon loading without a background WebView.
- Discovers page icon links, Apple touch icons, web-manifest icons, and conventional favicon locations.
- Follows redirects and caches successful icons in memory and on disk for faster subsequent launches.

## Existing 1.0.3.002 improvements retained

- Updated Ubuntu Launcher app icon.
- Separate portrait and landscape display settings, including top/center/bottom and left/center/right clock placement.
- Launcher PIN/password activation, immediate **Lock now**, incorrect-entry feedback, and automatic re-lock after the launcher leaves the foreground.

The launcher lock protects the Ubuntu Launcher interface; Android's secure system keyguard remains the device-level lock.
