package com.macleanofduartenterprises.ubuntulauncher

import android.app.role.RoleManager
import android.content.*
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.automirrored.filled.ViewSidebar
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.ceil
import java.security.MessageDigest
import java.text.*
import java.util.*
import org.json.JSONObject
import org.json.JSONArray

private val Aubergine=Color(0xFF2C001E); private val Aubergine2=Color(0xFF3D1230); private val Orange=Color(0xFFE95420); private val Warm=Color(0xFFF7F3F0)
data class AppItem(val label:String,val packageName:String,val activityName:String,val icon:Drawable)
data class SettingItem(val label:String,val subtitle:String,val action:String)

class MainActivity:ComponentActivity(){
    private val prefs by lazy{getSharedPreferences("launcher",MODE_PRIVATE)}
    private val roleRequest=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){}
    private val photos=registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->
        if(uris.isNotEmpty()){uris.forEach{runCatching{contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}};prefs.edit().putStringSet(wallKey(prefs,prefs.getBoolean("picking_dumb",false),prefs.getString("picking_orientation","portrait") ?: "portrait"),uris.map{it.toString()}.toSet()).apply()}
    }
    private val file=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri-> uri?.let{
        runCatching{contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
        val page=prefs.getString("shortcut_target_page","main")?:"main"; val key=if(page=="secondary")"desktop_files_secondary" else "desktop_files_main"; val set=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.add("${it}|Pinned file");prefs.edit().putStringSet(key,set).apply()
    }}
    val backupOut=registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->uri?.let{exportBackup(it)}}
    val backupIn=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->uri?.let{importBackup(it);recreate()}}
    private fun exportBackup(uri:Uri){val root=JSONObject();prefs.all.forEach{(k,v)->when(v){is String->root.put(k,v);is Boolean->root.put(k,v);is Int->root.put(k,v);is Long->root.put(k,v);is Float->root.put(k,v);is Set<*>->root.put(k,JSONArray(v.filterIsInstance<String>()))}};contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(root.toString(2))}}
    private fun importBackup(uri:Uri){val text=contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:return;val root=JSONObject(text);val e=prefs.edit().clear();root.keys().forEach{k->when(val v=root.get(k)){is Boolean->e.putBoolean(k,v);is Int->e.putInt(k,v);is Long->e.putLong(k,v);is Double->e.putFloat(k,v.toFloat());is JSONArray->{val set=mutableSetOf<String>();for(i in 0 until v.length())set.add(v.getString(i));e.putStringSet(k,set)}else->e.putString(k,v.toString())}};e.apply()}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);acceptShare(intent);setContent{LauncherApp(prefs,{d,o->prefs.edit().putBoolean("picking_dumb",d).putString("picking_orientation",o).apply();photos.launch(arrayOf("image/*"))},{file.launch(arrayOf("*/*"))})}}
    override fun onNewIntent(intent:Intent){super.onNewIntent(intent);acceptShare(intent)}
    private fun acceptShare(i:Intent){if(i.action!=Intent.ACTION_SEND)return; val e=prefs.edit(); val uri=if(Build.VERSION.SDK_INT>=33)i.getParcelableExtra(Intent.EXTRA_STREAM,Uri::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM); val page=prefs.getString("shortcut_target_page","main")?:"main"; val suffix=if(page=="secondary")"secondary" else "main"; if(uri!=null){if(i.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION!=0&&i.flags and Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION!=0)runCatching{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)};val key="desktop_files_$suffix";val s=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();s.add("$uri|Shared file");e.putStringSet(key,s)}; i.getStringExtra(Intent.EXTRA_TEXT)?.let{t->if(t.startsWith("http")){val key="desktop_links_$suffix";val s=prefs.getStringSet(key,emptySet()).orEmpty().toMutableSet();s.add("$t|Shared link");e.putStringSet(key,s)}};e.apply()}
    fun requestHome(){if(Build.VERSION.SDK_INT>=29){val r=getSystemService(RoleManager::class.java);if(r.isRoleAvailable(RoleManager.ROLE_HOME)&&!r.isRoleHeld(RoleManager.ROLE_HOME))roleRequest.launch(r.createRequestRoleIntent(RoleManager.ROLE_HOME))}else startActivity(Intent(Settings.ACTION_HOME_SETTINGS))}
}
fun loadApps(c:Context):List<AppItem>{val q=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);return c.packageManager.queryIntentActivities(q,0).filter{it.activityInfo.packageName!=c.packageName}.map{AppItem(it.loadLabel(c.packageManager).toString(),it.activityInfo.packageName,it.activityInfo.name,it.loadIcon(c.packageManager))}.distinctBy{it.packageName+it.activityName}.sortedBy{it.label.lowercase()}}
fun launch(c:Context,a:AppItem)=runCatching{c.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(ComponentName(a.packageName,a.activityName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}.let{}
fun openSetting(c:Context,a:String)=runCatching{c.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}.let{}
fun hash(v:String)=MessageDigest.getInstance("SHA-256").digest(v.toByteArray()).joinToString(""){"%02x".format(it)}

@Composable fun LauncherApp(p:android.content.SharedPreferences,pickPhotos:(Boolean,String)->Unit,pickFile:()->Unit){
 val c=LocalContext.current;val appContext=c.applicationContext;val scope=rememberCoroutineScope();var apps by remember{mutableStateOf<List<AppItem>>(emptyList())};var settings by remember{mutableStateOf(false)};var drawer by remember{mutableStateOf(false)};var q by remember{mutableStateOf("")};var tick by remember{mutableIntStateOf(0)}
 suspend fun refreshApps(){apps=withContext(Dispatchers.IO){loadApps(appContext)}}
 LaunchedEffect(appContext){refreshApps()}
 DisposableEffect(p){
  val listener=android.content.SharedPreferences.OnSharedPreferenceChangeListener{_,_->tick++}
  p.registerOnSharedPreferenceChangeListener(listener)
  onDispose{p.unregisterOnSharedPreferenceChangeListener(listener)}
 }
 DisposableEffect(appContext){val r=object:BroadcastReceiver(){override fun onReceive(x:Context?,i:Intent?){scope.launch{refreshApps()}}};val f=IntentFilter().apply{addAction(Intent.ACTION_PACKAGE_ADDED);addAction(Intent.ACTION_PACKAGE_REMOVED);addAction(Intent.ACTION_PACKAGE_CHANGED);addDataScheme("package")};ContextCompat.registerReceiver(appContext,r,f,ContextCompat.RECEIVER_EXPORTED);onDispose{runCatching{appContext.unregisterReceiver(r)}}}
 val hidden=remember(tick){p.getStringSet("hidden",emptySet()).orEmpty()};val dumb=remember(tick){p.getBoolean("dumb_mode",false)};val allow=remember(tick){p.getStringSet("dumb",emptySet()).orEmpty()};val visible=remember(apps,hidden,dumb,allow){apps.filter{it.packageName !in hidden&&(!dumb||it.packageName in allow)}}
 val lockEnabled=remember(tick){p.getBoolean("lock_enabled",false)}
 val lockHash=remember(tick){p.getString("lock_hash","").orEmpty()}
 val lockRequest=remember(tick){p.getLong("lock_request",0L)}
 val hasLockCredential=lockHash.isNotBlank()
 var unlocked by remember{mutableStateOf(!(lockEnabled&&hasLockCredential))}
 LaunchedEffect(lockEnabled,lockHash,lockRequest){unlocked=!(lockEnabled&&hasLockCredential)}
 val lifecycleOwner=LocalLifecycleOwner.current
 DisposableEffect(lifecycleOwner,lockEnabled,hasLockCredential){
  val observer=LifecycleEventObserver{_,event->if(event==Lifecycle.Event.ON_STOP&&lockEnabled&&hasLockCredential)unlocked=false}
  lifecycleOwner.lifecycle.addObserver(observer)
  onDispose{lifecycleOwner.lifecycle.removeObserver(observer)}
 }
 UbuntuTheme{Box(Modifier.fillMaxSize()){Wallpaper(p,dumb);HomeShell(visible,apps,p,dumb,{drawer=true},{settings=true},pickFile){tick++};if(drawer)AppDrawer(visible,q,{q=it},{drawer=false},{settings=true},p){tick++};if(settings)LauncherSettings(apps,p,{settings=false},{tick++},pickPhotos,pickFile,{(c as? MainActivity)?.backupOut?.launch("ubuntu-launcher-backup.json")},{(c as? MainActivity)?.backupIn?.launch(arrayOf("application/json","text/plain"))});if(!unlocked&&lockEnabled&&hasLockCredential)LockOverlay(p){unlocked=true}}}
}

fun decodeSampledImage(c:Context,uri:Uri,requestWidth:Int,requestHeight:Int):ImageBitmap?{val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};c.contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it,null,bounds)};if(bounds.outWidth<=0||bounds.outHeight<=0)return null;var sample=1;while(bounds.outWidth/(sample*2)>=requestWidth&&bounds.outHeight/(sample*2)>=requestHeight)sample*=2;val options=BitmapFactory.Options().apply{inSampleSize=sample;inPreferredConfig=Bitmap.Config.ARGB_8888};return c.contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it,null,options)}?.asImageBitmap()}

@Composable fun Wallpaper(p:android.content.SharedPreferences,dumb:Boolean){val configuration=LocalConfiguration.current;val orientation=orientationName(configuration.orientation);val key=wallKey(p,dumb,orientation);val legacy=if(dumb)"wall_dumb" else "wall_regular";val uris=p.getStringSet(key,p.getStringSet(legacy,emptySet())).orEmpty().toList();var idx by remember(uris){mutableIntStateOf(0)};val interval=p.getInt(if(dumb)"slide_dumb" else "slide_regular",15).coerceAtLeast(3);if(uris.size>1)LaunchedEffect(uris,interval){while(true){delay(interval*1000L);idx=(idx+1)%uris.size}};val c=LocalContext.current;val density=LocalDensity.current;val requestWidth=with(density){configuration.screenWidthDp.dp.roundToPx()};val requestHeight=with(density){configuration.screenHeightDp.dp.roundToPx()};val bm by produceState<ImageBitmap?>(null,uris,idx,requestWidth,requestHeight){value=uris.getOrNull(idx)?.let{u->withContext(Dispatchers.IO){runCatching{decodeSampledImage(c,Uri.parse(u),requestWidth,requestHeight)}.getOrNull()}}};if(bm!=null)Image(bm!!,null,Modifier.fillMaxSize(),contentScale=scaleFor(p.getString(settingKey("${legacy}_scale",orientation),"crop")?:"crop"))else Box(Modifier.fillMaxSize().background(Aubergine2));Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=.18f)))}

@Composable fun HomeShell(visible:List<AppItem>,all:List<AppItem>,p:android.content.SharedPreferences,dumb:Boolean,drawer:()->Unit,settings:()->Unit,pickFile:()->Unit,changed:()->Unit){
 val landscape=LocalConfiguration.current.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE
 val pos=p.getString("taskbar_pos",if(landscape)"left" else "bottom")?:"bottom"
 val hide=p.getBoolean("taskbar_hide",false);var autoShown by remember{mutableStateOf(true)};val auto=p.getBoolean("taskbar_auto",false)
 val autoSeconds=p.getInt("taskbar_auto_seconds",3).coerceAtLeast(1)
 val gestures=p.getBoolean("swipe_actions",false)
 val content: @Composable () -> Unit = { DesktopContent(visible,all,p,dumb,drawer,settings,pickFile,changed) }
 if(auto) LaunchedEffect(pos,autoShown,autoSeconds){if(autoShown){delay(autoSeconds*1000L);autoShown=false}}
 var drag by remember{mutableFloatStateOf(0f)}
 val swipeModifier=if(gestures) Modifier.pointerInput(Unit){detectHorizontalDragGestures(onDragStart={drag=0f},onHorizontalDrag={_,amount->drag+=amount},onDragEnd={if(drag>120f)drawer() else if(drag< -120f)settings();drag=0f})} else Modifier
 Column(Modifier.fillMaxSize().then(swipeModifier).statusBarsPadding().navigationBarsPadding()){
  if(!hide&&(!auto||autoShown)&&pos=="top")Taskbar(all,p,drawer,changed,false,auto){autoShown=!autoShown}
  Row(Modifier.weight(1f)){
   if(!hide&&(!auto||autoShown)&&pos=="left")Taskbar(all,p,drawer,changed,true,auto){autoShown=!autoShown}
   Box(Modifier.weight(1f)){content();if(auto&&!autoShown)TaskbarRevealDot(pos){autoShown=true}}
   if(!hide&&(!auto||autoShown)&&pos=="right")Taskbar(all,p,drawer,changed,true,auto){autoShown=!autoShown}
  }
  if(!hide&&(!auto||autoShown)&&pos=="bottom")Taskbar(all,p,drawer,changed,false,auto){autoShown=!autoShown}
 }
}
@Composable fun BoxScope.TaskbarRevealDot(pos:String,show:()->Unit){val a=when(pos){"top"->Alignment.TopCenter;"left"->Alignment.CenterStart;"right"->Alignment.CenterEnd;else->Alignment.BottomCenter};Box(Modifier.align(a).padding(5.dp).size(14.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Orange).clickable{show()})}

private enum class DesktopShortcutKind { FILE, WEBSITE, WEATHER }

private data class DesktopShortcut(
    val id: String,
    val kind: DesktopShortcutKind,
    val target: String,
    val label: String,
    val preferenceKey: String?,
    val entry: String
)

private fun desktopShortcutId(kind: DesktopShortcutKind, target: String): String =
    hash("desktop|" + kind.name + "|" + target)

private fun desktopPositionKey(page: String, orientation: String): String =
    "desktop_positions_" + page + "_" + orientation

private fun readDesktopPositions(
    preferences: android.content.SharedPreferences,
    key: String
): Map<String, Int> =
    parseDesktopPositions(preferences.getStringSet(key, emptySet()).orEmpty())

private fun saveDesktopPositions(
    preferences: android.content.SharedPreferences,
    key: String,
    positions: Map<String, Int>
) {
    preferences.edit().putStringSet(key, encodeDesktopPositions(positions)).apply()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DesktopContent(
    visible: List<AppItem>,
    all: List<AppItem>,
    p: android.content.SharedPreferences,
    dumb: Boolean,
    drawer: () -> Unit,
    settings: () -> Unit,
    pickFile: () -> Unit,
    changed: () -> Unit
) {
    val context = LocalContext.current
    val orientation = orientationName(LocalConfiguration.current.orientation)
    val maxColumns = if (orientation == "landscape") 14 else 8
    val columns = p.getInt(
        settingKey("desktop_cols", orientation),
        p.getInt("desktop_cols", 4)
    ).coerceIn(2, maxColumns)
    val secondaryEnabled = p.getBoolean("secondary_page_enabled", false)
    var page by remember { mutableStateOf("main") }
    if (!secondaryEnabled) page = "main"
    val suffix = if (page == "secondary") "secondary" else "main"
    val filePreferenceKey = "desktop_files_" + suffix
    val linkPreferenceKey = "desktop_links_" + suffix
    val files = p.getStringSet(filePreferenceKey, emptySet()).orEmpty().toList()
    val links = p.getStringSet(linkPreferenceKey, emptySet()).orEmpty().toList()
    val weatherPackage = p.getStringSet("weather_app", emptySet()).orEmpty().firstOrNull()
    val showWeather = p.getBoolean("show_weather", true)

    val shortcuts = buildList {
        files.forEach { entry ->
            val parts = entry.split("|", limit = 2)
            val target = parts[0]
            add(
                DesktopShortcut(
                    desktopShortcutId(DesktopShortcutKind.FILE, target),
                    DesktopShortcutKind.FILE,
                    target,
                    parts.getOrElse(1) { "File" },
                    filePreferenceKey,
                    entry
                )
            )
        }
        links.forEach { entry ->
            val parts = entry.split("|", limit = 2)
            val target = parts[0]
            add(
                DesktopShortcut(
                    desktopShortcutId(DesktopShortcutKind.WEBSITE, target),
                    DesktopShortcutKind.WEBSITE,
                    target,
                    parts.getOrElse(1) { "Website" },
                    linkPreferenceKey,
                    entry
                )
            )
        }
        if (page == "main" && showWeather && weatherPackage != null) {
            add(
                DesktopShortcut(
                    desktopShortcutId(DesktopShortcutKind.WEATHER, weatherPackage),
                    DesktopShortcutKind.WEATHER,
                    weatherPackage,
                    "Weather",
                    null,
                    weatherPackage
                )
            )
        }
    }

    val itemIds = shortcuts.map { it.id }
    val positionKey = desktopPositionKey(suffix, orientation)
    val desktopIdentity = positionKey + "|" + itemIds.joinToString(",")
    var positions by remember(desktopIdentity) {
        mutableStateOf(
            normalizeDesktopPositions(itemIds, readDesktopPositions(p, positionKey))
        )
    }
    LaunchedEffect(desktopIdentity) {
        saveDesktopPositions(p, positionKey, positions)
    }

    var addLink by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }
    var label by remember { mutableStateOf("") }
    var manage by remember { mutableStateOf<Pair<String, String>?>(null) }
    var movingId by remember { mutableStateOf<String?>(null) }
    var dragSourceSlot by remember { mutableStateOf<Int?>(null) }
    var dropTargetSlot by remember { mutableStateOf<Int?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    val gridState = rememberLazyGridState()

    LaunchedEffect(page, orientation) {
        movingId = null
        dragSourceSlot = null
        dropTargetSlot = null
        dragOffset = Offset.Zero
    }

    fun commitMove(id: String, targetSlot: Int) {
        val updated = moveDesktopItem(positions, id, targetSlot)
        if (updated != positions) {
            positions = updated
            saveDesktopPositions(p, positionKey, updated)
        }
    }

    fun openShortcut(shortcut: DesktopShortcut) {
        when (shortcut.kind) {
            DesktopShortcutKind.FILE -> runCatching {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse(shortcut.target))
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            }
            DesktopShortcutKind.WEBSITE -> runCatching {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(shortcut.target)))
            }
            DesktopShortcutKind.WEATHER -> all.firstOrNull {
                it.packageName == shortcut.target
            }?.let { launch(context, it) }
        }
    }

    val showClock = p.getBoolean(
        settingKey("show_clock", orientation),
        p.getBoolean("show_clock", true)
    )
    val customText = p.getString(
        settingKey("custom_text", orientation),
        p.getString("custom_text", "")
    ).orEmpty()
    val clockVisible = showClock || customText.isNotBlank()
    val clockVertical = p.getString(
        settingKey("clock_vertical", orientation),
        "top"
    ) ?: "top"
    val clockHorizontal = p.getString(
        settingKey("clock_horizontal", orientation),
        "left"
    ) ?: "left"
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    if (showClock) {
        LaunchedEffect(Unit) {
            while (true) {
                now = System.currentTimeMillis()
                delay(1_000L - (now % 1_000L))
            }
        }
    }

    val systemViewConfiguration = LocalViewConfiguration.current
    val moveViewConfiguration = remember(systemViewConfiguration) {
        object : ViewConfiguration by systemViewConfiguration {
            override val longPressTimeoutMillis: Long = SHORTCUT_MOVE_HOLD_MILLIS
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        BoxWithConstraints(Modifier.weight(1f)) {
            val tileWidth = maxWidth / columns
            val visibleRows = ceil(
                maxHeight.value / tileWidth.value.coerceAtLeast(1f)
            ).toInt().coerceAtLeast(1)
            val highestUsedSlot = positions.values.maxOrNull() ?: -1
            val requiredSlots = maxOf(
                visibleRows * columns,
                highestUsedSlot + 1,
                shortcuts.size
            )
            val rows = ((requiredSlots + columns - 1) / columns)
                .coerceAtLeast(visibleRows) + 1
            val clockRow = when (clockVertical) {
                "center" -> visibleRows / 2
                "bottom" -> (visibleRows - 1).coerceAtLeast(0)
                else -> 0
            }
            val shortcutsBySlot = shortcuts.mapNotNull { shortcut ->
                positions[shortcut.id]?.let { slot -> slot to shortcut }
            }.toMap()

            CompositionLocalProvider(
                LocalViewConfiguration provides moveViewConfiguration
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    modifier = Modifier.fillMaxSize(),
                    state = gridState,
                    userScrollEnabled = dragSourceSlot == null
                ) {
                    for (row in 0 until rows) {
                        if (clockVisible && row == clockRow) {
                            item(
                                key = "desktop-clock",
                                span = { GridItemSpan(maxLineSpan) }
                            ) {
                                DesktopClockRow(
                                    p,
                                    orientation,
                                    now,
                                    showClock,
                                    customText,
                                    clockHorizontal,
                                    tileWidth
                                )
                            }
                        }
                        items(
                            count = columns,
                            key = { column -> "slot-" + (row * columns + column) }
                        ) { column ->
                            val slot = row * columns + column
                            val shortcut = shortcutsBySlot[slot]
                            val activelyDragging =
                                dragSourceSlot == slot && dragOffset != Offset.Zero
                            DesktopSlot(
                                shortcut = shortcut,
                                selected = shortcut?.id == movingId,
                                dropTarget = slot == dropTargetSlot &&
                                    dropTargetSlot != dragSourceSlot,
                                moveMode = movingId != null,
                                dragOffset = if (activelyDragging) dragOffset else Offset.Zero,
                                onActivate = {
                                    val selectedId = movingId
                                    if (selectedId != null) {
                                        if (selectedId == shortcut?.id) {
                                            movingId = null
                                        } else {
                                            commitMove(selectedId, slot)
                                            movingId = null
                                        }
                                        dragSourceSlot = null
                                        dropTargetSlot = null
                                        dragOffset = Offset.Zero
                                    } else if (shortcut != null) {
                                        openShortcut(shortcut)
                                    }
                                },
                                onDragStart = {
                                    if (shortcut != null) {
                                        movingId = shortcut.id
                                        dragSourceSlot = slot
                                        dropTargetSlot = slot
                                        dragOffset = Offset.Zero
                                    }
                                },
                                onDrag = { delta ->
                                    dragOffset += delta
                                    val sourceSlot = dragSourceSlot
                                    if (sourceSlot != null) {
                                        val sourceInfo =
                                            gridState.layoutInfo.visibleItemsInfo.firstOrNull {
                                                it.key == "slot-" + sourceSlot
                                            }
                                        if (sourceInfo != null) {
                                            val centerX = sourceInfo.offset.x +
                                                sourceInfo.size.width / 2f + dragOffset.x
                                            val centerY = sourceInfo.offset.y +
                                                sourceInfo.size.height / 2f + dragOffset.y
                                            val targetInfo =
                                                gridState.layoutInfo.visibleItemsInfo.firstOrNull {
                                                    val key = it.key as? String
                                                    key?.startsWith("slot-") == true &&
                                                        centerX >= it.offset.x &&
                                                        centerX < it.offset.x + it.size.width &&
                                                        centerY >= it.offset.y &&
                                                        centerY < it.offset.y + it.size.height
                                                }
                                            dropTargetSlot = (targetInfo?.key as? String)
                                                ?.removePrefix("slot-")
                                                ?.toIntOrNull()
                                        }
                                    }
                                },
                                onDragEnd = {
                                    val selectedId = movingId
                                    val sourceSlot = dragSourceSlot
                                    val targetSlot = dropTargetSlot
                                    if (
                                        selectedId != null &&
                                        sourceSlot != null &&
                                        targetSlot != null &&
                                        targetSlot != sourceSlot
                                    ) {
                                        commitMove(selectedId, targetSlot)
                                        movingId = null
                                    }
                                    dragSourceSlot = null
                                    dropTargetSlot = null
                                    dragOffset = Offset.Zero
                                },
                                onDragCancel = {
                                    dragSourceSlot = null
                                    dropTargetSlot = null
                                    dragOffset = Offset.Zero
                                }
                            )
                        }
                    }
                }
            }
        }

        shortcuts.firstOrNull { it.id == movingId }?.let { movingShortcut ->
            Surface(
                color = Aubergine.copy(alpha = .94f),
                shape = RoundedCornerShape(14.dp),
                tonalElevation = 5.dp
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Moving " + movingShortcut.label +
                            ". Drag it, or scroll and tap a destination.",
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall
                    )
                    movingShortcut.preferenceKey?.let { preferenceKey ->
                        TextButton(
                            onClick = {
                                manage = preferenceKey to movingShortcut.entry
                                movingId = null
                            }
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null)
                            Text("Manage")
                        }
                    }
                    IconButton(
                        onClick = {
                            movingId = null
                            dragSourceSlot = null
                            dropTargetSlot = null
                            dragOffset = Offset.Zero
                        }
                    ) {
                        Icon(Icons.Default.Close, "Finish moving", tint = Color.White)
                    }
                }
            }
        }

        if (secondaryEnabled) {
            Row {
                TextButton(
                    onClick = {
                        page = if (page == "main") "secondary" else "main"
                    }
                ) {
                    Text(if (page == "main") "Page 2" else "Main page")
                }
            }
        }
    }

    if (addLink) {
        AlertDialog(
            onDismissRequest = { addLink = false },
            title = {
                Text(
                    "Pin website to " +
                        if (page == "secondary") "Page 2" else "Main page"
                )
            },
            text = {
                Column {
                    OutlinedTextField(label, { label = it }, label = { Text("Name") })
                    OutlinedTextField(url, { url = it }, label = { Text("https://...") })
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (url.startsWith("http")) {
                            val key = "desktop_links_" + suffix
                            val set = p.getStringSet(key, emptySet())
                                .orEmpty()
                                .toMutableSet()
                            set.add(url + "|" + label.ifBlank { "Website" })
                            p.edit().putStringSet(key, set).apply()
                            changed()
                        }
                        addLink = false
                    }
                ) {
                    Text("Pin")
                }
            },
            dismissButton = {
                TextButton(onClick = { addLink = false }) { Text("Cancel") }
            }
        )
    }
    manage?.let { (key, entry) ->
        ShortcutManageDialog(
            p,
            key,
            entry,
            {
                manage = null
                changed()
            },
            { manage = null }
        )
    }
}

@Composable
private fun DesktopClockRow(
    p: android.content.SharedPreferences,
    orientation: String,
    now: Long,
    showClock: Boolean,
    customText: String,
    horizontal: String,
    minimumHeight: androidx.compose.ui.unit.Dp
) {
    val textAlignment = when (horizontal) {
        "center" -> Alignment.CenterHorizontally
        "right" -> Alignment.End
        else -> Alignment.Start
    }
    val rowAlignment = when (horizontal) {
        "center" -> Alignment.Center
        "right" -> Alignment.CenterEnd
        else -> Alignment.CenterStart
    }
    val clockSize = p.getInt(
        settingKey("clock_size", orientation),
        p.getInt("clock_size", 22)
    ).sp
    val clockColor = runCatching {
        Color(
            android.graphics.Color.parseColor(
                p.getString(
                    settingKey("clock_color", orientation),
                    p.getString("clock_color", "#FFFFFF")
                )
            )
        )
    }.getOrDefault(Color.White)
    val clockFont = when (
        p.getString(
            settingKey("clock_font", orientation),
            p.getString("clock_font", "sans")
        )
    ) {
        "serif" -> FontFamily.Serif
        "mono" -> FontFamily.Monospace
        "cursive" -> FontFamily.Cursive
        else -> FontFamily.SansSerif
    }
    val rowHeight = if (minimumHeight < 56.dp) 56.dp else minimumHeight
    Box(Modifier.fillMaxWidth().heightIn(min = rowHeight).padding(4.dp)) {
        Column(
            Modifier.align(rowAlignment)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black.copy(alpha = .32f))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = textAlignment
        ) {
            if (showClock) {
                Text(
                    SimpleDateFormat("EEE, MMM d   HH:mm", Locale.getDefault())
                        .format(Date(now)),
                    color = clockColor,
                    fontSize = clockSize,
                    fontFamily = clockFont
                )
            }
            if (customText.isNotBlank()) {
                Text(customText, color = Color.White.copy(alpha = .9f))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DesktopSlot(
    shortcut: DesktopShortcut?,
    selected: Boolean,
    dropTarget: Boolean,
    moveMode: Boolean,
    dragOffset: Offset,
    onActivate: () -> Unit,
    onDragStart: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit
) {
    val activelyDragging = dragOffset != Offset.Zero
    var modifier = Modifier
        .padding(4.dp)
        .aspectRatio(1f)
        .zIndex(if (activelyDragging) 5f else 0f)
        .graphicsLayer {
            translationX = dragOffset.x
            translationY = dragOffset.y
            if (activelyDragging) {
                scaleX = 1.06f
                scaleY = 1.06f
                shadowElevation = 10f
            }
        }
        .clickable(
            enabled = shortcut != null || moveMode,
            onClick = onActivate
        )

    if (shortcut != null) {
        modifier = modifier.pointerInput(shortcut.id) {
            detectDragGesturesAfterLongPress(
                onDragStart = { onDragStart() },
                onDragEnd = onDragEnd,
                onDragCancel = onDragCancel,
                onDrag = { change, amount ->
                    change.consume()
                    onDrag(amount)
                }
            )
        }
    }

    Box(modifier) {
        if (shortcut == null) {
            if (moveMode) {
                Box(
                    Modifier.fillMaxSize()
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            1.dp,
                            Orange.copy(alpha = .35f),
                            RoundedCornerShape(14.dp)
                        )
                )
            }
        } else {
            when (shortcut.kind) {
                DesktopShortcutKind.FILE -> FileShortcutTile(
                    Uri.parse(shortcut.target),
                    shortcut.label,
                    Modifier.fillMaxSize()
                )
                DesktopShortcutKind.WEBSITE -> WebsiteShortcutTile(
                    shortcut.target,
                    shortcut.label,
                    Modifier.fillMaxSize()
                )
                DesktopShortcutKind.WEATHER -> ShortcutTile(
                    Icons.Default.Cloud,
                    shortcut.label,
                    Modifier.fillMaxSize()
                )
            }
            if (selected || dropTarget) {
                Box(
                    Modifier.fillMaxSize()
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            width = if (dropTarget) 3.dp else 2.dp,
                            color = if (dropTarget) Color.White else Orange,
                            shape = RoundedCornerShape(14.dp)
                        )
                )
            }
        }
    }
}

@Composable fun ShortcutManageDialog(p:android.content.SharedPreferences,key:String,entry:String,done:()->Unit,cancel:()->Unit){val parts=entry.split("|",limit=2);var name by remember(entry){mutableStateOf(parts.getOrElse(1){"Shortcut"})};AlertDialog(onDismissRequest=cancel,title={Text("Manage shortcut")},text={OutlinedTextField(name,{name=it},label={Text("Name")})},confirmButton={Row{TextButton({val set=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.remove(entry);set.add("${parts[0]}|${name.ifBlank{"Shortcut"}}");p.edit().putStringSet(key,set).apply();done()}){Text("Rename")};TextButton({val set=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();set.remove(entry);p.edit().putStringSet(key,set).apply();done()}){Text("Remove",color=MaterialTheme.colorScheme.error)}}},dismissButton={TextButton(cancel){Text("Cancel")}})}
@Composable
fun FileShortcutTile(
    uri: Uri,
    label: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var preview by remember(uri) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(uri) {
        preview = withContext(Dispatchers.IO) {
            runCatching { decodeSampledImage(context, uri, 512, 512) }.getOrNull()
        }
    }
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = .38f))
    ) {
        if (preview != null) {
            Image(
                preview!!,
                label,
                Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Icon(
                Icons.Default.Description,
                contentDescription = "File",
                tint = Color.White,
                modifier = Modifier.align(Alignment.Center).fillMaxSize(.46f)
            )
        }
        Box(
            Modifier.fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = .62f))
                .padding(5.dp)
        ) {
            Text(label, color = Color.White, maxLines = 2)
        }
    }
}

@Composable
fun WebsiteShortcutTile(
    url: String,
    label: String,
    modifier: Modifier = Modifier
) {
    val applicationContext = LocalContext.current.applicationContext
    var favicon by remember(url) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(url) {
        favicon = withContext(Dispatchers.IO) {
            FaviconLoader.load(applicationContext, url)
        }?.asImageBitmap()
    }
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = .30f))
    ) {
        if (favicon != null) {
            Image(
                favicon!!,
                label,
                Modifier.align(Alignment.Center).fillMaxSize(.66f),
                contentScale = ContentScale.Fit
            )
        } else {
            Icon(
                Icons.Default.Language,
                contentDescription = "Website",
                tint = Color.White,
                modifier = Modifier.align(Alignment.Center).fillMaxSize(.46f)
            )
        }
        Box(
            Modifier.fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = .62f))
                .padding(5.dp)
        ) {
            Text(label, color = Color.White, maxLines = 2)
        }
    }
}

@Composable
fun ShortcutTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = .30f))
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = Color.White,
            modifier = Modifier.align(Alignment.Center).fillMaxSize(.46f)
        )
        Box(
            Modifier.fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = .62f))
                .padding(5.dp)
        ) {
            Text(label, color = Color.White, maxLines = 2)
        }
    }
}

@Composable fun AppIcon(a:AppItem,pixels:Int,modifier:Modifier=Modifier){val image=remember(a.packageName,a.activityName,a.icon){a.icon.toBitmap(pixels,pixels).asImageBitmap()};Image(image,a.label,modifier)}
@OptIn(ExperimentalFoundationApi::class) @Composable fun AppTile(a:AppItem,onClick:()->Unit,onLong:(()->Unit)?=null){Column(Modifier.padding(7.dp).clip(RoundedCornerShape(12.dp)).combinedClickable(onClick=onClick,onLongClick=onLong).padding(7.dp),horizontalAlignment=Alignment.CenterHorizontally){AppIcon(a,96,Modifier.size(48.dp));Text(a.label,color=Color.White,maxLines=1,style=MaterialTheme.typography.labelMedium)}}
fun toggleSet(p:android.content.SharedPreferences,key:String,value:String){val s=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();if(!s.add(value))s.remove(value);p.edit().putStringSet(key,s).apply()}

@Composable fun Taskbar(all:List<AppItem>,p:android.content.SharedPreferences,drawer:()->Unit,changed:()->Unit,vertical:Boolean,auto:Boolean,toggle:()->Unit){
 val c=LocalContext.current;val size=p.getInt("taskbar_size",64).coerceIn(44,110).dp;val pins=p.getStringSet("pins",emptySet()).orEmpty().mapNotNull{x->all.firstOrNull{a->a.packageName==x}};val mod=if(vertical)Modifier.width(size).fillMaxHeight() else Modifier.height(size).fillMaxWidth();Surface(mod,color=Color.Black.copy(alpha=.48f)){if(vertical)LazyColumn(horizontalAlignment=Alignment.CenterHorizontally){item{IconButton(drawer){Icon(Icons.Default.Apps,"Apps",tint=Color.White)}};items(pins,key={it.packageName}){a->AppIcon(a,72,Modifier.padding(5.dp).size(36.dp).clickable{launch(c,a)})};if(auto)item{IconButton(toggle){Icon(Icons.Default.UnfoldLess,"Auto hide",tint=Color.White)}}}else LazyRow(verticalAlignment=Alignment.CenterVertically){item{IconButton(drawer){Icon(Icons.Default.Apps,"Apps",tint=Color.White)}};items(pins,key={it.packageName}){a->AppIcon(a,72,Modifier.padding(horizontal=7.dp).size(36.dp).clickable{launch(c,a)})};if(auto)item{IconButton(toggle){Icon(Icons.Default.UnfoldLess,"Auto hide",tint=Color.White)}}}}}

val settingItems=listOf(SettingItem("Wi-Fi","Networks and Internet",Settings.ACTION_WIFI_SETTINGS),SettingItem("Bluetooth","Connected devices",Settings.ACTION_BLUETOOTH_SETTINGS),SettingItem("Display","Brightness and display",Settings.ACTION_DISPLAY_SETTINGS),SettingItem("Sound","Volume and sound",Settings.ACTION_SOUND_SETTINGS),SettingItem("Storage","Device storage",Settings.ACTION_INTERNAL_STORAGE_SETTINGS),SettingItem("Accessibility","Accessibility",Settings.ACTION_ACCESSIBILITY_SETTINGS),SettingItem("System settings","All Android settings",Settings.ACTION_SETTINGS))
@Composable
fun AppDrawer(
    apps: List<AppItem>,
    q: String,
    setQ: (String) -> Unit,
    close: () -> Unit,
    settings: () -> Unit,
    p: android.content.SharedPreferences,
    changed: () -> Unit
) {
    val context = LocalContext.current
    val grid = p.getBoolean("app_grid", true)
    val results = remember(apps, q) { apps.filter {
        it.label.contains(q, ignoreCase = true) ||
            it.packageName.contains(q, ignoreCase = true)
    } }
    Surface(modifier = Modifier.fillMaxSize(), color = Aubergine.copy(alpha = .98f)) {
        Column(
            modifier = Modifier.statusBarsPadding().navigationBarsPadding().padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = settings) {
                    Icon(Icons.Default.Settings, contentDescription = "Launcher settings", tint = Color.White)
                }
                OutlinedTextField(
                    value = q,
                    onValueChange = setQ,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("Search apps and settings") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
                )
                IconButton(onClick = close) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }
            if (q.isNotBlank()) {
                settingItems.filter {
                    it.label.contains(q, ignoreCase = true) ||
                        it.subtitle.contains(q, ignoreCase = true)
                }.forEach { setting ->
                    ListItem(
                        headlineContent = { Text(setting.label) },
                        supportingContent = { Text(setting.subtitle) },
                        modifier = Modifier.clickable { openSetting(context, setting.action) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            if (grid) {
                LazyVerticalGrid(columns = GridCells.Adaptive(90.dp)) {
                    items(results, key = { it.packageName + it.activityName }) { app ->
                        AppTile(
                            app,
                            onClick = { launch(context, app) },
                            onLong = { toggleSet(p, "pins", app.packageName); changed() }
                        )
                    }
                }
            } else {
                LazyColumn {
                    items(results, key = { it.packageName + it.activityName }) { app ->
                        ListItem(
                            headlineContent = { Text(app.label) },
                            supportingContent = { Text(app.packageName) },
                            leadingContent = { AppIcon(app, 64, Modifier.size(38.dp)) },
                            modifier = Modifier.clickable { launch(context, app) }
                        )
                    }
                }
            }
        }
    }
}

@Composable fun LauncherSettings(apps:List<AppItem>,p:android.content.SharedPreferences,close:()->Unit,changed:()->Unit,pickPhotos:(Boolean,String)->Unit,pickFile:()->Unit,exportBackup:()->Unit,importBackup:()->Unit){val c=LocalContext.current;var page by remember{mutableStateOf("main")};var tick by remember{mutableIntStateOf(0)};var addWebsite by remember{mutableStateOf(false)};var websiteUrl by remember{mutableStateOf("")};var websiteLabel by remember{mutableStateOf("")};fun ch(){tick++;changed()};Surface(Modifier.fillMaxSize(),color=Warm){Column(Modifier.statusBarsPadding().navigationBarsPadding()){Row(Modifier.fillMaxWidth().background(Aubergine).padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton({if(page=="main")close()else page="main"}){Icon(Icons.AutoMirrored.Filled.ArrowBack,"Back",tint=Color.White)};Text(pageTitle(page),color=Color.White,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)};when(page){
"hidden"->AppSelector(apps,p,"hidden",true){ch()};"dumbapps"->AppSelector(apps,p,"dumb",false){ch()};"taskbarapps"->AppSelector(apps,p,"pins",false){ch()};"weather"->WeatherSettings(apps,p){ch()};"appearance"->LazyColumn{item{SettingRow(Icons.Default.PhoneAndroid,"Portrait orientation","Configure portrait wallpapers, clock and desktop layout"){page="portrait"}};item{SettingRow(Icons.Default.DesktopWindows,"Landscape orientation","Configure landscape wallpapers, clock and desktop layout"){page="landscape"}}};"portrait"->AppearanceSettings(p,"portrait",pickPhotos){ch()};"landscape"->AppearanceSettings(p,"landscape",pickPhotos){ch()};"taskbar"->TaskbarSettings(p){ch()};"apps"->AppsSettings(p){ch()};"lock"->LockSettings(p){ch()};"licenses"->LicenseScreen();"about"->AboutScreen();
"desktop"->LazyColumn{item{SettingRow(Icons.Default.Description,"Pin file","Choose a file for the selected shortcut destination"){pickFile()}};item{SettingRow(Icons.Default.AddLink,"Add website","Create a website shortcut on the selected desktop page"){addWebsite=true}};item{SettingRow(Icons.AutoMirrored.Filled.ViewSidebar,"Taskbar","Position, size, hide, auto-hide and delay"){page="taskbar"}};item{SettingRow(Icons.Default.PushPin,"Taskbar pinned apps","Choose any number of apps for the scrollable taskbar"){page="taskbarapps"}};item{val second=p.getBoolean("secondary_page_enabled",false);SettingRow(Icons.Default.Layers,"Secondary desktop page","Optional second page for file and website shortcuts",second){p.edit().putBoolean("secondary_page_enabled",!second).apply();ch()}};item{val target=p.getString("shortcut_target_page","main")?:"main";SettingRow(Icons.Default.AddLink,"Shared shortcut destination","New shared files/links go to ${if(target=="secondary")"Page 2" else "Main page"}"){p.edit().putString("shortcut_target_page",if(target=="main")"secondary" else "main").apply();ch()}};item{SettingRow(Icons.Default.Cloud,"Weather app","Choose the app opened by the weather shortcut"){page="weather"}};item{val sw=p.getBoolean("swipe_actions",false);SettingRow(Icons.Default.Swipe,"Swipe actions","Swipe right for Applications; swipe left for Settings",sw){p.edit().putBoolean("swipe_actions",!sw).apply();ch()}}};
"dumbsettings"->LazyColumn{item{val d=p.getBoolean("dumb_mode",false);SettingRow(Icons.Default.PhoneAndroid,"Dumb Phone Mode",if(d)"Enabled" else "Disabled",d){p.edit().putBoolean("dumb_mode",!d).apply();ch()}};item{SettingRow(Icons.Default.Checklist,"Choose Dumb Phone apps","Manage accessible apps"){page="dumbapps"}};item{val f=p.getBoolean("dumb_notification_filter",false);SettingRow(Icons.Default.NotificationsOff,"Notification filter","Block notifications from apps outside the Dumb Phone allowlist",f){p.edit().putBoolean("dumb_notification_filter",!f).apply();ch()}};item{SettingRow(Icons.Default.Notifications,"Notification access","Required for Dumb Phone notification filtering"){openSetting(c,Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)}}};
else->LazyColumn{item{SettingRow(Icons.Default.Home,"Make default Home","Set Ubuntu Launcher as Android Home"){(c as? MainActivity)?.requestHome()}};item{SettingRow(Icons.Default.Wallpaper,"Display settings","Wallpaper, clock/date, colors, fonts and desktop appearance"){page="appearance"}};item{SettingRow(Icons.Default.DesktopWindows,"Desktop settings","Taskbar, pinned apps, secondary page, shared shortcuts and weather"){page="desktop"}};item{SettingRow(Icons.Default.PhoneAndroid,"Dumb Phone Settings","Mode, app allowlist and notification management"){page="dumbsettings"}};item{SettingRow(Icons.Default.Apps,"Applications list","Grid/list presentation"){page="apps"}};item{SettingRow(Icons.Default.Lock,"Ubuntu-style lock layer","PIN/password and lock-screen appearance"){page="lock"}};item{SettingRow(Icons.Default.VisibilityOff,"Hidden apps","Only accessible through launcher settings"){page="hidden"}};item{SettingRow(Icons.Default.Save,"Launcher backup","Download a complete launcher settings backup"){exportBackup()}};item{SettingRow(Icons.Default.Restore,"Restore launcher backup","Upload a launcher backup and restore settings"){importBackup()}};item{SettingRow(Icons.Default.Settings,"Android Settings","Open system settings"){openSetting(c,Settings.ACTION_SETTINGS)}};item{SettingRow(Icons.Default.Description,"Licenses","GNU AGPLv3"){page="licenses"}};item{SettingRow(Icons.Default.Info,"About","Version and developer information"){page="about"}}}}}
 if(addWebsite)AlertDialog(onDismissRequest={addWebsite=false},title={Text("Add website")},text={Column{OutlinedTextField(websiteLabel,{websiteLabel=it},label={Text("Name")});OutlinedTextField(websiteUrl,{websiteUrl=it},label={Text("Website URL")})}},confirmButton={TextButton({val normalized=if(websiteUrl.startsWith("https://")||websiteUrl.startsWith("http://"))websiteUrl else "https://$websiteUrl";val uri=runCatching{Uri.parse(normalized)}.getOrNull();if(uri?.host!=null){val target=if(p.getString("shortcut_target_page","main")=="secondary" && p.getBoolean("secondary_page_enabled",false))"secondary" else "main";val key="desktop_links_$target";val links=p.getStringSet(key,emptySet()).orEmpty().toMutableSet();links.add("$normalized|${websiteLabel.ifBlank{uri.host?:"Website"}}");p.edit().putStringSet(key,links).apply();ch()};addWebsite=false;websiteUrl="";websiteLabel=""}){Text("Add")}},dismissButton={TextButton({addWebsite=false}){Text("Cancel")}})
 }}

fun pageTitle(p:String)=when(p){"hidden"->"Hidden applications";"dumbapps"->"Dumb Phone applications";"taskbarapps"->"Taskbar pinned applications";"weather"->"Weather";"appearance"->"Display settings";"portrait"->"Portrait orientation";"landscape"->"Landscape orientation";"desktop"->"Desktop settings";"dumbsettings"->"Dumb Phone Settings";"taskbar"->"Taskbar";"apps"->"Applications list";"lock"->"Lock screen";"licenses"->"Licenses";"about"->"About";else->"Ubuntu Launcher Settings"}

@Composable fun SettingRow(icon:androidx.compose.ui.graphics.vector.ImageVector,title:String,sub:String,switch:Boolean?=null,click:()->Unit){Row(Modifier.fillMaxWidth().clickable(onClick=click).padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Orange);Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.SemiBold);Text(sub,color=Color.Gray,style=MaterialTheme.typography.bodySmall)};if(switch!=null)Switch(switch,{click()})}}

fun orientationName(orientation:Int):String=if(orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE)"landscape" else "portrait"
fun wallKey(p:android.content.SharedPreferences,dumb:Boolean,orientation:String):String {
 val base=if(dumb)"wall_dumb" else "wall_regular"
 return "${base}_${orientation}"
}
fun settingKey(base:String,orientation:String)="${base}_${orientation}"
fun scaleFor(name:String):ContentScale=when(name){"fit"->ContentScale.Fit;"fill"->ContentScale.FillBounds;"zoom"->ContentScale.FillHeight;else->ContentScale.Crop}
@Composable fun AppearanceSettings(p:android.content.SharedPreferences,orientation:String,pick:(Boolean,String)->Unit,changed:()->Unit){
 val key:(String)->String={settingKey(it,orientation)}
 val maxColumns=if(orientation=="landscape")14 else 8
 var cols by remember(orientation){mutableIntStateOf(p.getInt(key("desktop_cols"),p.getInt("desktop_cols",4)).coerceIn(2,maxColumns))}
 var clock by remember(orientation){mutableStateOf(p.getBoolean(key("show_clock"),p.getBoolean("show_clock",true)))}
 var clockSize by remember(orientation){mutableIntStateOf(p.getInt(key("clock_size"),p.getInt("clock_size",22)))}
 var clockColor by remember(orientation){mutableStateOf(p.getString(key("clock_color"),p.getString("clock_color","#FFFFFF"))?:"#FFFFFF")}
 var clockFont by remember(orientation){mutableStateOf(p.getString(key("clock_font"),p.getString("clock_font","sans"))?:"sans")}
 var clockVertical by remember(orientation){mutableStateOf(p.getString(key("clock_vertical"),"top")?:"top")}
 var clockHorizontal by remember(orientation){mutableStateOf(p.getString(key("clock_horizontal"),"left")?:"left")}
 var custom by remember(orientation){mutableStateOf(p.getString(key("custom_text"),p.getString("custom_text",""))?:"")}
 LazyColumn {
  listOf(false,true).forEach{dumb->
   item {
    val label=if(dumb)"Dumb Phone" else "Regular launcher"
    val base=if(dumb)"wall_dumb" else "wall_regular"
    val wkey=wallKey(p,dumb,orientation)
    Text("$label wallpaper",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)
    Row(Modifier.padding(horizontal=16.dp)){
     Button({pick(dumb,orientation)}){Text("Choose photos")}
     Spacer(Modifier.width(8.dp))
     OutlinedButton({p.edit().remove(wkey).apply();changed()}){Text("Remove wallpaper")}
    }
    var mode by remember(orientation,dumb){mutableStateOf(p.getString(key("${base}_scale"),"crop")?:"crop")}
    Text("Image scaling",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)
    Row(Modifier.padding(horizontal=8.dp)){
     listOf("crop","fill","fit","zoom").forEach{option->
      FilterChip(mode==option,{mode=option;p.edit().putString(key("${base}_scale"),option).apply();changed()},label={Text(option.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(2.dp))
     }
    }
   }
  }
  item{Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("Show clock and date",Modifier.weight(1f));Switch(clock,{clock=it;p.edit().putBoolean(key("show_clock"),it).apply();changed()})}}
  item{Text("Clock/date size: $clockSize sp",Modifier.padding(16.dp));Slider(clockSize.toFloat(),{clockSize=it.toInt();p.edit().putInt(key("clock_size"),clockSize).apply();changed()},valueRange=12f..64f,modifier=Modifier.padding(horizontal=16.dp))}
  item{OutlinedTextField(clockColor,{clockColor=it;p.edit().putString(key("clock_color"),it).apply();changed()},label={Text("Clock/date color (#RRGGBB)")},modifier=Modifier.fillMaxWidth().padding(16.dp))}
  item{Text("Clock/date font",Modifier.padding(horizontal=16.dp),fontWeight=FontWeight.Bold);Row(Modifier.padding(12.dp)){listOf("sans","serif","mono","cursive").forEach{x->FilterChip(clockFont==x,{clockFont=x;p.edit().putString(key("clock_font"),x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(3.dp))}}}
  item{
   Text("Clock placement",Modifier.padding(start=16.dp,top=16.dp,bottom=6.dp),fontWeight=FontWeight.Bold)
   Text("Vertical",Modifier.padding(horizontal=16.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
   Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){listOf("top","center","bottom").forEach{x->FilterChip(clockVertical==x,{clockVertical=x;p.edit().putString(key("clock_vertical"),x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.weight(1f).padding(3.dp))}}
   Text("Horizontal",Modifier.padding(start=16.dp,top=8.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)
   Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){listOf("left","center","right").forEach{x->FilterChip(clockHorizontal==x,{clockHorizontal=x;p.edit().putString(key("clock_horizontal"),x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.weight(1f).padding(3.dp))}}
  }
  item{Text("Desktop columns: $cols",Modifier.padding(16.dp));Slider(cols.toFloat(),{cols=it.toInt().coerceIn(2,maxColumns);p.edit().putInt(key("desktop_cols"),cols).apply();changed()},valueRange=2f..maxColumns.toFloat(),steps=maxColumns-3,modifier=Modifier.padding(horizontal=16.dp));Text("Shortcuts use unlimited scrollable rows. Hold a file or website for 3 seconds to move it.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray,style=MaterialTheme.typography.bodySmall)}
  item{OutlinedTextField(custom,{custom=it;p.edit().putString(key("custom_text"),it).apply();changed()},label={Text("Desktop custom text")},modifier=Modifier.fillMaxWidth().padding(16.dp))}
  item{Text("Border design",Modifier.padding(16.dp),fontWeight=FontWeight.Bold);var border by remember(orientation){mutableStateOf(p.getString(key("border_style"),p.getString("border_style","rounded"))?:"rounded")};Row(Modifier.padding(horizontal=12.dp)){listOf("none","rounded","ubuntu").forEach{x->FilterChip(border==x,{border=x;p.edit().putString(key("border_style"),x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(3.dp))}}}
 }
}

@Composable fun TaskbarSettings(p:android.content.SharedPreferences,changed:()->Unit){var pos by remember{mutableStateOf(p.getString("taskbar_pos","bottom")?:"bottom")};var size by remember{mutableIntStateOf(p.getInt("taskbar_size",64))};var hide by remember{mutableStateOf(p.getBoolean("taskbar_hide",false))};var auto by remember{mutableStateOf(p.getBoolean("taskbar_auto",false))};var seconds by remember{mutableStateOf(p.getInt("taskbar_auto_seconds",3).toString())};LazyColumn{item{Text("Position",Modifier.padding(16.dp),fontWeight=FontWeight.Bold);Row(Modifier.padding(horizontal=12.dp)){listOf("left","right","top","bottom").forEach{x->FilterChip(pos==x,{pos=x;p.edit().putString("taskbar_pos",x).apply();changed()},{Text(x.replaceFirstChar{it.uppercase()})},modifier=Modifier.padding(3.dp))}}};item{Text("Size: $size dp",Modifier.padding(16.dp));Slider(size.toFloat(),{size=it.toInt();p.edit().putInt("taskbar_size",size).apply();changed()},valueRange=44f..110f,modifier=Modifier.padding(horizontal=16.dp))};item{SettingRow(Icons.Default.VisibilityOff,"Hide taskbar","Never show the taskbar",hide){hide=!hide;p.edit().putBoolean("taskbar_hide",hide).apply();changed()}};item{SettingRow(Icons.Default.UnfoldLess,"Auto hide","Hide the taskbar after the configured delay",auto){auto=!auto;p.edit().putBoolean("taskbar_auto",auto).apply();changed()}};if(auto)item{OutlinedTextField(seconds,{v->if(v.all{it.isDigit()}&&v.length<=5){seconds=v;v.toIntOrNull()?.coerceAtLeast(1)?.let{p.edit().putInt("taskbar_auto_seconds",it).apply();changed()}}},label={Text("Auto-hide duration (seconds)")},singleLine=true,modifier=Modifier.fillMaxWidth().padding(16.dp));Text("A small orange dot remains at the taskbar edge. Tap it to reveal the hidden taskbar.",Modifier.padding(horizontal=16.dp,vertical=4.dp),color=Color.Gray)}}}
@Composable fun AppsSettings(p:android.content.SharedPreferences,changed:()->Unit){val grid=p.getBoolean("app_grid",true);Column{SettingRow(Icons.Default.GridView,"Grid view","Show apps as icons in a grid",grid){p.edit().putBoolean("app_grid",true).apply();changed()};SettingRow(Icons.AutoMirrored.Filled.ViewList,"List view","Show apps in a detailed list",!grid){p.edit().putBoolean("app_grid",false).apply();changed()}}}
@Composable fun LockSettings(p:android.content.SharedPreferences,changed:()->Unit){
 var hasCredential by remember{mutableStateOf(p.getString("lock_hash","").orEmpty().isNotBlank())}
 var enabled by remember{mutableStateOf(p.getBoolean("lock_enabled",false)&&hasCredential)}
 var pass by remember{mutableStateOf("")}
 var message by remember{mutableStateOf<String?>(if(p.getBoolean("lock_enabled",false)&&!hasCredential)"Save a PIN or password before enabling the lock." else null)}
 Column(Modifier.padding(16.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){
   Text("Enable launcher lock layer",Modifier.weight(1f))
   Switch(enabled,{requested->
    if(requested&&!hasCredential)message="Save a PIN or password first."
    else{enabled=requested;message=if(requested)"Lock enabled. The lock screen is now active." else "Lock disabled.";p.edit().putBoolean("lock_enabled",requested).putLong("lock_request",System.currentTimeMillis()).apply();changed()}
   })
  }
  OutlinedTextField(pass,{pass=it;message=null},label={Text("New PIN or password")},singleLine=true,visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Password),modifier=Modifier.fillMaxWidth())
  Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){
   Button({
    if(pass.length<4)message="Use at least 4 characters."
    else{p.edit().putString("lock_hash",hash(pass)).putLong("lock_request",System.currentTimeMillis()).apply();pass="";hasCredential=true;message=if(enabled)"PIN/password saved. Lock screen activated." else "PIN/password saved. Turn on the lock when ready.";changed()}
   }){Text("Save PIN/password")}
   if(enabled&&hasCredential){Spacer(Modifier.width(8.dp));OutlinedButton({p.edit().putLong("lock_request",System.currentTimeMillis()).apply();changed()}){Text("Lock now")}}
  }
  message?.let{Text(it,Modifier.padding(top=10.dp),color=if(it.contains("first")||it.contains("least"))MaterialTheme.colorScheme.error else Color.DarkGray)}
  Text("When enabled, the launcher locks immediately and re-locks whenever it leaves the foreground. Android's system keyguard remains the authoritative device lock; this layer protects the launcher UI but does not replace Android secure lock-screen enforcement.",Modifier.padding(top=18.dp),color=Color.Gray)
 }
}
@Composable fun LockOverlay(p:android.content.SharedPreferences,unlock:()->Unit){
 BackHandler(enabled=true){}
 var v by remember{mutableStateOf("")};var error by remember{mutableStateOf<String?>(null)};var now by remember{mutableLongStateOf(System.currentTimeMillis())}
 fun submit(){if(hash(v)==p.getString("lock_hash","")){error=null;v="";unlock()}else error="Incorrect PIN or password."}
 LaunchedEffect(Unit){while(true){now=System.currentTimeMillis();delay(1000L-(now%1000L))}}
 Surface(Modifier.fillMaxSize(),color=Aubergine){
  Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
   Icon(Icons.Default.Lock,"Launcher locked",tint=Orange,modifier=Modifier.size(72.dp))
   Text(SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date(now)),color=Color.White,style=MaterialTheme.typography.displayMedium)
   Text(DateFormat.getDateInstance().format(Date(now)),color=Color.White)
   OutlinedTextField(v,{v=it;error=null},label={Text("PIN or password")},singleLine=true,isError=error!=null,visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Password,imeAction=ImeAction.Done),keyboardActions=KeyboardActions(onDone={submit()}),modifier=Modifier.padding(top=24.dp))
   error?.let{Text(it,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(top=8.dp))}
   Button({submit()},Modifier.padding(top=12.dp),enabled=v.isNotBlank()){Text("Unlock")}
  }
 }
}

@Composable fun WeatherSettings(apps:List<AppItem>,p:android.content.SharedPreferences,changed:()->Unit){
 var show by remember{mutableStateOf(p.getBoolean("show_weather",true))}
 Column{
  SettingRow(Icons.Default.Cloud,"Show weather emblem","Show or hide the selected weather app emblem on the main desktop",show){show=!show;p.edit().putBoolean("show_weather",show).apply();changed()}
  Text("Weather application",Modifier.padding(start=16.dp,top=14.dp,bottom=6.dp),fontWeight=FontWeight.Bold)
  Box(Modifier.weight(1f)){AppSelector(apps,p,"weather_app",false,single=true,changed=changed)}
 }
}
@Composable fun AppSelector(apps:List<AppItem>,p:android.content.SharedPreferences,key:String,launchable:Boolean,single:Boolean=false,changed:()->Unit){val c=LocalContext.current;var selected by remember{mutableStateOf(p.getStringSet(key,emptySet()).orEmpty())};LazyColumn{items(apps,key={it.packageName+it.activityName}){a->Row(Modifier.fillMaxWidth().clickable{val s=if(single)mutableSetOf<String>() else selected.toMutableSet();if(single)s.add(a.packageName) else if(!s.add(a.packageName))s.remove(a.packageName);selected=s;p.edit().putStringSet(key,s).apply();changed()}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){AppIcon(a,64,Modifier.size(38.dp));Spacer(Modifier.width(12.dp));Text(a.label,Modifier.weight(1f));if(launchable)IconButton({launch(c,a)}){Icon(Icons.AutoMirrored.Filled.OpenInNew,"Open")};Checkbox(a.packageName in selected,null)}}}}
@Composable fun LicenseScreen(){val c=LocalContext.current;val t=remember{runCatching{c.resources.openRawResource(R.raw.agpl_3_0).bufferedReader().use{it.readText()}}.getOrElse{"Unable to load license."}};LazyColumn(Modifier.padding(18.dp)){item{Text("GNU Affero General Public License",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge,color=Aubergine);Text("Version 3, 19 November 2007",color=Color.Gray);Spacer(Modifier.height(16.dp));Text(t,style=MaterialTheme.typography.bodySmall)}}}
@Composable fun AboutScreen(){Column(Modifier.padding(18.dp)){Text("Ubuntu Launcher",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.headlineSmall,color=Aubergine);Text("Version ${BuildConfig.VERSION_NAME}");Spacer(Modifier.height(16.dp));Text("Developer",fontWeight=FontWeight.Bold);Text("Maclean Of Duart Enterprises Corp");Text(BuildConfig.APPLICATION_ID);Spacer(Modifier.height(16.dp));Text("Licensed under GNU AGPLv3. Ubuntu is a registered trademark of Canonical Ltd. This independent launcher is not endorsed by or affiliated with Canonical.",color=Color.DarkGray)}}
@Composable fun UbuntuTheme(content: @Composable () -> Unit){MaterialTheme(colorScheme=lightColorScheme(primary=Orange,secondary=Aubergine,surface=Warm),content=content)}
