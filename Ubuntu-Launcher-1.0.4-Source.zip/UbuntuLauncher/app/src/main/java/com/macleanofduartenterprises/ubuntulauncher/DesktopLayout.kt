package com.macleanofduartenterprises.ubuntulauncher

internal const val SHORTCUT_MOVE_HOLD_MILLIS = 3_000L

/** Keeps valid saved positions, removes collisions, and assigns every new item a free slot. */
internal fun normalizeDesktopPositions(
    itemIds: List<String>,
    savedPositions: Map<String, Int>
): Map<String, Int> {
    val normalized = linkedMapOf<String, Int>()
    val used = mutableSetOf<Int>()

    itemIds.forEach { id ->
        val saved = savedPositions[id]
        if (saved != null && saved >= 0 && used.add(saved)) {
            normalized[id] = saved
        }
    }

    var nextFree = 0
    itemIds.forEach { id ->
        if (id !in normalized) {
            while (nextFree in used) nextFree++
            normalized[id] = nextFree
            used += nextFree
        }
    }
    return normalized
}

/** Moves to a blank slot or swaps with the item already occupying the requested slot. */
internal fun moveDesktopItem(
    positions: Map<String, Int>,
    movingId: String,
    targetPosition: Int
): Map<String, Int> {
    if (targetPosition < 0) return positions
    val sourcePosition = positions[movingId] ?: return positions
    if (sourcePosition == targetPosition) return positions

    val occupant = positions.entries.firstOrNull {
        it.key != movingId && it.value == targetPosition
    }?.key

    return positions.toMutableMap().apply {
        this[movingId] = targetPosition
        if (occupant != null) this[occupant] = sourcePosition
    }
}

internal fun parseDesktopPositions(values: Set<String>): Map<String, Int> = buildMap {
    values.forEach { encoded ->
        val separator = encoded.lastIndexOf(':')
        if (separator > 0) {
            val id = encoded.substring(0, separator)
            val position = encoded.substring(separator + 1).toIntOrNull()
            if (position != null && position >= 0) put(id, position)
        }
    }
}

internal fun encodeDesktopPositions(positions: Map<String, Int>): Set<String> =
    positions.mapTo(linkedSetOf()) { (id, position) -> "$id:$position" }

