package com.macleanofduartenterprises.ubuntulauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.os.Build
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONObject

private const val NETWORK_TIMEOUT_MILLIS = 7_000
private const val MAX_HTML_BYTES = 1_048_576
private const val MAX_ICON_BYTES = 3_145_728

internal object FaviconLoader {
    private val memoryCache = ConcurrentHashMap<String, Bitmap>()

    fun load(context: Context, pageUrl: String): Bitmap? {
        val normalized = normalizePageUrl(pageUrl) ?: return null
        val key = hash(normalized)
        memoryCache[key]?.let { return it }

        val cacheDirectory = context.cacheDir.resolve("website-favicons").apply { mkdirs() }
        val cacheFile = cacheDirectory.resolve(key + ".png")
        BitmapFactory.decodeFile(cacheFile.path)?.let {
            memoryCache[key] = it
            return it
        }

        val page = fetch(normalized, MAX_HTML_BYTES, "text/html,application/xhtml+xml")
        val finalPageUrl = page?.finalUrl ?: normalized
        val candidates = linkedSetOf<String>()
        if (page != null) {
            val html = page.bytes.toString(Charsets.UTF_8)
            candidates += extractIconUrls(html, finalPageUrl)
            extractManifestUrl(html, finalPageUrl)?.let { manifestUrl ->
                val manifest = fetch(
                    manifestUrl,
                    MAX_HTML_BYTES,
                    "application/manifest+json,application/json"
                )
                if (manifest != null) {
                    candidates += extractManifestIconUrls(
                        manifest.bytes.toString(Charsets.UTF_8),
                        manifest.finalUrl
                    )
                }
            }
        }
        originUrl(finalPageUrl)?.let { origin ->
            candidates += origin + "/favicon.ico"
            candidates += origin + "/favicon.png"
            candidates += origin + "/apple-touch-icon.png"
        }

        candidates.forEach { candidate ->
            val response = fetch(candidate, MAX_ICON_BYTES, "image/*,*/*;q=0.5")
                ?: return@forEach
            decodeBitmap(response.bytes)?.let { bitmap ->
                memoryCache[key] = bitmap
                runCatching {
                    cacheFile.outputStream().use {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                }
                return bitmap
            }
        }
        return null
    }
}

internal fun normalizePageUrl(value: String): String? = runCatching {
    val trimmed = value.trim()
    val hasExplicitScheme = Regex("^[A-Za-z][A-Za-z0-9+.-]*:").containsMatchIn(trimmed)
    val uri = URI(if (hasExplicitScheme) trimmed else "https://$trimmed")
    uri.takeIf {
        it.host != null &&
            (it.scheme.equals("http", ignoreCase = true) ||
                it.scheme.equals("https", ignoreCase = true))
    }?.toString()
}.getOrNull()

internal fun extractIconUrls(html: String, baseUrl: String): List<String> =
    linkTags(html).mapNotNull { attributes ->
        val rel = attributes["rel"]?.lowercase().orEmpty()
        val href = attributes["href"]
        if (
            href != null &&
            rel.split(Regex("\\s+")).any {
                it == "icon" || it == "apple-touch-icon" || it == "shortcut"
            }
        ) {
            resolveUrl(baseUrl, href)
        } else {
            null
        }
    }.distinct()

internal fun extractManifestUrl(html: String, baseUrl: String): String? =
    linkTags(html).firstNotNullOfOrNull { attributes ->
        val rel = attributes["rel"]?.lowercase().orEmpty()
        attributes["href"]
            ?.takeIf { "manifest" in rel.split(Regex("\\s+")) }
            ?.let { resolveUrl(baseUrl, it) }
    }

internal fun extractManifestIconUrls(json: String, manifestUrl: String): List<String> =
    runCatching {
        val icons = JSONObject(json).optJSONArray("icons")
            ?: return@runCatching emptyList()
        buildList {
            for (index in 0 until icons.length()) {
                icons.optJSONObject(index)
                    ?.optString("src")
                    ?.takeIf { it.isNotBlank() }
                    ?.let { src -> resolveUrl(manifestUrl, src)?.let(::add) }
            }
        }.asReversed()
    }.getOrDefault(emptyList())

private fun linkTags(html: String): List<Map<String, String>> {
    val tagPattern = Regex("<link\\b[^>]*>", RegexOption.IGNORE_CASE)
    val attributePattern = Regex(
        "([A-Za-z_:][-A-Za-z0-9_:.]*)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))"
    )
    return tagPattern.findAll(html).map { tag ->
        buildMap {
            attributePattern.findAll(tag.value).forEach { match ->
                val name = match.groupValues[1].lowercase()
                val value = match.groupValues.drop(2)
                    .firstOrNull { it.isNotEmpty() }
                    .orEmpty()
                put(name, value.replace("&amp;", "&"))
            }
        }
    }.toList()
}

private fun resolveUrl(baseUrl: String, candidate: String): String? =
    runCatching { URL(URL(baseUrl), candidate.trim()).toString() }
        .getOrNull()
        ?.takeIf { it.startsWith("http://") || it.startsWith("https://") }

private fun originUrl(value: String): String? = runCatching {
    URI(value).let { uri ->
        val defaultPort =
            (uri.scheme == "https" && uri.port == 443) ||
                (uri.scheme == "http" && uri.port == 80)
        uri.scheme + "://" + uri.host +
            if (uri.port >= 0 && !defaultPort) ":" + uri.port else ""
    }
}.getOrNull()

private data class NetworkResponse(val bytes: ByteArray, val finalUrl: String)

private fun fetch(
    url: String,
    maximumBytes: Int,
    accept: String
): NetworkResponse? = runCatching {
    val connection = URL(url).openConnection() as HttpURLConnection
    try {
        connection.instanceFollowRedirects = true
        connection.connectTimeout = NETWORK_TIMEOUT_MILLIS
        connection.readTimeout = NETWORK_TIMEOUT_MILLIS
        connection.setRequestProperty("Accept", accept)
        connection.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android) UbuntuLauncher/1.0.4"
        )
        connection.setRequestProperty("Accept-Encoding", "identity")
        val status = connection.responseCode
        if (status !in 200..299) return@runCatching null
        NetworkResponse(
            connection.inputStream.use { it.readLimited(maximumBytes) },
            connection.url.toString()
        )
    } finally {
        connection.disconnect()
    }
}.getOrNull()

private fun java.io.InputStream.readLimited(maximumBytes: Int): ByteArray {
    val output = ByteArrayOutputStream(minOf(maximumBytes, 64 * 1024))
    val buffer = ByteArray(16 * 1024)
    var total = 0
    while (true) {
        val count = read(buffer)
        if (count < 0) break
        total += count
        if (total > maximumBytes) {
            throw IllegalStateException("Download exceeds size limit")
        }
        output.write(buffer, 0, count)
    }
    return output.toByteArray()
}

private fun decodeBitmap(bytes: ByteArray): Bitmap? {
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { return it }
    if (Build.VERSION.SDK_INT >= 28) {
        return runCatching {
            ImageDecoder.decodeBitmap(
                ImageDecoder.createSource(ByteBuffer.wrap(bytes))
            ) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        }.getOrNull()
    }
    return null
}

