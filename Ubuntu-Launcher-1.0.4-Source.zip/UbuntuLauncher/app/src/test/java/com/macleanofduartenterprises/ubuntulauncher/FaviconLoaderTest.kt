package com.macleanofduartenterprises.ubuntulauncher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FaviconLoaderTest {
    @Test
    fun extractsStandardAndAppleIconsAndResolvesRelativeUrls() {
        val html = """
            <html><head>
              <link rel="icon" href="/assets/favicon-32.png">
              <link href='icons/touch.png' rel='apple-touch-icon'>
              <link rel="stylesheet" href="/styles.css">
            </head></html>
        """.trimIndent()

        assertEquals(
            listOf(
                "https://example.com/assets/favicon-32.png",
                "https://example.com/folder/icons/touch.png"
            ),
            extractIconUrls(html, "https://example.com/folder/page.html")
        )
    }

    @Test
    fun extractsManifestUrl() {
        val html = "<link href='/site.webmanifest' rel='manifest'>"
        assertEquals(
            "https://example.com/site.webmanifest",
            extractManifestUrl(html, "https://example.com/app/index.html")
        )
    }

    @Test
    fun rejectsUnsupportedPageSchemes() {
        assertNull(normalizePageUrl("file:///tmp/page.html"))
    }
}

