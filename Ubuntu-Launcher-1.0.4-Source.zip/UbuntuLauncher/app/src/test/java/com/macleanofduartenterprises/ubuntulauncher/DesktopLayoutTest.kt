package com.macleanofduartenterprises.ubuntulauncher

import org.junit.Assert.assertEquals
import org.junit.Test

class DesktopLayoutTest {
    @Test
    fun normalizePreservesValidSlotsAndRepairsCollisions() {
        val normalized = normalizeDesktopPositions(
            listOf("gmail", "mode", "maps"),
            mapOf("gmail" to 4, "mode" to 4, "obsolete" to 2)
        )

        assertEquals(4, normalized["gmail"])
        assertEquals(0, normalized["mode"])
        assertEquals(1, normalized["maps"])
        assertEquals(setOf("gmail", "mode", "maps"), normalized.keys)
    }

    @Test
    fun moveToOccupiedSlotSwapsItems() {
        val moved = moveDesktopItem(
            mapOf("gmail" to 0, "mode" to 1, "maps" to 5),
            "gmail",
            5
        )

        assertEquals(5, moved["gmail"])
        assertEquals(0, moved["maps"])
        assertEquals(1, moved["mode"])
    }

    @Test
    fun moveToBlankSlotKeepsOtherItemsInPlace() {
        val moved = moveDesktopItem(
            mapOf("gmail" to 0, "mode" to 1),
            "mode",
            27
        )

        assertEquals(0, moved["gmail"])
        assertEquals(27, moved["mode"])
    }

    @Test
    fun positionEncodingRoundTrips() {
        val original = linkedMapOf("alpha" to 0, "beta" to 19)
        assertEquals(original, parseDesktopPositions(encodeDesktopPositions(original)))
    }
}

