# Ubuntu Launcher 1.0.4 build verification

Verified on 2026-10-09 with JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile/target SDK 35, and Android build tools 35.0.0.

## Completed checks

- `testDebugUnitTest`: passed (7 tests)
- `compileReleaseKotlin`: passed
- `lintRelease`: passed (0 errors; 1 non-blocking dependency-update advisory)
- `assembleRelease`: passed
- R8 code optimization: passed
- Resource shrinking and optimization: passed
- APK zip alignment: passed
- APK Signature Schemes v2 and v3: passed
- Package: `com.macleanofduartenterprises.ubuntulauncher`
- Version: `1.0.4` (`versionCode 7`)
- Minimum/target SDK: 26 / 35
- Native ABIs: ARM64, ARMv7, x86, and x86_64
- Release certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- APK SHA-256: `37da469f6313a359c86009d3130b40ba3b27e0c2a8941852956812b4a85a5dee`
- APK size: 2,504,237 bytes

The package name and release certificate exactly match the supplied 1.0.3.002 APK. Version code 7 is higher than version code 6, allowing Android to treat 1.0.4 as its signed upgrade.

## Repairs and improvements

- Repaired the Kotlin/Compose syntax defects that prevented the supplied source from compiling.
- Replaced stale hard-coded About information with BuildConfig release identity.
- Moved installed-app enumeration and image decoding off the main thread.
- Added sampled wallpaper/file previews and cached application icon bitmaps.
- Replaced fragile hidden WebView favicon extraction with direct favicon discovery, redirect handling, memory caching, and persistent disk caching.
- Added adaptive and monochrome icons.
- Updated adaptive and legacy icons from the supplied Ubuntu Launcher artwork.
- Added independent vertical and horizontal clock placement for portrait and landscape.
- Reserved a full desktop grid row for the clock, preventing overlap with files and links at every placement.
- Added persistent three-second hold-and-drag/tap shortcut placement with occupied-slot swapping.
- Raised the landscape desktop limit to 14 columns and added unlimited vertically scrollable shortcut rows in both orientations.
- Added live preference observation so newly shared files and links appear without restarting the launcher.
- Repaired lock activation, foreground lifecycle re-locking, manual Lock now, PIN validation, and incorrect-entry feedback.
- Enabled release code shrinking, resource shrinking, and optimization.
- Corrected and hardened the signed GitHub Actions build workflow.

The release keystore and credentials are never included in this source archive.
