# Ubuntu Launcher for Android

A standalone Android HOME launcher with an Ubuntu-inspired visual shell. Portrait uses a phone-first Ubuntu-style home; landscape automatically becomes a desktop-style shell with a left dock, Activities/app search and desktop grid.

- App name: **Ubuntu Launcher**
- Application ID: `com.macleanofduartenterprises.ubuntulauncher`
- Version: **1.0.1** (`versionCode 2`)
- Developer: **Maclean Of Duart Enterprises Corp**

## Included
- Android HOME/default-launcher role request
- Automatic portrait/landscape layouts
- Ubuntu-inspired aubergine/orange UI
- Installed-app discovery and launch
- App + Android settings search
- Pinnable dock (long-press an app)
- Dumb Phone Mode with selectable allowed apps
- Launcher-level hidden-app vault, available only inside Launcher Settings
- Wi-Fi/Bluetooth/Display/Sound/Storage/Security/Accessibility shortcuts
- Package-change refresh when apps are installed, removed, or updated

## Build
Open in Android Studio (JDK 17), allow Gradle sync, then Build > Build APK(s), or run:

```bash
./gradlew assembleDebug
./gradlew assembleRelease
```

The included Gradle wrapper uses Gradle 8.9. The project uses compileSdk/targetSdk 35 and minSdk 26. The release build is a universal APK; the bundled AndroidX native helper includes ARM64, ARMv7, x86, and x86_64 ABIs.

The source project intentionally excludes private signing keys and passwords. Keep release credentials outside version control, then align and sign the release APK with Android SDK `zipalign` and `apksigner`.

## Important Android limitations
The Hidden Apps feature removes selected apps from this launcher's Home, drawer, search and Dumb Phone mode. It does not uninstall, disable, or system-lock them. Strong system-wide blocking requires device-owner/enterprise privileges or OS support. Android 15+ Private Space is a separate platform feature and requires additional launcher integration if you want to expose Private Space apps.

## Suggested next modules
Widgets/AppWidgetHost, folders, desktop drag-and-drop, notification badges (with notification-listener permission), icon packs, wallpaper picker, gestures, backup/export, work/private-profile support, keyboard shortcuts, mouse context menus, and per-orientation layouts.

## License

Ubuntu Launcher is distributed under the GNU Affero General Public License, version 3 (AGPLv3). The complete license text is included in the repository as `LICENSE`, bundled in the Android application as `res/raw/agpl_3_0.txt`, and can be viewed in the launcher under **Ubuntu Launcher Settings → Licenses**.

Ubuntu and the Ubuntu logo are registered trademarks of Canonical Ltd. This independent project is not endorsed by or affiliated with Canonical.
