package com.macleanofduartenterprises.ubuntulauncher

import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Rotate90DegreesCcw
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import java.text.Collator
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Aubergine = Color(0xFF2C001E)
private val Aubergine2 = Color(0xFF3D1230)
private val Orange = Color(0xFFE95420)
private val Warm = Color(0xFFF7F3F0)

data class AppItem(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable,
)

data class SettingItem(
    val label: String,
    val subtitle: String,
    val action: String,
)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val roleRequest =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherApp(prefs) }
    }

    fun requestHome() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (
                roleManager.isRoleAvailable(RoleManager.ROLE_HOME) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_HOME)
            ) {
                roleRequest.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME))
            }
        } else {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        }
    }
}

fun loadApps(context: Context): List<AppItem> {
    val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return context.packageManager
        .queryIntentActivities(query, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .map { resolveInfo: ResolveInfo ->
            AppItem(
                label = resolveInfo.loadLabel(context.packageManager).toString(),
                packageName = resolveInfo.activityInfo.packageName,
                activityName = resolveInfo.activityInfo.name,
                icon = resolveInfo.loadIcon(context.packageManager),
            )
        }
        .distinctBy { it.packageName + it.activityName }
        .sortedWith(compareBy(Collator.getInstance()) { it.label })
}

fun launch(context: Context, app: AppItem) {
    runCatching {
        context.startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(app.packageName, app.activityName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}

fun openSetting(context: Context, action: String) {
    runCatching {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@Composable
fun LauncherApp(prefs: SharedPreferences) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf(loadApps(context)) }
    var settingsOpen by remember { mutableStateOf(false) }
    var drawerOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }

    val hidden = remember(refresh) { prefs.getStringSet("hidden", emptySet()).orEmpty().toSet() }
    val dumbSet = remember(refresh) { prefs.getStringSet("dumb", emptySet()).orEmpty().toSet() }
    val pins = remember(refresh) { prefs.getStringSet("pins", emptySet()).orEmpty().toList() }
    val dumbMode = remember(refresh) { prefs.getBoolean("dumb_mode", false) }

    DisposableEffect(context) {
        val receiver =
            object : BroadcastReceiver() {
                override fun onReceive(receiverContext: Context?, intent: Intent?) {
                    apps = loadApps(context)
                }
            }
        val filter =
            IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_CHANGED)
                addDataScheme("package")
            }
        ContextCompat.registerReceiver(
            context,
            receiver,
            filter,
            ContextCompat.RECEIVER_EXPORTED,
        )
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }

    val landscape =
        LocalConfiguration.current.orientation ==
            android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val visible =
        apps.filter {
            it.packageName !in hidden && (!dumbMode || it.packageName in dumbSet)
        }

    UbuntuTheme {
        Box(
            Modifier
                .fillMaxSize()
                .background(if (landscape) Aubergine else Aubergine2),
        ) {
            if (landscape) {
                DesktopShell(
                    visible = visible,
                    all = apps,
                    pins = pins,
                    search = search,
                    onSearch = { search = it },
                    onDrawer = { drawerOpen = it },
                    onSettings = { settingsOpen = true },
                    prefs = prefs,
                    onChanged = { refresh++ },
                )
            } else {
                PhoneShell(
                    visible = visible,
                    all = apps,
                    pins = pins,
                    search = search,
                    onSearch = { search = it },
                    onDrawer = { drawerOpen = it },
                    onSettings = { settingsOpen = true },
                    prefs = prefs,
                    dumb = dumbMode,
                    onChanged = { refresh++ },
                )
            }

            if (drawerOpen) {
                AppDrawer(
                    apps = visible,
                    query = search,
                    setQuery = { search = it },
                    close = { drawerOpen = false },
                    settings = { settingsOpen = true },
                    prefs = prefs,
                    onChanged = { refresh++ },
                )
            }

            if (settingsOpen) {
                LauncherSettings(
                    apps = apps,
                    prefs = prefs,
                    close = { settingsOpen = false },
                    onChanged = { refresh++ },
                )
            }
        }
    }
}

@Composable
fun PhoneShell(
    visible: List<AppItem>,
    all: List<AppItem>,
    pins: List<String>,
    search: String,
    onSearch: (String) -> Unit,
    onDrawer: (Boolean) -> Unit,
    onSettings: () -> Unit,
    prefs: SharedPreferences,
    dumb: Boolean,
    onChanged: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (dumb) "Dumb Phone" else "Ubuntu Launcher",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.headlineMedium,
                )
                Text(
                    DateFormat.getDateInstance().format(Date()),
                    color = Color.White.copy(alpha = 0.72f),
                )
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, "Settings", tint = Color.White)
            }
        }
        Spacer(Modifier.height(18.dp))
        SearchBox(search, onSearch) { onDrawer(true) }
        Spacer(Modifier.height(18.dp))
        if (dumb) {
            DumbGrid(visible)
        } else {
            AppGrid(visible.take(12), prefs, onChanged)
        }
        Spacer(Modifier.weight(1f))
        Dock(all, pins, prefs, onChanged) { onDrawer(true) }
    }
}

@Composable
fun DesktopShell(
    visible: List<AppItem>,
    all: List<AppItem>,
    pins: List<String>,
    search: String,
    onSearch: (String) -> Unit,
    onDrawer: (Boolean) -> Unit,
    onSettings: () -> Unit,
    prefs: SharedPreferences,
    onChanged: () -> Unit,
) {
    val context = LocalContext.current
    Row(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        DesktopRail(all, pins, prefs, onChanged) { onDrawer(true) }
        Column(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Activities", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(20.dp))
                Box(Modifier.widthIn(max = 420.dp)) {
                    SearchBox(search, onSearch) { onDrawer(true) }
                }
                Spacer(Modifier.weight(1f))
                Text(
                    SimpleDateFormat("EEE  HH:mm", Locale.getDefault()).format(Date()),
                    color = Color.White,
                )
                IconButton(onClick = onSettings) {
                    Icon(Icons.Default.Settings, "Settings", tint = Color.White)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Desktop", color = Color.White.copy(alpha = 0.8f))
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(columns = GridCells.Adaptive(100.dp)) {
                items(visible.take(20), key = { it.packageName + it.activityName }) { app ->
                    AppTile(app, label = false, onClick = { launch(context, app) })
                }
            }
        }
    }
}

@Composable
fun SearchBox(
    query: String,
    setQuery: (String) -> Unit,
    open: () -> Unit,
) {
    OutlinedTextField(
        value = query,
        onValueChange = {
            setQuery(it)
            open()
        },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text("Search apps and settings") },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        colors =
            OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Orange,
                unfocusedBorderColor = Color.White.copy(alpha = 0.35f),
                focusedContainerColor = Color.Black.copy(alpha = 0.16f),
                unfocusedContainerColor = Color.Black.copy(alpha = 0.16f),
                focusedPlaceholderColor = Color.White.copy(alpha = 0.55f),
                unfocusedPlaceholderColor = Color.White.copy(alpha = 0.55f),
            ),
    )
}

@Composable
fun AppGrid(
    apps: List<AppItem>,
    prefs: SharedPreferences,
    onChanged: () -> Unit,
) {
    val context = LocalContext.current
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = Modifier.fillMaxWidth().heightIn(max = 430.dp),
    ) {
        items(apps, key = { it.packageName + it.activityName }) { app ->
            AppTile(
                app,
                onClick = { launch(context, app) },
                onLong = {
                    togglePin(prefs, app.packageName)
                    onChanged()
                },
            )
        }
    }
}

@Composable
fun DumbGrid(apps: List<AppItem>) {
    val context = LocalContext.current
    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxWidth()) {
        items(apps, key = { it.packageName + it.activityName }) { app ->
            AppTile(app, onClick = { launch(context, app) })
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppTile(
    app: AppItem,
    label: Boolean = true,
    onClick: () -> Unit,
    onLong: (() -> Unit)? = null,
) {
    Column(
        Modifier
            .padding(7.dp)
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            app.icon.toBitmap(96, 96).asImageBitmap(),
            app.label,
            Modifier.size(48.dp),
        )
        if (label) {
            Text(
                app.label,
                color = Color.White,
                maxLines = 1,
                style = MaterialTheme.typography.labelMedium,
            )
        }
    }
}

fun togglePin(
    prefs: SharedPreferences,
    packageName: String,
) {
    val pins = prefs.getStringSet("pins", emptySet()).orEmpty().toMutableSet()
    if (!pins.add(packageName)) {
        pins.remove(packageName)
    }
    prefs.edit().putStringSet("pins", pins).apply()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Dock(
    all: List<AppItem>,
    pins: List<String>,
    prefs: SharedPreferences,
    onChanged: () -> Unit,
    drawer: () -> Unit,
) {
    val context = LocalContext.current
    Surface(color = Color.Black.copy(alpha = 0.34f), shape = RoundedCornerShape(24.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = drawer) {
                Icon(Icons.Default.Apps, "Apps", tint = Color.White)
            }
            pins
                .take(5)
                .mapNotNull { packageName ->
                    all.firstOrNull { it.packageName == packageName }
                }.forEach { app ->
                    Box(
                        modifier =
                            Modifier
                                .size(48.dp)
                                .combinedClickable(
                                    onClick = { launch(context, app) },
                                    onLongClick = {
                                        togglePin(prefs, app.packageName)
                                        onChanged()
                                    },
                                ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Image(
                            app.icon.toBitmap(72, 72).asImageBitmap(),
                            app.label,
                            Modifier.size(34.dp),
                        )
                    }
                }
            IconButton(onClick = { openSetting(context, Settings.ACTION_SETTINGS) }) {
                Icon(Icons.Default.Settings, "System settings", tint = Color.White)
            }
        }
    }
}

@Composable
fun DesktopRail(
    all: List<AppItem>,
    pins: List<String>,
    prefs: SharedPreferences,
    onChanged: () -> Unit,
    drawer: () -> Unit,
) {
    val context = LocalContext.current
    Column(
        Modifier
            .width(68.dp)
            .fillMaxHeight()
            .background(Color.Black.copy(alpha = 0.42f))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        IconButton(onClick = drawer) {
            Icon(Icons.Default.Apps, "Activities", tint = Color.White)
        }
        Spacer(Modifier.height(10.dp))
        pins
            .take(8)
            .mapNotNull { packageName ->
                all.firstOrNull { it.packageName == packageName }
            }.forEach { app ->
                Image(
                    app.icon.toBitmap(72, 72).asImageBitmap(),
                    app.label,
                    Modifier
                        .padding(7.dp)
                        .size(42.dp)
                        .clickable { launch(context, app) },
                )
            }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = { openSetting(context, Settings.ACTION_SETTINGS) }) {
            Icon(Icons.Default.Settings, "System settings", tint = Color.White)
        }
    }
}

val settingItems =
    listOf(
        SettingItem("Wi-Fi", "Networks and Internet", Settings.ACTION_WIFI_SETTINGS),
        SettingItem("Bluetooth", "Connected devices", Settings.ACTION_BLUETOOTH_SETTINGS),
        SettingItem("Display", "Brightness, rotation and display", Settings.ACTION_DISPLAY_SETTINGS),
        SettingItem("Sound", "Volume and sound", Settings.ACTION_SOUND_SETTINGS),
        SettingItem("Storage", "Device storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
        SettingItem("Security", "Security settings", Settings.ACTION_SECURITY_SETTINGS),
        SettingItem("Accessibility", "Accessibility services", Settings.ACTION_ACCESSIBILITY_SETTINGS),
        SettingItem("System settings", "All Android settings", Settings.ACTION_SETTINGS),
    )

@Composable
fun AppDrawer(
    apps: List<AppItem>,
    query: String,
    setQuery: (String) -> Unit,
    close: () -> Unit,
    settings: () -> Unit,
    prefs: SharedPreferences,
    onChanged: () -> Unit,
) {
    val context = LocalContext.current
    val appResults =
        apps.filter {
            it.label.contains(query, ignoreCase = true) ||
                it.packageName.contains(query, ignoreCase = true)
        }
    val settingResults =
        settingItems.filter {
            it.label.contains(query, ignoreCase = true) ||
                it.subtitle.contains(query, ignoreCase = true)
        }

    Surface(Modifier.fillMaxSize(), color = Aubergine.copy(alpha = 0.98f)) {
        Column(
            Modifier
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(16.dp),
        ) {
            Row {
                Box(Modifier.weight(1f)) {
                    SearchBox(query, setQuery) {}
                }
                IconButton(onClick = close) {
                    Icon(Icons.Default.Close, "Close", tint = Color.White)
                }
            }

            if (query.isNotBlank() && settingResults.isNotEmpty()) {
                Text("Settings", color = Orange, fontWeight = FontWeight.Bold)
                settingResults.forEach { setting ->
                    ListItem(
                        headlineContent = { Text(setting.label) },
                        supportingContent = { Text(setting.subtitle) },
                        leadingContent = { Icon(Icons.Default.Settings, null) },
                        modifier = Modifier.clickable { openSetting(context, setting.action) },
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Applications",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = settings) {
                    Text("Launcher settings")
                }
            }

            LazyVerticalGrid(columns = GridCells.Adaptive(90.dp)) {
                items(appResults, key = { it.packageName + it.activityName }) { app ->
                    AppTile(
                        app,
                        onClick = { launch(context, app) },
                        onLong = {
                            togglePin(prefs, app.packageName)
                            onChanged()
                        },
                    )
                }
            }
        }
    }
}

@Composable
fun LauncherSettings(
    apps: List<AppItem>,
    prefs: SharedPreferences,
    close: () -> Unit,
    onChanged: () -> Unit,
) {
    val context = LocalContext.current
    var page by remember { mutableStateOf("main") }
    var tick by remember { mutableIntStateOf(0) }
    val dumbMode = remember(tick) { prefs.getBoolean("dumb_mode", false) }

    Surface(Modifier.fillMaxSize(), color = Warm) {
        Column(
            Modifier
                .statusBarsPadding()
                .navigationBarsPadding(),
        ) {
            Row(
                Modifier.fillMaxWidth().background(Aubergine).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { if (page == "main") close() else page = "main" }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                }
                Text(
                    when (page) {
                        "hidden" -> "Hidden applications"
                        "dumbapps" -> "Dumb Phone applications"
                        "licenses" -> "Licenses"
                        "about" -> "About"
                        else -> "Ubuntu Launcher Settings"
                    },
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                )
            }

            when (page) {
                "hidden" ->
                    AppSelector(apps, prefs, "hidden", launchable = true) {
                        tick++
                        onChanged()
                    }

                "dumbapps" ->
                    AppSelector(apps, prefs, "dumb", launchable = false) {
                        tick++
                        onChanged()
                    }

                "licenses" -> LicenseScreen()
                "about" -> AboutScreen()
                else ->
                    LazyColumn {
                        item {
                            SettingRow(
                                Icons.Default.Home,
                                "Make default Home",
                                "Set this launcher as the Android Home app",
                            ) {
                                (context as? MainActivity)?.requestHome()
                            }
                        }
                        item {
                            SettingRow(
                                Icons.Default.PhoneAndroid,
                                "Dumb Phone Mode",
                                if (dumbMode) {
                                    "Enabled — only selected apps are shown"
                                } else {
                                    "Disabled — full launcher is shown"
                                },
                                switch = dumbMode,
                            ) {
                                prefs.edit().putBoolean("dumb_mode", !dumbMode).apply()
                                tick++
                                onChanged()
                            }
                        }
                        item {
                            SettingRow(
                                Icons.Default.Checklist,
                                "Choose Dumb Phone apps",
                                "Customize which apps remain accessible",
                            ) {
                                page = "dumbapps"
                            }
                        }
                        item {
                            SettingRow(
                                Icons.Default.VisibilityOff,
                                "Hidden apps",
                                "Hidden from Home, app drawer and search; accessible here only",
                            ) {
                                page = "hidden"
                            }
                        }
                        item {
                            SettingRow(
                                Icons.Default.Rotate90DegreesCcw,
                                "Rotation",
                                "Portrait phone shell; landscape Ubuntu desktop shell",
                            ) {
                                openSetting(context, Settings.ACTION_DISPLAY_SETTINGS)
                            }
                        }
                        item {
                            SettingRow(
                                Icons.Default.Settings,
                                "Android Settings",
                                "Open system settings",
                            ) {
                                openSetting(context, Settings.ACTION_SETTINGS)
                            }
                        }
                        item {
                            SettingRow(
                                Icons.Default.Info,
                                "About",
                                "Version, developer, and package information",
                            ) {
                                page = "about"
                            }
                        }
                        item {
                            SettingRow(
                                Icons.Default.Description,
                                "Licenses",
                                "GNU Affero General Public License v3.0 (AGPLv3)",
                            ) {
                                page = "licenses"
                            }
                        }
                        item {
                            Text(
                                "Tips",
                                Modifier.padding(18.dp),
                                fontWeight = FontWeight.Bold,
                                color = Aubergine,
                            )
                            Text(
                                "Long-press an app in Home or the app drawer to pin or unpin it from the dock. Hidden apps can still be launched from the Hidden applications page.",
                                Modifier.padding(horizontal = 18.dp, vertical = 4.dp),
                                color = Color.DarkGray,
                            )
                        }
                    }
            }
        }
    }
}

@Composable
fun SettingRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    switch: Boolean? = null,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Orange)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(
                subtitle,
                color = Color.Gray,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        if (switch != null) {
            Switch(checked = switch, onCheckedChange = { onClick() })
        }
    }
}

@Composable
fun AppSelector(
    apps: List<AppItem>,
    prefs: SharedPreferences,
    key: String,
    launchable: Boolean,
    onChanged: () -> Unit,
) {
    val context = LocalContext.current
    var selected by remember {
        mutableStateOf(prefs.getStringSet(key, emptySet()).orEmpty().toSet())
    }

    LazyColumn {
        items(apps, key = { it.packageName + it.activityName }) { app ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable {
                        val updated = selected.toMutableSet()
                        if (!updated.add(app.packageName)) {
                            updated.remove(app.packageName)
                        }
                        selected = updated
                        prefs.edit().putStringSet(key, updated).apply()
                        onChanged()
                    }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(
                    app.icon.toBitmap(64, 64).asImageBitmap(),
                    app.label,
                    Modifier.size(38.dp),
                )
                Spacer(Modifier.width(12.dp))
                Text(app.label, Modifier.weight(1f))
                if (launchable) {
                    IconButton(onClick = { launch(context, app) }) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, "Open")
                    }
                }
                Checkbox(selected.contains(app.packageName), onCheckedChange = null)
            }
        }
    }
}

@Composable
fun UbuntuTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme =
            lightColorScheme(
                primary = Orange,
                secondary = Aubergine,
                surface = Warm,
            ),
        content = content,
    )
}

@Composable
fun LicenseScreen() {
    val context = LocalContext.current
    val licenseText =
        remember {
            runCatching {
                context.resources
                    .openRawResource(R.raw.agpl_3_0)
                    .bufferedReader()
                    .use { it.readText() }
            }.getOrElse {
                "Unable to load the bundled AGPLv3 license text."
            }
        }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        item {
            Spacer(Modifier.height(18.dp))
            Text(
                "GNU Affero General Public License",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleLarge,
                color = Aubergine,
            )
            Text("Version 3, 19 November 2007", color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            Text(
                "This launcher is distributed under the GNU Affero General Public License version 3. The complete license is bundled with the application and source project.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(18.dp))
            HorizontalDivider()
            Spacer(Modifier.height(18.dp))
            Text(licenseText, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
fun AboutScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp)) {
        item {
            Text(
                "Ubuntu Launcher",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineSmall,
                color = Aubergine,
            )
            Spacer(Modifier.height(8.dp))
            Text("Version 1.0.1", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(18.dp))
            Text("Developer", fontWeight = FontWeight.SemiBold, color = Aubergine)
            Text("Maclean Of Duart Enterprises Corp")
            Spacer(Modifier.height(12.dp))
            Text("Application ID", fontWeight = FontWeight.SemiBold, color = Aubergine)
            Text("com.macleanofduartenterprises.ubuntulauncher")
            Spacer(Modifier.height(18.dp))
            Text(
                "Ubuntu is a registered trademark of Canonical Ltd. This independent launcher is not endorsed by or affiliated with Canonical.",
                color = Color.DarkGray,
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}
